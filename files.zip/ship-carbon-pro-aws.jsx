import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Ship, LogOut, Plus, Shield, TrendingUp, DollarSign, Activity, Anchor,
  Trash2, Leaf, CheckCircle, AlertCircle, FileText, Download, Printer,
  Zap, X, ChevronDown, ChevronUp, TrendingDown, Target, RefreshCw,
  Link, Search, Key, Eye, Award, Globe, Wallet, Gauge, MapPin, Radio,
} from 'lucide-react';
import {
  PieChart as RechartsPie, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Area, AreaChart,
  BarChart, Bar, Legend, LineChart, Line, ReferenceLine,
} from 'recharts';

/* ═══════════════════════════════════════════════════════════════════
   CONSTANTS — Gemi profilleri, yakıt faktörleri, CII, ETS, FuelEU
   ═══════════════════════════════════════════════════════════════════ */
const SHIP_PROFILES = {
  'Bulk Carrier': { dailyFuel: 28, defaultSpeed: 13.5, refDWT: 58000 },
  'Tanker':       { dailyFuel: 40, defaultSpeed: 14.0, refDWT: 80000 },
  'Container':    { dailyFuel: 115, defaultSpeed: 17.0, refDWT: 50000 },
  'Ro-Ro':        { dailyFuel: 50, defaultSpeed: 16.0, refDWT: 12000 },
  'LPG':          { dailyFuel: 35, defaultSpeed: 15.0, refDWT: 45000 },
  'LNG':          { dailyFuel: 65, defaultSpeed: 19.0, refDWT: 70000 },
};

const LNG_ENGINE_TYPES = {
  'Otto DF Medium Speed': { label: 'Otto Dual Fuel Medium Speed', cslip: 0.031 },
  'Otto DF Slow Speed':   { label: 'Otto Dual Fuel Slow Speed',   cslip: 0.017 },
  'Diesel DF Slow Speed': { label: 'Diesel Dual Fuel Slow Speed', cslip: 0.002 },
  'LBSI':                 { label: 'Lean-Burn Spark-Ignited',     cslip: 0.026 },
};
const LNG_ENGINE_DEFAULT = 'Otto DF Medium Speed';

const FUEL_EMISSION_FACTORS = {
  'HFO': 3.114, 'VLSFO': 3.151, 'MGO': 3.206, 'LNG': 2.750, 'Methanol': 1.375,
  'LPG_Butane': 3.030, 'LPG_Propane': 3.000,
  'Ethanol': 1.913, 'Biodiesel': 2.834, 'HVO': 3.115,
  'Bio-LNG': 2.750, 'Bio-Methanol': 1.375,
  'e-Diesel': 3.206, 'e-Methanol': 1.375, 'e-LNG': 2.750,
  'H2_Fossil': 0, 'NH3_Fossil': 0, 'Bio-H2': 0, 'e-H2': 0, 'e-NH3': 0,
};

const FUEL_GHG_FACTORS = {
  'HFO':          { co2: 3.114, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'VLSFO':        { co2: 3.151, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'MGO':          { co2: 3.206, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'LNG':          { co2: 2.750, ch4: 0.00000, n2o: 0.00011, isLNG: true },
  'LPG_Butane':   { co2: 3.030, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'LPG_Propane':  { co2: 3.000, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'H2_Fossil':    { co2: 0,     ch4: 0,       n2o: 0.00018, isLNG: false },
  'NH3_Fossil':   { co2: 0,     ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Methanol':     { co2: 1.375, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Ethanol':      { co2: 1.913, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Biodiesel':    { co2: 2.834, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'HVO':          { co2: 3.115, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Bio-LNG':      { co2: 2.750, ch4: 0.00000, n2o: 0.00011, isLNG: true },
  'Bio-Methanol': { co2: 1.375, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Bio-H2':       { co2: 0,     ch4: 0,       n2o: 0,       isLNG: false },
  'e-Diesel':     { co2: 3.206, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'e-Methanol':   { co2: 1.375, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'e-LNG':        { co2: 2.750, ch4: 0.00000, n2o: 0.00011, isLNG: true },
  'e-H2':         { co2: 0,     ch4: 0,       n2o: 0,       isLNG: false },
  'e-NH3':        { co2: 0,     ch4: 0.00005, n2o: 0.00018, isLNG: false },
};

const ROUTE_ETS_RATES = { 'AB içi': 1.00, 'Yarı AB': 0.50, 'AB dışı': 0.00 };
const ETS_PHASE_IN = { 2023: 0.00, 2024: 0.40, 2025: 0.70, 2026: 1.00 };
const ETS_GWP = { CO2: 1, CH4: 28, N2O: 265 };

const FUELEU_GWP_SETS = {
  AR4: { CO2: 1, CH4: 25, N2O: 298, label: 'AR4 — Geçerli (FuelEU Annex II)', source: 'Regulation (EU) 2023/1805, Annex II', status: 'current' },
  AR5: { CO2: 1, CH4: 28, N2O: 265, label: 'AR5 — EU ETS / MRV Geçerli', source: 'Delegated Reg. (EU) 2020/1044', status: 'current' },
};
const FUELEU_GWP_DEFAULT = 'AR4';

const FUELEU_TARGETS = {
  2025: { reduction: 0.02, limit: 91.16 * 0.98 },
  2030: { reduction: 0.06, limit: 91.16 * 0.94 },
  2035: { reduction: 0.145, limit: 91.16 * 0.855 },
  2040: { reduction: 0.31, limit: 91.16 * 0.69 },
  2045: { reduction: 0.62, limit: 91.16 * 0.38 },
  2050: { reduction: 0.80, limit: 91.16 * 0.20 },
};

const FUELEU_VLSFO_LCV_PER_TON = 41000;
const FUELEU_PENALTY_PER_TON_VLSFO = 2400;

const FUELEU_FACTORS = {
  'HFO':      { name: 'HFO (Grades RME–RMK)', fuelClass: 'Fossil', lcv: 0.0405, wtT: 13.5, cfCO2: 3.114, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'VLSFO':    { name: 'LFO / VLSFO (Grades RMA–RMD)', fuelClass: 'Fossil', lcv: 0.0410, wtT: 13.2, cfCO2: 3.151, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'MGO':      { name: 'MDO / MGO (Grades DMX–DMB)', fuelClass: 'Fossil', lcv: 0.0427, wtT: 14.4, cfCO2: 3.206, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'LNG':      { name: 'LNG', fuelClass: 'Fossil', lcv: 0.0491, wtT: 18.5, cfCO2: 2.750, cfCH4: 0.00000, cfN2O: 0.00011, cslip: null, cslipByEngine: { 'Otto DF Medium Speed': 0.031, 'Otto DF Slow Speed': 0.017, 'Diesel DF Slow Speed': 0.002, 'LBSI': 0.026 } },
  'LPG_Butane':  { name: 'LPG (Butane)', fuelClass: 'Fossil', lcv: 0.0459, wtT: 7.8, cfCO2: 3.030, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'LPG_Propane': { name: 'LPG (Propane)', fuelClass: 'Fossil', lcv: 0.0461, wtT: 7.8, cfCO2: 3.000, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'H2_Fossil':   { name: 'H₂ (Fossil)', fuelClass: 'Fossil', lcv: 0.1200, wtT: 132.0, cfCO2: 0, cfCH4: 0, cfN2O: 0.00018, cslip: 0.0 },
  'NH3_Fossil':  { name: 'NH₃ (Fossil)', fuelClass: 'Fossil', lcv: 0.0186, wtT: 121.0, cfCO2: 0, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Methanol':    { name: 'Fossil Methanol', fuelClass: 'Fossil', lcv: 0.0199, wtT: 31.3, cfCO2: 1.375, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Ethanol':      { name: 'Ethanol', fuelClass: 'Biofuel', lcv: 0.0267, wtT: null, cfCO2: 1.913, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Biodiesel':    { name: 'Bio-diesel (FAME)', fuelClass: 'Biofuel', lcv: 0.0372, wtT: null, cfCO2: 2.834, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'HVO':          { name: 'HVO', fuelClass: 'Biofuel', lcv: 0.0440, wtT: null, cfCO2: 3.115, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Bio-LNG':      { name: 'Bio-LNG', fuelClass: 'Biofuel', lcv: 0.0491, wtT: null, cfCO2: 2.750, cfCH4: 0.00000, cfN2O: 0.00011, cslip: null, cslipByEngine: { 'Otto DF Medium Speed': 0.031, 'Otto DF Slow Speed': 0.017, 'Diesel DF Slow Speed': 0.002, 'LBSI': 0.026 } },
  'Bio-Methanol': { name: 'Bio-methanol', fuelClass: 'Biofuel', lcv: 0.0199, wtT: null, cfCO2: 1.375, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Bio-H2':       { name: 'Bio-H₂', fuelClass: 'Biofuel', lcv: 0.1200, wtT: null, cfCO2: 0, cfCH4: 0, cfN2O: 0, cslip: 0.0 },
  'e-Diesel':   { name: 'e-Diesel', fuelClass: 'RFNBO', lcv: 0.0427, wtT: null, cfCO2: 3.206, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'e-Methanol': { name: 'e-Methanol', fuelClass: 'RFNBO', lcv: 0.0199, wtT: null, cfCO2: 1.375, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'e-LNG':      { name: 'e-LNG', fuelClass: 'RFNBO', lcv: 0.0491, wtT: null, cfCO2: 2.750, cfCH4: 0.00000, cfN2O: 0.00011, cslip: null, cslipByEngine: { 'Otto DF Medium Speed': 0.031, 'Otto DF Slow Speed': 0.017, 'Diesel DF Slow Speed': 0.002, 'LBSI': 0.026 } },
  'e-H2':       { name: 'e-H₂', fuelClass: 'RFNBO', lcv: 0.1200, wtT: null, cfCO2: 0, cfCH4: 0, cfN2O: 0, cslip: 0.0 },
  'e-NH3':      { name: 'e-NH₃', fuelClass: 'RFNBO', lcv: 0.0186, wtT: null, cfCO2: 0, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
};

const FUEL_CATEGORIES = {
  'Fossil':  ['HFO', 'VLSFO', 'MGO', 'LNG', 'Methanol', 'LPG_Butane', 'LPG_Propane'],
  'Biofuel': ['Biodiesel', 'HVO', 'Bio-LNG', 'Bio-Methanol', 'Ethanol'],
  'RFNBO':   ['e-Diesel', 'e-Methanol', 'e-LNG', 'e-H2', 'e-NH3'],
};

const isLNGTypeFuel = (fuelType) => ['LNG', 'Bio-LNG', 'e-LNG'].includes(fuelType);

const resolveCslip = (fuelType, engineType) => {
  const f = FUELEU_FACTORS[fuelType];
  if (!f) return 0;
  if (f.cslip !== null && f.cslip !== undefined) return f.cslip;
  if (f.cslipByEngine && engineType) return f.cslipByEngine[engineType] || 0.031;
  if (f.cslipByEngine) return f.cslipByEngine[LNG_ENGINE_DEFAULT] || 0.031;
  return 0;
};

const FUELEU_SCOPE_RATES = { 'AB içi': 1.00, 'Yarı AB': 0.50, 'AB dışı': 0.00 };
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

/* MEPC.353(78) Tablo 1 + MEPC.354(78) dd vektörleri.
   DÜZELTME (v3): LNG ve Gaz taşıyıcı (LPG) parametreleri DWT'ye göre
   parçalıdır ve eski kod bunu tek satıra indirgemişti (LNG'ye üstelik
   gaz taşıyıcının dd vektörü atanmıştı). Bulk ≥279k DWT'de kapasite
   279.000'e sabitlenir (Capacity cap). Kaynak: IMO MEPC 78/17/Add.1. */
const CII_REF_LINES = {
  'Bulk Carrier': { a: 4745, c: 0.622, d: [0.86, 0.94, 1.06, 1.18] },
  'Tanker':       { a: 5247, c: 0.610, d: [0.82, 0.93, 1.08, 1.28] },
  'Container':    { a: 1984, c: 0.489, d: [0.83, 0.94, 1.07, 1.19] },
  'Ro-Ro':        { a: 5739, c: 0.631, d: [0.86, 0.94, 1.06, 1.16] },
};

// CII hesabında kullanılacak Kapasite (MEPC.353(78) Capacity sütunu)
const getCIICapacity = (shipType, dwt) => {
  const w = parseFloat(dwt) || 0;
  if (shipType === 'Bulk Carrier' && w >= 279000) return 279000;
  if (shipType === 'LNG' && w < 65000) return 65000; // LNG <65k: Capacity=65.000
  return w;
};

// Gemi tipi + DWT'ye göre referans hattı parametreleri {a, c, d}
const getCIIRefParams = (shipType, dwt) => {
  const w = parseFloat(dwt) || 0;
  if (shipType === 'LNG') {
    if (w >= 100000) return { a: 9.827, c: 0.000, d: [0.89, 0.98, 1.06, 1.13] };
    return { a: 14479e10, c: 2.673, d: [0.78, 0.92, 1.10, 1.37] }; // <100k (kapasite <65k'da 65k'ya sabitlenir)
  }
  if (shipType === 'LPG') {
    if (w >= 65000) return { a: 14405e7, c: 2.071, d: [0.81, 0.91, 1.12, 1.44] };
    return { a: 8104, c: 0.639, d: [0.85, 0.95, 1.06, 1.25] };
  }
  return CII_REF_LINES[shipType] || null;
};

const CII_REDUCTION_Z = {
  2023: 5, 2024: 7, 2025: 9, 2026: 11,
  2027: 13.625, 2028: 16.250, 2029: 18.875, 2030: 21.500,
};

const REPORT_FOOTER_TEXT = "Bu rapor karar destek aracı niteliğindedir. Resmi IMO DCS, CII ve EU ETS beyanı için akredite doğrulayıcı onayı gereklidir.";
const BDN_DISCLAIMER = "ℹ️ Yakıt verileri BDN ile doğrulanmamıştır. Klas kuruluşu onayı için BDN tabanlı veri kaynağı zorunludur.";
const CII_ANNUAL_DISCLAIMER = "* CII notu tüm yıl seferlerinin toplamına dayanır. Resmi CII, takvim yılı sonu klas kuruluşunca doğrulanır.";

/* ═══════════════════════════════════════════════════════════════════
   RBAC — Roller ve izinler
   ═══════════════════════════════════════════════════════════════════ */
const ROLES = {
  officer: { label: 'Gemi Subayı', badge: '⚓', can: ['create_voyage', 'view_dashboard', 'view_fleet'], color: 'blue' },
  superintendent: { label: 'Süpervizör', badge: '🏢', can: ['create_voyage', 'delete_voyage', 'create_ship', 'view_dashboard', 'view_fleet', 'view_whatif', 'view_report', 'export_report', 'view_audit', 'edit_settings', 'upload_bdn', 'verify_bdn', 'create_verifier'], color: 'cyan' },
  auditor: { label: 'Doğrulayıcı', badge: '🔍', can: ['view_dashboard', 'view_fleet', 'view_report', 'export_report', 'view_audit'], color: 'purple', readOnly: true },
  company_admin: { label: 'Şirket Yöneticisi', badge: '👑', can: ['all'], color: 'amber' },
};

const ROLE_OPTIONS = [
  { value: 'officer',        label: '⚓ Gemi Subayı' },
  { value: 'superintendent', label: '🏢 Süpervizör' },
  { value: 'auditor',        label: '🔍 Doğrulayıcı' },
  { value: 'company_admin',  label: '👑 Şirket Yöneticisi' },
];

const checkPermission = (role, action) => {
  const r = ROLES[role];
  if (!r) return false;
  if (r.can.includes('all')) return true;
  return r.can.includes(action);
};

/* ═══════════════════════════════════════════════════════════════════
   CALCULATIONS — CII, ETS, FuelEU hesaplama motoru
   ═══════════════════════════════════════════════════════════════════ */
const getEtsPhaseIn = (dateStr) => {
  const y = parseInt((dateStr || '').substring(0, 4)) || new Date().getFullYear();
  if (y < 2024) return 0.00;
  return ETS_PHASE_IN[y] !== undefined ? ETS_PHASE_IN[y] : 1.00;
};

const getZFactor = (year) => {
  const y = parseInt(year) || new Date().getFullYear();
  return CII_REDUCTION_Z[y] !== undefined ? CII_REDUCTION_Z[y] : null;
};

const getCIIGrade = (attainedCII, dwt, shipType, year) => {
  const capacity = getCIICapacity(shipType, dwt);
  const params = getCIIRefParams(shipType, dwt);
  if (!params || !capacity || !attainedCII || attainedCII <= 0)
    return { grade: '-', label: '⚠️ Veri Eksik', required: 0, boundaries: null, disclaimer: false };
  const z = getZFactor(year);
  if (z === null)
    return { grade: '?', label: '⚠️ 2031+ IMO faktör yok', required: 0, boundaries: null, disclaimer: true };
  const ciiRef = params.a * Math.pow(capacity, -params.c);
  const ciiRequired = ciiRef * (1 - z / 100);
  const bounds = { A: ciiRequired * params.d[0], B: ciiRequired * params.d[1], C: ciiRequired * params.d[2], D: ciiRequired * params.d[3] };
  let grade, label;
  if (attainedCII <= bounds.A) { grade = 'A'; label = 'A - Mükemmel'; }
  else if (attainedCII <= bounds.B) { grade = 'B'; label = 'B - İyi'; }
  else if (attainedCII <= bounds.C) { grade = 'C'; label = 'C - Hedef'; }
  else if (attainedCII <= bounds.D) { grade = 'D'; label = 'D - Riskli'; }
  else { grade = 'E'; label = 'E - Kritik'; }
  return { grade, label, required: ciiRequired, boundaries: bounds, disclaimer: false };
};

const getGradeColor = (grade) =>
  ({ A: '#16a34a', B: '#2563eb', C: '#ca8a04', D: '#ea580c', E: '#dc2626' }[grade] || '#6b7280');

const getComplianceScope = (ship) => {
  const gt = ship?.grossTonnage || 0;
  return { cii: gt >= 5000, euEts: gt >= 5000, fuelEU: gt >= 5000, gt };
};

const validateIMO = (imo) => {
  if (!imo) return { valid: true, msg: '' };
  const digits = String(imo).replace(/\D/g, '');
  if (digits.length !== 7) return { valid: false, msg: '7 hane olmalıdır' };
  if (digits[0] === '0') return { valid: false, msg: 'İlk hane 0 olamaz' };
  const weights = [7, 6, 5, 4, 3, 2];
  const sum = weights.reduce((acc, w, i) => acc + w * parseInt(digits[i]), 0);
  const check = sum % 10;
  if (check !== parseInt(digits[6])) return { valid: false, msg: `Kontrol rakamı hatalı. Beklenen: ${check}` };
  return { valid: true, msg: '' };
};

const calcEtsCO2eqForFuel = (fuelTons, fuelType, voyageYear, engineType, redCertified) => {
  const factors = FUEL_GHG_FACTORS[fuelType] || FUEL_GHG_FACTORS['HFO'];
  // DÜZELTME (v3): RED II sertifikalı biyoyakıt/RFNBO'nun yanma CO₂'si
  // EU ETS'te sıfır faktörlüdür (Dir. 2003/87/EC Annex IV — biyokütle).
  // CH₄/N₂O ve metan kaçağı fiziksel emisyon olarak sayılmaya devam eder.
  const isAlt = (FUELEU_FACTORS[fuelType]?.fuelClass || 'Fossil') !== 'Fossil';
  const co2Factor = (isAlt && redCertified) ? 0 : factors.co2;
  let cslip = 0;
  if (factors.isLNG) {
    const engKey = engineType || LNG_ENGINE_DEFAULT;
    cslip = (LNG_ENGINE_TYPES[engKey] || LNG_ENGINE_TYPES[LNG_ENGINE_DEFAULT]).cslip;
  }
  const combustedFuel = fuelTons * (1 - cslip);
  const slippedFuel = fuelTons * cslip;
  const co2 = combustedFuel * co2Factor;
  const ch4 = combustedFuel * factors.ch4 + slippedFuel;
  const n2o = combustedFuel * factors.n2o;
  let co2eq;
  if (voyageYear >= 2026) co2eq = co2 * ETS_GWP.CO2 + ch4 * ETS_GWP.CH4 + n2o * ETS_GWP.N2O;
  else co2eq = co2;
  return { co2, ch4, n2o, co2eq, fuel: fuelTons };
};

const calculateCorrectedCII_CO2 = (voyage) => {
  const fuel1 = parseFloat(voyage.fuelAmount) || 0;
  const fuel2 = parseFloat(voyage.secondaryFuelAmount) || 0;
  // DÜZELTME: IMO CII takvim yılındaki TÜM yakıt tüketimini kapsar (liman dahil).
  // Liman yakıtı önceden hesaba katılmıyordu → CII olduğundan iyi görünüyordu.
  const portFuel = parseFloat(voyage.portFuelAmount) || 0;
  const type1 = voyage.fuelType || 'HFO';
  const type2 = voyage.secondaryFuelType;
  const factors1 = FUEL_GHG_FACTORS[type1] || FUEL_GHG_FACTORS['HFO'];
  const factors2 = type2 ? (FUEL_GHG_FACTORS[type2] || FUEL_GHG_FACTORS['HFO']) : null;
  const rawCO2g = ((fuel1 + portFuel) * factors1.co2 + (type2 && fuel2 > 0 ? fuel2 * factors2.co2 : 0)) * 1_000_000;
  const fcDed  = (parseFloat(voyage.fcVoyageDeduction) || 0) * factors1.co2 * 1_000_000;
  const fcBoil = (parseFloat(voyage.fcBoiler)          || 0) * factors1.co2 * 1_000_000;
  const fcOth  = (parseFloat(voyage.fcOthers)          || 0) * factors1.co2 * 1_000_000;
  const fcElec = (parseFloat(voyage.fcElectrical)      || 0) * 1_000_000;
  return Math.max(0, rawCO2g - fcDed - fcBoil - fcOth - fcElec);
};

const calcWtWIntensity = (fuelType, gwpVersion, engineType) => {
  const f = FUELEU_FACTORS[fuelType];
  if (!f) return 0;
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  const cslip = resolveCslip(fuelType, engineType);
  const combustion = (1 - cslip) * (f.cfCO2 * gwp.CO2 + f.cfCH4 * gwp.CH4 + f.cfN2O * gwp.N2O);
  const slip = cslip * gwp.CH4;
  const wtT = f.wtT !== null ? f.wtT : 0;
  return wtT + (combustion + slip) / f.lcv;
};

const getFuelEUTarget = (year) => {
  const y = parseInt(year) || 2025;
  if (y >= 2050) return FUELEU_TARGETS[2050];
  if (y >= 2045) return FUELEU_TARGETS[2045];
  if (y >= 2040) return FUELEU_TARGETS[2040];
  if (y >= 2035) return FUELEU_TARGETS[2035];
  if (y >= 2030) return FUELEU_TARGETS[2030];
  return FUELEU_TARGETS[2025];
};

/* ═══ FuelEU v3 — Reg. (EU) 2023/1805 tam uyumlu hesap ═══
   Düzeltmeler:
   1. Rapor yılı filtresi: eski kod TÜM yılların seferlerini tek yılın
      hedefine karşı topluyordu (Md. 4: yıllık ortalama yoğunluk).
   2. Sertifikalı biyoyakıt/RFNBO: yanma CO₂'si biyojenik = 0 sayılır,
      WtT sertifikadaki E-değerinden gelir (Annex I / RED II).
   3. Sertifikasız biyoyakıt/RFNBO: "en olumsuz fosil yol" = WtW 94 g/MJ
      fosil karşılaştırıcısı uygulanır (Annex II dipnotu).
   4. Ceza formülü Annex IV: bölen HEDEF değil GERÇEKLEŞEN yoğunluktur.
   5. RFNBO ödül çarpanı ×2 (2025–2033, Md. 5) enerji paydasında.
   6. Ardışık yıl ceza artışı: n. ardışık açık yılında ×(1+(n−1)/10) (Md. 23). */
const FOSSIL_COMPARATOR_WTW = 94.0; // gCO2eq/MJ — RED II fosil karşılaştırıcısı
const RFNBO_REWARD_START = 2025, RFNBO_REWARD_END = 2033;
// Sertifika E-değeri girilmezse kullanılacak TİPİK varsayılanlar (gCO2eq/MJ).
// UYARI: Resmi hesapta RED II Sürdürülebilirlik Kanıtı'ndaki (PoS) gerçek
// değer girilmelidir; bunlar yalnızca planlama için makul yer tutuculardır.
const WTT_CERT_DEFAULTS = {
  'Biodiesel': 16.0, 'HVO': 16.0, 'Bio-LNG': 14.0, 'Bio-Methanol': 10.0,
  'Ethanol': 25.0, 'Bio-H2': 10.0,
  'e-Diesel': 12.0, 'e-Methanol': 10.0, 'e-LNG': 12.0, 'e-H2': 3.6, 'e-NH3': 5.0,
};
const fuelClassOf = (fType) => FUELEU_FACTORS[fType]?.fuelClass || 'Fossil';

// Tek raporlama yılı için çekirdek hesap (ceza çarpanı hariç)
const computeFuelEUYear = (yearVoyages, ship, reportYear, gwpVersion) => {
  if (!yearVoyages || yearVoyages.length === 0) return null;
  const scope = getComplianceScope(ship);
  if (!scope.fuelEU) return null;
  const yr = parseInt(reportYear) || 2025;
  const target = getFuelEUTarget(reportYear);
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  const fuelAgg = {};
  let totalEnergyInScope = 0, totalWtTEmissions = 0, totalTtWEmissions = 0;
  let rfnboRewardApplied = false;
  const engineType = ship?.engineType || LNG_ENGINE_DEFAULT;

  const processFuelEntry = (fuelMassTons, fType, scopeRate, portFuelTons, certified, wtTCertRaw) => {
    const f = FUELEU_FACTORS[fType];
    if (!f) return;
    const portScopeRate = scopeRate > 0 ? 1.0 : 0; // AB temaslı rota → liman %100
    const inScopeMassTons = fuelMassTons * scopeRate + portFuelTons * portScopeRate;
    if (inScopeMassTons <= 0) return;
    const cls = f.fuelClass;
    const isAlt = cls !== 'Fossil';
    const cslip = resolveCslip(fType, engineType);
    const grams = inScopeMassTons * 1e6;
    const energyMJ = grams * f.lcv;
    // Yanma CO₂: sertifikalı bio/RFNBO'da biyojenik → 0; aksi halde fosil eşdeğeri
    const cfCO2eff = (isAlt && certified) ? 0 : f.cfCO2;
    const combustionPerGram = (1 - cslip) * (cfCO2eff * gwp.CO2 + f.cfCH4 * gwp.CH4 + f.cfN2O * gwp.N2O);
    const slipPerGram = cslip * gwp.CH4;
    const ttWEmissions = grams * (combustionPerGram + slipPerGram);
    // WtT g/MJ:
    let wtTperMJ;
    if (!isAlt) wtTperMJ = f.wtT !== null && f.wtT !== undefined ? f.wtT : 0;
    else if (certified) {
      const certVal = parseFloat(wtTCertRaw);
      wtTperMJ = Number.isFinite(certVal) && certVal >= 0 ? certVal : (WTT_CERT_DEFAULTS[fType] ?? 20);
    } else {
      // Sertifikasız: toplam WtW tam 94 g/MJ olacak şekilde tamamla
      const ttWIntensity = energyMJ > 0 ? ttWEmissions / energyMJ : 0;
      wtTperMJ = Math.max(0, FOSSIL_COMPARATOR_WTW - ttWIntensity);
    }
    const wtTEmissions = energyMJ * wtTperMJ;
    // RFNBO ödül çarpanı yalnızca sertifikalı RFNBO'da, 2025–2033
    const rewardMult = (cls === 'RFNBO' && certified && yr >= RFNBO_REWARD_START && yr <= RFNBO_REWARD_END) ? 2 : 1;
    if (rewardMult === 2) rfnboRewardApplied = true;
    totalEnergyInScope += energyMJ * rewardMult;
    totalWtTEmissions += wtTEmissions;
    totalTtWEmissions += ttWEmissions;
    const key = fType + (isAlt ? (certified ? ' (RED II ✓)' : ' (sertifikasız)') : '');
    if (!fuelAgg[key]) fuelAgg[key] = { baseFuel: fType, massTons: 0, energyMJ: 0, wtT: 0, ttW: 0, certified: !!certified, rewardMult, wtw: 0 };
    fuelAgg[key].massTons += inScopeMassTons;
    fuelAgg[key].energyMJ += energyMJ;
    fuelAgg[key].wtT += wtTEmissions;
    fuelAgg[key].ttW += ttWEmissions;
  };

  yearVoyages.forEach(v => {
    const scopeRate = FUELEU_SCOPE_RATES[v.routeType] || 0;
    const primaryFuel = parseFloat(v.fuelAmount) || 0;
    const portFuel = parseFloat(v.portFuelAmount) || 0;
    const primaryType = v.fuelType || 'HFO';
    processFuelEntry(primaryFuel, primaryType, scopeRate, portFuel, !!v.redCertified, v.wtTCert);
    const secFuel = parseFloat(v.secondaryFuelAmount) || 0;
    const secType = v.secondaryFuelType;
    if (secType && secFuel > 0) processFuelEntry(secFuel, secType, scopeRate, 0, !!v.secondaryRedCertified, v.secondaryWtTCert);
  });

  if (totalEnergyInScope === 0) return null;
  Object.values(fuelAgg).forEach(a => { a.wtw = a.energyMJ > 0 ? (a.wtT + a.ttW) / a.energyMJ : 0; });
  const ghgIntensity = (totalWtTEmissions + totalTtWEmissions) / totalEnergyInScope;
  const complianceBalance = (target.limit - ghgIntensity) * totalEnergyInScope;
  const complianceBalanceTons = complianceBalance / 1000000;
  let penaltyBase = 0, nonCompliantVLSFOTons = 0;
  if (complianceBalance < 0 && ghgIntensity > 0) {
    // Annex IV: Ceza = |CB| / (GHGIE_gerçekleşen × 41.000) × 2.400 €
    nonCompliantVLSFOTons = Math.abs(complianceBalance) / (ghgIntensity * FUELEU_VLSFO_LCV_PER_TON);
    penaltyBase = nonCompliantVLSFOTons * FUELEU_PENALTY_PER_TON_VLSFO;
  }
  return { target, fuelAgg, totalEnergyInScope, totalWtTEmissions, totalTtWEmissions, ghgIntensity, complianceBalance, complianceBalanceTons, isCompliant: complianceBalance >= 0, nonCompliantVLSFOTons, penaltyBase, rfnboRewardApplied, reportYear };
};

// Dış API (imza değişmedi): tüm sefer listesi verilir, yıl filtresi içeride yapılır,
// ardışık yıl ceza çarpanı önceki yılların verisinden hesaplanır.
const calculateFuelEUCompliance = (voyages, ship, reportYear, gwpVersion) => {
  if (!voyages || voyages.length === 0) return null;
  const yearOf = (v) => (v.date || '').substring(0, 4);
  const res = computeFuelEUYear(voyages.filter(v => yearOf(v) === String(reportYear)), ship, reportYear, gwpVersion);
  if (!res) return null;
  // Ardışık açık yılı sayısı (Md. 23(2)): mevcut yıl dahil geriye doğru
  let consecutiveDeficitYears = res.isCompliant ? 0 : 1;
  if (!res.isCompliant) {
    for (let y = parseInt(reportYear) - 1; y >= 2025; y--) {
      const prev = computeFuelEUYear(voyages.filter(v => yearOf(v) === String(y)), ship, String(y), gwpVersion);
      if (prev && !prev.isCompliant) consecutiveDeficitYears++;
      else break;
    }
  }
  const penaltyMultiplier = consecutiveDeficitYears > 1 ? 1 + (consecutiveDeficitYears - 1) / 10 : 1;
  const penalty = res.penaltyBase * penaltyMultiplier;
  return { ...res, penalty, penaltyMultiplier, consecutiveDeficitYears };
};

const REF_LCV = FUELEU_FACTORS['HFO'].lcv;

const calculateFuelAmount = (distance, dwt, shipType, fuelType, customDailyFuel, speedOverride) => {
  const d = parseFloat(distance) || 0;
  const w = parseFloat(dwt) || 0;
  const profile = SHIP_PROFILES[shipType];
  if (!d || !profile) return 0;
  const daily = parseFloat(customDailyFuel) || profile.dailyFuel;
  const speed = parseFloat(speedOverride) || profile.defaultSpeed;
  const effectiveFuelPerNm = daily / (speed * 24);
  const dwtFactor = (w > 0 && profile.refDWT > 0) ? Math.pow(w / profile.refDWT, 2 / 3) : 1;
  const fuelLCV = (FUELEU_FACTORS[fuelType] || FUELEU_FACTORS['HFO']).lcv;
  return effectiveFuelPerNm * dwtFactor * (REF_LCV / fuelLCV) * d;
};

const calculateVoyageEmissions = (voyage, ship, carbonPrice) => {
  const distance = parseFloat(voyage.distance) || 0;
  const voyageYear = parseInt(voyage.date?.substring(0, 4)) || 2024;
  const engineType = ship?.engineType || LNG_ENGINE_DEFAULT;
  const fuel1 = parseFloat(voyage.fuelAmount) || 0;
  const type1 = voyage.fuelType || 'HFO';
  const r1 = calcEtsCO2eqForFuel(fuel1, type1, voyageYear, engineType, !!voyage.redCertified);
  const fuel2 = parseFloat(voyage.secondaryFuelAmount) || 0;
  const type2 = voyage.secondaryFuelType;
  const r2 = (type2 && fuel2 > 0)
    ? calcEtsCO2eqForFuel(fuel2, type2, voyageYear, engineType, !!voyage.secondaryRedCertified)
    : { co2: 0, ch4: 0, n2o: 0, co2eq: 0, fuel: 0 };
  // DÜZELTME: Liman yakıtı ETS ve toplamlarda hiç sayılmıyordu (eksik beyan riski).
  // EU ETS'te AB limanındaki rıhtım emisyonları %100 kapsamdadır (Dir. 2003/87/EC Md. 3ga);
  // AB temaslı rotalarda (AB içi / Yarı AB) liman yakıtına tam oran uygulanır.
  const portFuel = parseFloat(voyage.portFuelAmount) || 0;
  const rPort = portFuel > 0
    ? calcEtsCO2eqForFuel(portFuel, type1, voyageYear, engineType, !!voyage.redCertified)
    : { co2: 0, ch4: 0, n2o: 0, co2eq: 0, fuel: 0 };
  const totalFuel = r1.fuel + r2.fuel + rPort.fuel;
  const totalCO2 = r1.co2 + r2.co2 + rPort.co2;
  const totalCO2eq = r1.co2eq + r2.co2eq + rPort.co2eq;
  const routeRate = ROUTE_ETS_RATES[voyage.routeType] || 0;
  const portEtsRate = voyage.routeType === 'AB dışı' ? 0 : 1.0;
  const phaseIn = getEtsPhaseIn(voyage.date);
  const scope = getComplianceScope(ship);
  const liableEmission = scope.euEts
    ? (((r1.co2eq + r2.co2eq) * routeRate + rPort.co2eq * portEtsRate) * phaseIn)
    : 0;
  /* DÜZELTME (v4.1): "carbonPrice || 84" deseni fiyat 0 girildiğinde sessizce
     84'e dönüyordu (0 falsy) — maliyeti sıfır fiyatla görmek imkânsızdı. */
  const effCarbonPrice = Number.isFinite(parseFloat(carbonPrice)) ? parseFloat(carbonPrice) : 84;
  const carbonCost = liableEmission * effCarbonPrice;
  const capDWT = getCIICapacity(ship?.type, ship?.capacityDWT || parseFloat(voyage.dwt) || 0);
  const factors1 = FUEL_GHG_FACTORS[type1] || FUEL_GHG_FACTORS['HFO'];
  const factors2 = type2 ? (FUEL_GHG_FACTORS[type2] || FUEL_GHG_FACTORS['HFO']) : null;
  const correctedCO2g = calculateCorrectedCII_CO2(voyage);
  const fi = (voyage.stsSts && ship?.type === 'Tanker') ? 0.97 : 1.0;
  const contributingAER = (capDWT && distance && fi) ? correctedCO2g / (fi * capDWT * distance) : 0;
  let riskStatus = '⚪ Veri bekleniyor...';
  if (totalFuel > 0) {
    if (carbonCost > 500000) riskStatus = '🔴 KRİTİK';
    else if (carbonCost > 200000) riskStatus = '🟠 UYARI';
    else if (carbonCost > 0) riskStatus = '🟢 OPTİMUM';
    else if (phaseIn === 0) riskStatus = '⚪ ETS öncesi';
    else riskStatus = '⚪ AB dışı';
  }
  const totalCH4 = r1.ch4 + r2.ch4 + rPort.ch4;
  const totalN2O = r1.n2o + r2.n2o + rPort.n2o;
  const engCslip = (LNG_ENGINE_TYPES[engineType] || LNG_ENGINE_TYPES[LNG_ENGINE_DEFAULT]).cslip;
  const slippedCH4 = (factors1.isLNG ? fuel1 * engCslip : 0)
                   + (factors2?.isLNG ? fuel2 * engCslip : 0);
  return {
    totalCO2, totalCO2eq, totalCH4, totalN2O, slippedCH4,
    liableEmission, carbonCost, contributingAER, riskStatus,
    fuel: totalFuel, phaseIn, voyageYear, engineType,
    fuelBreakdown: {
      primary: { type: type1, amount: fuel1, co2: r1.co2, ch4: r1.ch4, n2o: r1.n2o, co2eq: r1.co2eq },
      secondary: (type2 && fuel2 > 0) ? { type: type2, amount: fuel2, co2: r2.co2, ch4: r2.ch4, n2o: r2.n2o, co2eq: r2.co2eq } : null,
    },
  };
};

const computeSummary = (fleet, voyages, selectedShip, carbonPrice, gwpVersion) => {
  const ship = fleet.find(s => s.id === selectedShip);
  const sv = voyages.filter(v => v.shipId === selectedShip);
  const empty = { totalCO2: 0, totalCO2eq: 0, totalCost: 0, totalDistance: 0, totalFuel: 0, avgCII: 0, ciiDWT: 0, overallCIIResult: { grade: '-', label: 'Veri yok', required: 0, boundaries: null, disclaimer: false }, voyageCount: 0, euCost: 0, halfEuCost: 0, monthlyData: [], routeBreakdown: [], latestYear: new Date().getFullYear().toString() };
  if (!ship || sv.length === 0) return empty;
  let totalCO2 = 0, totalCO2eq = 0, totalCost = 0, totalDistance = 0, totalFuel = 0;
  let dwtDistSum = 0, euCost = 0, halfEuCost = 0, correctedCO2gSum = 0;
  const monthlyMap = {}, routeMap = { 'AB içi': 0, 'Yarı AB': 0, 'AB dışı': 0 };
  // DÜZELTME (v3): CII takvim yılı bazlı bir göstergedir. Eski kod tüm yılların
  // seferlerini tek havuzda toplayıp son yılın hedefine göre notluyordu.
  // Artık CII yalnızca son raporlama yılının seferlerinden hesaplanır;
  // maliyet/emisyon toplamları ise tüm veriyi kapsamaya devam eder.
  const latestDate = sv.reduce((mx, v) => ((v.date || '') > mx ? v.date : mx), '');
  const latestYear = latestDate.substring(0, 4) || new Date().getFullYear().toString();
  const ciiCapacity = getCIICapacity(ship.type, ship.capacityDWT || 0);
  sv.forEach(v => {
    const r = calculateVoyageEmissions(v, ship, carbonPrice);
    const dist = parseFloat(v.distance) || 0;
    const dwt = parseFloat(v.dwt) || 0;
    totalCO2 += r.totalCO2;
    totalCO2eq += r.totalCO2eq;
    totalCost += r.carbonCost;
    totalDistance += dist;
    totalFuel += r.fuel;
    if (v.routeType === 'AB içi') euCost += r.carbonCost;
    else if (v.routeType === 'Yarı AB') halfEuCost += r.carbonCost;
    const m = (v.date || '').substring(0, 7) || 'Bilinmiyor';
    if (!monthlyMap[m]) monthlyMap[m] = { month: m, co2: 0, cost: 0 };
    monthlyMap[m].co2 += r.totalCO2;
    monthlyMap[m].cost += r.carbonCost;
    if (routeMap[v.routeType] === undefined) routeMap[v.routeType] = 0;
    routeMap[v.routeType] += r.totalCO2;
    // CII: yalnızca son raporlama yılı + sınırlı kapasite + STS fi tutarlılığı
    if ((v.date || '').startsWith(latestYear)) {
      const fi = (v.stsSts && ship.type === 'Tanker') ? 0.97 : 1.0;
      const cap = ciiCapacity || getCIICapacity(ship.type, dwt);
      dwtDistSum += cap * dist;
      correctedCO2gSum += calculateCorrectedCII_CO2(v) / fi;
    }
  });
  const avgCII = dwtDistSum > 0 ? correctedCO2gSum / dwtDistSum : 0;
  const ciiDWT = ship.capacityDWT || (totalDistance > 0 ? dwtDistSum / totalDistance : 0);
  const overallCIIResult = getCIIGrade(avgCII, ciiDWT, ship.type, latestYear);
  return { totalCO2, totalCO2eq, totalCost, totalDistance, totalFuel, avgCII, ciiDWT, overallCIIResult, euCost, halfEuCost, voyageCount: sv.length, monthlyData: Object.values(monthlyMap).sort((a, b) => a.month.localeCompare(b.month)), routeBreakdown: Object.entries(routeMap).filter(([, v]) => v > 0).map(([name, value]) => ({ name, value: Math.round(value) })), latestYear };
};

/* ═══════════════════════════════════════════════════════════════════
   v4 — OPTİMİZASYON MOTORU (hız / yakıt / maliyet)
   Model: günlük tüketim ∝ hız³ (küp yasası), referans = gemi profili.
   Mevcut calculateFuelAmount ile TAM tutarlıdır: referans hızda ikisi
   birebir aynı yakıtı verir (birim testiyle doğrulanır).
   ═══════════════════════════════════════════════════════════════════ */
const computeSpeedSweep = (params) => {
  const {
    shipType, dwt, engineType, fuelType = 'HFO', distance, routeType = 'AB içi',
    year = 2026, fuelPrice = 500, carbonPrice = 84, dayCost = 0,
    dailyFuelOverride, redCertified = false,
  } = params || {};
  const profile = SHIP_PROFILES[shipType];
  const d = parseFloat(distance) || 0;
  if (!profile || d <= 0) return null;
  const vRef = profile.defaultSpeed;
  const ovr = parseFloat(dailyFuelOverride);
  const dailyRef = ovr > 0 ? ovr : profile.dailyFuel;
  const w = parseFloat(dwt) || 0;
  const dwtFactor = (w > 0 && profile.refDWT > 0) ? Math.pow(w / profile.refDWT, 2 / 3) : 1;
  const lcvRatio = REF_LCV / ((FUELEU_FACTORS[fuelType] || FUELEU_FACTORS['HFO']).lcv);
  const routeRate = ROUTE_ETS_RATES[routeType] !== undefined ? ROUTE_ETS_RATES[routeType] : 0;
  const yr = parseInt(year) || 2026;
  const phaseIn = getEtsPhaseIn(String(yr) + '-06-15');
  const capacity = getCIICapacity(shipType, w) || w;
  const fp = Math.max(0, parseFloat(fuelPrice) || 0);
  const cp = Math.max(0, parseFloat(carbonPrice) || 0);
  const dc = Math.max(0, parseFloat(dayCost) || 0);
  const points = [];
  const vMin = Math.max(6, Math.round(vRef * 0.6 * 4) / 4);
  const vMax = Math.round(vRef * 1.1 * 4) / 4;
  for (let v = vMin; v <= vMax + 1e-9; v += 0.25) {
    const speed = Math.round(v * 100) / 100;
    const days = d / (speed * 24);
    const dailyAtV = dailyRef * Math.pow(speed / vRef, 3);
    const fuelTons = dailyAtV * days * dwtFactor * lcvRatio;
    const em = calcEtsCO2eqForFuel(fuelTons, fuelType, yr, engineType, redCertified);
    const etsCost = em.co2eq * routeRate * phaseIn * cp;
    const fuelCost = fuelTons * fp;
    const timeCost = days * dc;
    const total = fuelCost + etsCost + timeCost;
    const aer = (capacity > 0 && d > 0) ? (em.co2 * 1e6) / (capacity * d) : 0;
    points.push({ speed, days, fuelTons, co2: em.co2, co2eq: em.co2eq, fuelCost, etsCost, timeCost, total, aer });
  }
  if (points.length === 0) return null;
  let best = points[0];
  points.forEach(p => { if (p.total < best.total - 1e-9) best = p; });
  const base = points.reduce((acc, p) => (Math.abs(p.speed - vRef) < Math.abs(acc.speed - vRef) ? p : acc), points[0]);
  return { points, best, base, vRef, dailyRef, dwtFactor, phaseIn, routeRate };
};

/* Aynı sefer enerjisi için alternatif yakıt karşılaştırması.
   Enerji eşdeğerliği: ton_alt = E(MJ) / (1e6 × LCV_alt) — enerji korunur.
   FuelEU WtW: fosilde Annex II; sertifikalı bio/RFNBO'da yanma CO₂'si
   biyojenik (0) + tipik sertifika WtT (yer tutucu, PoS değeriyle değiştirin);
   sertifikasızda mevzuat gereği 94 gCO₂eq/MJ fosil karşılaştırıcısı. */
const OPT_FUEL_DEFAULT_PRICES = {
  'HFO': 480, 'VLSFO': 540, 'MGO': 720, 'LNG': 560, 'Methanol': 420,
  'Biodiesel': 1150, 'HVO': 1450, 'Bio-Methanol': 900, 'e-Methanol': 1600,
};
const compareFuelsAtEnergy = (params) => {
  const {
    baseFuelType = 'HFO', baseFuelTons = 0, year = 2026, engineType,
    routeType = 'AB içi', carbonPrice = 84, gwpVersion, priceMap = {},
    redCertifiedAlt = true,
  } = params || {};
  const baseF = FUELEU_FACTORS[baseFuelType] || FUELEU_FACTORS['HFO'];
  const energyMJ = (parseFloat(baseFuelTons) || 0) * 1e6 * baseF.lcv;
  if (energyMJ <= 0) return [];
  const routeRate = ROUTE_ETS_RATES[routeType] !== undefined ? ROUTE_ETS_RATES[routeType] : 0;
  const yr = parseInt(year) || 2026;
  const phaseIn = getEtsPhaseIn(String(yr) + '-06-15');
  const limit = getFuelEUTarget(yr).limit;
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  return Object.keys(OPT_FUEL_DEFAULT_PRICES).map(ft => {
    const f = FUELEU_FACTORS[ft];
    const tons = energyMJ / (1e6 * f.lcv);
    const isAlt = f.fuelClass !== 'Fossil';
    const cert = isAlt && !!redCertifiedAlt;
    const em = calcEtsCO2eqForFuel(tons, ft, yr, engineType, cert);
    const etsCost = em.co2eq * routeRate * phaseIn * (parseFloat(carbonPrice) || 0);
    let wtw;
    if (!isAlt) {
      wtw = calcWtWIntensity(ft, gwpVersion, engineType);
    } else if (cert) {
      const cslip = resolveCslip(ft, engineType);
      const comb = (1 - cslip) * (f.cfCH4 * gwp.CH4 + f.cfN2O * gwp.N2O); // yanma CO₂ biyojenik → 0
      wtw = (WTT_CERT_DEFAULTS[ft] !== undefined ? WTT_CERT_DEFAULTS[ft] : 20) + (comb + cslip * gwp.CH4) / f.lcv;
    } else {
      wtw = FOSSIL_COMPARATOR_WTW;
    }
    const price = Number.isFinite(parseFloat(priceMap[ft])) ? parseFloat(priceMap[ft]) : OPT_FUEL_DEFAULT_PRICES[ft];
    const fuelCost = tons * price;
    return {
      fuelType: ft, name: f.name, fuelClass: f.fuelClass, tons, co2eq: em.co2eq,
      etsCost, fuelCost, total: fuelCost + etsCost, wtw,
      fuelEUCompliant: wtw <= limit + 1e-9, fuelEULimit: limit, certified: cert, price,
    };
  }).sort((a, b) => a.total - b.total);
};

/* ═══════════════════════════════════════════════════════════════════
   v4 — KARBON PORTFÖYÜ (ağırlıklı ortalama maliyet yöntemi)
   Kayıtlar tarih + oluşturma sırasına göre işlenir; satışta gerçekleşen
   K/Z = adet × (satış fiyatı − o anki ortalama maliyet).
   ═══════════════════════════════════════════════════════════════════ */
const computePortfolioPositions = (transactions, latestPrices) => {
  const lp = latestPrices || {};
  const txs = [...(transactions || [])].sort((a, b) =>
    ((a.date || '') + '#' + (a.createdAt || '')).localeCompare((b.date || '') + '#' + (b.createdAt || '')));
  const pos = {};
  let realizedTotal = 0;
  const errors = [];
  txs.forEach(t => {
    const q = parseFloat(t.quantity) || 0;
    const p = parseFloat(t.unitPrice) || 0;
    if (q <= 0 || !t.instrument) return;
    if (!pos[t.instrument]) pos[t.instrument] = { instrument: t.instrument, qty: 0, cost: 0, realized: 0, boughtQty: 0, soldQty: 0 };
    const s = pos[t.instrument];
    if (t.side === 'buy') {
      s.qty += q; s.cost += q * p; s.boughtQty += q;
    } else if (t.side === 'sell') {
      const avg = s.qty > 0 ? s.cost / s.qty : 0;
      const sellQ = Math.min(q, s.qty);
      if (q > s.qty + 1e-9) errors.push(`${t.instrument}: eldekinden fazla satış kaydı (${q} > ${s.qty.toFixed(2)})`);
      const gain = sellQ * (p - avg);
      s.realized += gain; realizedTotal += gain;
      s.cost -= sellQ * avg; s.qty -= sellQ; s.soldQty += sellQ;
      if (s.qty < 1e-9) { s.qty = 0; s.cost = 0; }
    }
  });
  const positions = Object.values(pos).map(s => {
    const avgCost = s.qty > 0 ? s.cost / s.qty : 0;
    const last = parseFloat(lp[s.instrument]);
    const hasPrice = Number.isFinite(last);
    return {
      ...s, avgCost,
      lastPrice: hasPrice ? last : null,
      marketValue: hasPrice ? s.qty * last : null,
      unrealized: hasPrice ? s.qty * (last - avgCost) : null,
    };
  }).sort((a, b) => a.instrument.localeCompare(b.instrument));
  return { positions, realizedTotal, errors };
};

/* ═══════════════════════════════════════════════════════════════════
   v4 — ERP / MUHASEBE FİŞ SATIRLARI (evrensel dışa aktarım)
   Tekdüzen hesap planına göre ŞABLON kodlar (770/373) — kendi hesap
   planınıza göre CSV içinde değiştirilebilir. Borç = Alacak dengesi
   birim testiyle doğrulanır.
   ═══════════════════════════════════════════════════════════════════ */
const buildErpJournalRows = ({ ship, reportYear, etsLiableTons, carbonPrice, fuelEUPenalty }) => {
  const rows = [];
  const date = `${reportYear}-12-31`;
  const docBase = String(ship && (ship.imoNumber || ship.name) || 'GEMI').replace(/[^\p{L}\p{N}-]+/gu, '-');
  const doc = `SCP-${reportYear}-${docBase}`;
  const r2 = (x) => Math.round((parseFloat(x) || 0) * 100) / 100;
  const etsAmount = r2((parseFloat(etsLiableTons) || 0) * (parseFloat(carbonPrice) || 0));
  if (etsAmount > 0) {
    rows.push({ date, doc, account: '770.10', accountName: 'EU ETS Emisyon Gideri', desc: `${(ship && ship.name) || ''} ${reportYear} ETS tahakkuku — ${(parseFloat(etsLiableTons) || 0).toFixed(2)} t × €${carbonPrice}`, debit: etsAmount, credit: 0 });
    rows.push({ date, doc, account: '373.10', accountName: 'EU ETS Yükümlülük Karşılığı', desc: `${(ship && ship.name) || ''} ${reportYear} ETS karşılığı`, debit: 0, credit: etsAmount });
  }
  const pen = r2(fuelEUPenalty);
  if (pen > 0) {
    rows.push({ date, doc, account: '770.11', accountName: 'FuelEU Maritime Ceza Gideri', desc: `${(ship && ship.name) || ''} ${reportYear} FuelEU ceza tahakkuku`, debit: pen, credit: 0 });
    rows.push({ date, doc, account: '373.11', accountName: 'FuelEU Ceza Karşılığı', desc: `${(ship && ship.name) || ''} ${reportYear} FuelEU karşılığı`, debit: 0, credit: pen });
  }
  return rows;
};

const csvEscape = (v) => {
  const s = String(v === null || v === undefined ? '' : v);
  return /[;"\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
const rowsToCsv = (headers, rows) =>
  '\uFEFF' + [headers, ...rows].map(r => r.map(csvEscape).join(';')).join('\r\n');
/*__END_PURE__*/

/* ═══════════════════════════════════════════════════════════════════
   GERÇEK API İSTEMCİSİ — AWS Backend
   ship-carbon-pro-fixed.jsx içindeki "MOCK API" bloğunun
   (yaklaşık 439–737. satırlar: "MOCK API" yorumundan `const api = {...}`
   tanımının sonuna kadar) YERİNE bu bloğu yapıştırın.
   UI kodunun kullandığı `api` ve `clearAuthToken` isimleri korunmuştur.
   ═══════════════════════════════════════════════════════════════════ */

// SAM deploy çıktısındaki ApiUrl değerini buraya girin:
const API_BASE_URL = 'https://XXXXXXXXXX.execute-api.eu-central-1.amazonaws.com';

const TOKEN_KEY = 'scp:jwt';

const memStore = {};
const safeGet = (k) => {
  try { return localStorage.getItem(k); }
  catch { return memStore[k] !== undefined ? memStore[k] : null; }
};
const safeSet = (k, v) => {
  try { localStorage.setItem(k, v); } catch { memStore[k] = v; }
};
const safeRemove = (k) => {
  try { localStorage.removeItem(k); } catch { delete memStore[k]; }
};

const getToken = () => safeGet(TOKEN_KEY);
const setToken = (t) => (t ? safeSet(TOKEN_KEY, t) : safeRemove(TOKEN_KEY));

const clearAuthToken = () => setToken(null);

/* Oturum düşünce (401) tüm uygulamanın haberdar olması için event yayınla */
const notifyUnauthorized = () => {
  try { window.dispatchEvent(new CustomEvent('scp:unauthorized')); } catch {}
};

async function apiRequest(method, path, body = null) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  // Token yokken sunucuya gereksiz session çağrısı yapma (mock davranış paritesi)
  if (!token && path === '/auth/session') return null;

  let res;
  try {
    res = await fetch(`${API_BASE_URL}${path}`, {
      method,
      headers,
      body: body != null ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error('Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edin.');
  }

  let data = null;
  try { data = await res.json(); } catch { /* boş yanıt */ }

  if (!res.ok) {
    if (res.status === 401) {
      clearAuthToken();
      if (path !== '/auth/login' && path !== '/auth/session') notifyUnauthorized();
    }
    throw new Error(data?.message || `Sunucu hatası (${res.status})`);
  }

  // Login/register yanıtındaki tokeni sakla
  if (data?.token && (path === '/auth/login' || path === '/auth/register')) {
    setToken(data.token);
  }
  if (path === '/auth/logout') clearAuthToken();

  return data;
}

const api = {
  get:    (path)       => apiRequest('GET', path),
  post:   (path, body) => apiRequest('POST', path, body),
  put:    (path, body) => apiRequest('PUT', path, body),
  delete: (path)       => apiRequest('DELETE', path),
};

/* NOT: 'GET /auth/session' artık sunucudan JWT ile doğrulanır.
   Uygulama açılışında token varsa oturum otomatik geri yüklenir;
   token yoksa sunucu 401 döner ve login ekranı gösterilir.
   Mock'taki seedDemoDataIfEmpty kaldırıldı — ilk şirketi
   "Kayıt Ol" sekmesinden oluşturun. */

/* ═══════════════════════════════════════════════════════════════════
   HOOKS
   ═══════════════════════════════════════════════════════════════════ */
function useAuth() {
  const [session, setSession] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get('/auth/session');
        if (res?.session && res?.company) { setSession(res.session); setCompany(res.company); }
      } catch {}
      finally { setLoading(false); }
    })();
  }, []);

  // JWT süresi dolduğunda (herhangi bir istekte 401) otomatik login ekranına dön
  useEffect(() => {
    const onUnauthorized = () => {
      setSession(null); setCompany(null);
      setError('Oturum süreniz doldu, lütfen tekrar giriş yapın.');
    };
    window.addEventListener('scp:unauthorized', onUnauthorized);
    return () => window.removeEventListener('scp:unauthorized', onUnauthorized);
  }, []);

  const fetchCompanies = useCallback(async () => {
    try {
      const res = await api.get('/auth/companies');
      setCompanies(res?.companies || []);
      return res?.companies || [];
    } catch (e) { setError(e.message); return []; }
  }, []);

  const login = useCallback(async (data) => {
    setError(''); setLoading(true);
    try {
      const res = await api.post('/auth/login', data);
      setSession(res.session); setCompany(res.company);
      return res;
    } catch (e) { setError(e.message); throw e; }
    finally { setLoading(false); }
  }, []);

  const register = useCallback(async (data) => {
    setError(''); setLoading(true);
    try {
      const res = await api.post('/auth/register', data);
      setSession(res.session); setCompany(res.company);
      return res;
    } catch (e) { setError(e.message); throw e; }
    finally { setLoading(false); }
  }, []);

  const logout = useCallback(async () => {
    try { await api.post('/auth/logout'); } catch {}
    clearAuthToken();
    setSession(null); setCompany(null);
  }, []);

  const changePin = useCallback(async (oldPin, newPin) => api.post('/auth/change-pin', { oldPin, newPin }), []);

  return { session, company, companies, loading, error, isAuthenticated: !!session, login, register, logout, fetchCompanies, changePin, setError };
}

function useShips() {
  const [fleet, setFleet] = useState([]);
  const [selectedShip, setSelectedShip] = useState('');
  const fetchFleet = useCallback(async () => {
    try {
      const res = await api.get('/ships');
      const ships = res?.ships || [];
      setFleet(ships);
      setSelectedShip(prev => prev || (ships[0]?.id || ''));
      return ships;
    } catch { return []; }
  }, []);
  const addShip = useCallback(async (data) => {
    const res = await api.post('/ships', data);
    setFleet(prev => [...prev, res.ship]);
    setSelectedShip(prev => prev || res.ship.id);
    return res.ship;
  }, []);
  const currentShip = fleet.find(s => s.id === selectedShip) || null;
  return { fleet, setFleet, selectedShip, setSelectedShip, currentShip, fetchFleet, addShip };
}

function useVoyages() {
  const [voyages, setVoyages] = useState([]);
  const fetchVoyages = useCallback(async () => {
    try { const res = await api.get('/voyages'); const v = res?.voyages || []; setVoyages(v); return v; }
    catch { return []; }
  }, []);
  const addVoyage = useCallback(async (data) => {
    const res = await api.post('/voyages', data);
    setVoyages(prev => [...prev, res.voyage]);
    return res.voyage;
  }, []);
  const updateVoyage = useCallback(async (id, updates) => {
    const res = await api.put(`/voyages/${id}`, updates);
    setVoyages(prev => prev.map(v => v.id === id ? { ...v, ...res.voyage } : v));
    return res.voyage;
  }, []);
  const deleteVoyage = useCallback(async (id) => {
    await api.delete(`/voyages/${id}`);
    setVoyages(prev => prev.filter(v => v.id !== id));
  }, []);
  return { voyages, setVoyages, fetchVoyages, addVoyage, updateVoyage, deleteVoyage };
}

function useBDN() {
  const [bdnList, setBdnList] = useState([]);
  const fetchBDN = useCallback(async () => {
    try { const res = await api.get('/bdn'); const list = res?.bdnList || []; setBdnList(list); return list; }
    catch { return []; }
  }, []);
  const addBDN = useCallback(async (data) => {
    const res = await api.post('/bdn', data);
    setBdnList(prev => [...prev, res.bdn]);
    return res.bdn;
  }, []);
  const verifyBDN = useCallback(async (id) => {
    const res = await api.put(`/bdn/${id}/verify`);
    setBdnList(prev => prev.map(b => b.id === id ? { ...b, isVerified: true, verifiedBy: res.verifiedBy, verifiedAt: res.verifiedAt } : b));
    return res;
  }, []);
  const linkBDNToVoyage = useCallback(async (bdnId, voyageId) => api.post('/bdn/link', { bdnId, voyageId }), []);
  return { bdnList, setBdnList, fetchBDN, addBDN, verifyBDN, linkBDNToVoyage };
}

function useAuditChain() {
  const [auditLog, setAuditLog] = useState([]);
  const [loading, setLoading] = useState(false);
  const fetchAuditLog = useCallback(async () => {
    try { const res = await api.get('/audit'); const log = res?.auditLog || []; setAuditLog(log); return log; }
    catch { return []; }
  }, []);
  const addLog = useCallback(async (action, entityId, details) => {
    try {
      const res = await api.post('/audit', { action, entityId, details });
      if (res?.entry) setAuditLog(prev => [res.entry, ...prev.slice(0, 499)]);
      return res?.entry;
    } catch {}
  }, []);
  const verifyChains = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get('/chain/verify');
      return { voyages: res?.voyages, bdn: res?.bdn, audit: res?.audit, checkedAt: res?.checkedAt };
    } finally { setLoading(false); }
  }, []);
  const exportAuditJSON = useCallback(() => {
    const blob = new Blob([JSON.stringify(auditLog, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `audit-export-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  }, [auditLog]);
  return { auditLog, setAuditLog, loading, fetchAuditLog, addLog, verifyChains, exportAuditJSON };
}

function useDashboard(fleet, voyages, selectedShip, carbonPrice, gwpVersion) {
  const summary = useMemo(
    () => computeSummary(fleet, voyages, selectedShip, carbonPrice, gwpVersion),
    [fleet, voyages, selectedShip, carbonPrice, gwpVersion]
  );
  const fuelEUData = useMemo(() => {
    const ship = fleet.find(s => s.id === selectedShip);
    const sv = voyages.filter(v => v.shipId === selectedShip);
    if (!ship || sv.length === 0) return null;
    const latest = sv.reduce((mx, v) => ((v.date || '') > mx ? v.date : mx), '');
    const yr = latest.substring(0, 4) || new Date().getFullYear().toString();
    return calculateFuelEUCompliance(sv, ship, yr, gwpVersion);
  }, [fleet, voyages, selectedShip, gwpVersion]);

  const runWhatIf = (type, value) => {
    let s = { ...summary };
    let desc = '';
    if (type === 'speed') {
      const pct = Math.min(Math.max(parseFloat(value) || 0, 0), 99);
      const sr = 1 - pct / 100;
      /* DÜZELTME (v4.1): Sabit MESAFELİ seferde yakıt ∝ hız² olur
         (günlük tüketim ∝ v³, seyir süresi ∝ 1/v → çarpım v²).
         Eski v³ katsayısı tasarrufu abartıyordu ve Optimizasyon
         modülündeki (doğru) modelle çelişiyordu. */
      const fr = Math.pow(sr, 2);
      s = { ...s, totalFuel: summary.totalFuel * fr, totalCO2: summary.totalCO2 * fr, totalCost: summary.totalCost * fr };
      desc = `Hız ${pct}% azaltılırsa`;
    } else if (type === 'fuel') {
      const currentEF = summary.totalFuel > 0 ? summary.totalCO2 / summary.totalFuel : 3.114;
      const newEF = FUEL_EMISSION_FACTORS[value] || 3.114;
      const ratio = newEF / currentEF;
      s = { ...s, totalCO2: summary.totalCO2 * ratio, totalCost: summary.totalCost * ratio };
      desc = value + ' yakıta geçilirse';
    } else if (type === 'route') {
      const pct = Math.min(Math.max(parseFloat(value) || 0, 0), 100);
      const euCost = summary.euCost + summary.halfEuCost;
      s = { ...s, totalCost: summary.totalCost - euCost * pct / 100 };
      desc = 'EU rotaları %' + pct + ' azaltılırsa';
    } else if (type === 'price') {
      const np = parseFloat(value) || 0;
      const ratio = carbonPrice > 0 ? np / carbonPrice : 0;
      s = { ...s, totalCost: summary.totalCost * ratio };
      desc = 'Karbon fiyatı €' + value + ' olursa';
    }
    return { desc, savings: { co2: summary.totalCO2 - s.totalCO2, cost: summary.totalCost - s.totalCost }, current: summary };
  };
  return { summary, fuelEUData, runWhatIf };
}

function useExport() {
  const downloadBlob = (content, filename, type) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  const downloadMRVXml = useCallback((ship, voyages, company, reportYear) => {
    if (!ship) return;
    const sv = voyages.filter(v => v.shipId === ship.id && v.date?.startsWith(reportYear));
    const engineType = ship?.engineType || LNG_ENGINE_DEFAULT;
    const esc = s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const fmt = (v, d = 3) => (parseFloat(v) || 0).toFixed(d);
    let totalCO2 = 0, totalCO2eq = 0, totalDist = 0, totalFuel = 0;
    sv.forEach(v => {
      const r = calculateVoyageEmissions(v, ship, 84);
      totalCO2 += r.totalCO2; totalCO2eq += r.totalCO2eq;
      totalDist += parseFloat(v.distance) || 0;
      totalFuel += r.fuel;
    });
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<EUMRVReport schemaVersion="2.0" reportingYear="${esc(reportYear)}" generatedAt="${nowIso()}">
  <ShippingCompany>
    <Name>${esc(company?.name)}</Name>
    <IMOCompanyNumber>${esc(company?.imoCompanyNo || '')}</IMOCompanyNumber>
  </ShippingCompany>
  <Ship>
    <Name>${esc(ship.name)}</Name>
    <IMONumber>${esc(ship.imoNumber || '')}</IMONumber>
    <ShipType>${esc(ship.type)}</ShipType>
    <GrossTonnage unit="GT">${ship.grossTonnage || 0}</GrossTonnage>
    <DWT unit="tonnes">${fmt(ship.capacityDWT, 0)}</DWT>
  </Ship>
  <ReportingPeriod>
    <StartDate>${reportYear}-01-01</StartDate>
    <EndDate>${reportYear}-12-31</EndDate>
  </ReportingPeriod>
  <FuelConsumption>
    <TotalConsumption unit="tonnes">${fmt(totalFuel)}</TotalConsumption>
    <TotalVoyages>${sv.length}</TotalVoyages>
  </FuelConsumption>
  <GHGEmissions>
    <CO2 unit="tonnes">${fmt(totalCO2)}</CO2>
    <TotalCO2eq unit="tonnes" gwp="AR5">${fmt(totalCO2eq)}</TotalCO2eq>
    <TotalDistance unit="nautical-miles">${fmt(totalDist, 1)}</TotalDistance>
  </GHGEmissions>
  <VerificationStatus>PENDING_VERIFICATION</VerificationStatus>
</EUMRVReport>`;
    const safeName = String(ship.name || 'ship').replace(/[^\p{L}\p{N}-]+/gu, '-').replace(/-+/g, '-');
    downloadBlob(xml, `THETIS-MRV-${safeName}-${reportYear}.xml`, 'application/xml;charset=utf-8');
  }, []);

  const exportAllData = useCallback((company, fleet, voyages, auditLog) => {
    const data = { company: { name: company.name, imoCompanyNo: company.imoCompanyNo }, fleet, voyages, auditLog, exportedAt: nowIso(), schemaVersion: '3.0-demo' };
    downloadBlob(JSON.stringify(data, null, 2), `shipcarbon-${company.name}-${Date.now()}.json`, 'application/json');
  }, []);

  /* v4 — IMO DCS (MEPC.348(78) veri alanlarına göre) yıllık bildirim taslağı.
     Sefer saatleri kayıt altında olmadığından "hours underway" profil hızından
     TAHMİNİDİR ve estimated="true" ile işaretlenir; resmi DCS'te gemi jurnal
     verisi kullanılmalıdır. */
  const downloadDCSXml = useCallback((ship, voyages, company, reportYear) => {
    if (!ship) return;
    const sv = voyages.filter(v => v.shipId === ship.id && (v.date || '').startsWith(String(reportYear)));
    const esc = s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const fmt = (v, d = 3) => (parseFloat(v) || 0).toFixed(d);
    const fuelTotals = {};
    let totalDist = 0;
    sv.forEach(v => {
      totalDist += parseFloat(v.distance) || 0;
      const t1 = v.fuelType || 'HFO';
      fuelTotals[t1] = (fuelTotals[t1] || 0) + (parseFloat(v.fuelAmount) || 0) + (parseFloat(v.portFuelAmount) || 0);
      const t2 = v.secondaryFuelType;
      const f2 = parseFloat(v.secondaryFuelAmount) || 0;
      if (t2 && f2 > 0) fuelTotals[t2] = (fuelTotals[t2] || 0) + f2;
    });
    const speed = SHIP_PROFILES[ship.type]?.defaultSpeed || 13;
    const estHours = speed > 0 ? totalDist / speed : 0;
    const fuelXml = Object.entries(fuelTotals)
      .filter(([, t]) => t > 0)
      .map(([ft, t]) => `    <FuelOilConsumption type="${esc(ft)}" unit="tonnes">${fmt(t)}</FuelOilConsumption>`)
      .join('\n');
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<IMODCSReport schemaVersion="1.0" generatedAt="${nowIso()}" tool="ShipCarbonPro">
  <Company>
    <Name>${esc(company?.name)}</Name>
    <IMOCompanyNumber>${esc(company?.imoCompanyNo || '')}</IMOCompanyNumber>
  </Company>
  <Ship>
    <Name>${esc(ship.name)}</Name>
    <IMONumber>${esc(ship.imoNumber || '')}</IMONumber>
    <ShipType>${esc(ship.type)}</ShipType>
    <GrossTonnage unit="GT">${ship.grossTonnage || 0}</GrossTonnage>
    <DWT unit="tonnes">${fmt(ship.capacityDWT, 0)}</DWT>
  </Ship>
  <Period start="${reportYear}-01-01" end="${reportYear}-12-31" />
  <Data>
${fuelXml || '    <!-- yakıt verisi yok -->'}
    <DistanceTravelled unit="nautical-miles">${fmt(totalDist, 1)}</DistanceTravelled>
    <HoursUnderway unit="hours" estimated="true" method="distance/profileSpeed">${fmt(estHours, 1)}</HoursUnderway>
    <VoyageCount>${sv.length}</VoyageCount>
  </Data>
  <Note>Karar destek taslağıdır; resmi IMO DCS bildirimi bayrak devleti/klas kuruluşu doğrulaması gerektirir. HoursUnderway tahminidir.</Note>
</IMODCSReport>`;
    const safeName = String(ship.name || 'ship').replace(/[^\p{L}\p{N}-]+/gu, '-').replace(/-+/g, '-');
    downloadBlob(xml, `IMO-DCS-${safeName}-${reportYear}.xml`, 'application/xml;charset=utf-8');
  }, []);

  /* v4 — ERP/muhasebe için yıl sonu tahakkuk fişi (CSV, ; ayraçlı + BOM:
     Türkçe bölge ayarlı Excel ile doğrudan açılır). */
  const downloadErpCsv = useCallback((ship, voyages, company, reportYear, carbonPrice, gwpVersion) => {
    if (!ship) return;
    const sv = voyages.filter(v => v.shipId === ship.id && (v.date || '').startsWith(String(reportYear)));
    let etsLiableTons = 0;
    sv.forEach(v => { etsLiableTons += calculateVoyageEmissions(v, ship, carbonPrice).liableEmission; });
    const allShipVoyages = voyages.filter(v => v.shipId === ship.id);
    const feu = calculateFuelEUCompliance(allShipVoyages, ship, String(reportYear), gwpVersion);
    const rows = buildErpJournalRows({
      ship, reportYear, etsLiableTons, carbonPrice,
      fuelEUPenalty: feu && !feu.isCompliant ? feu.penalty : 0,
    });
    const csv = rowsToCsv(
      ['Tarih', 'Belge No', 'Hesap Kodu', 'Hesap Adı', 'Açıklama', 'Borç (EUR)', 'Alacak (EUR)'],
      rows.map(r => [r.date, r.doc, r.account, r.accountName, r.desc, r.debit.toFixed(2), r.credit.toFixed(2)])
    );
    const safeName = String(ship.name || 'ship').replace(/[^\p{L}\p{N}-]+/gu, '-').replace(/-+/g, '-');
    downloadBlob(csv, `ERP-fis-${safeName}-${reportYear}.csv`, 'text/csv;charset=utf-8');
    return rows.length;
  }, []);

  return { downloadMRVXml, exportAllData, downloadDCSXml, downloadErpCsv };
}

/* ═══════════════════════════════════════════════════════════════════
   v4 HOOKS — Fiyatlar ve Karbon Portföyü
   ═══════════════════════════════════════════════════════════════════ */
function usePrices() {
  const [prices, setPrices] = useState([]);
  const fetchPrices = useCallback(async () => {
    try { const res = await api.get('/prices'); const p = res?.prices || []; setPrices(p); return p; }
    catch { return []; }
  }, []);
  const addPrice = useCallback(async (data) => {
    const res = await api.post('/prices', data);
    setPrices(prev => [res.price, ...prev]);
    return res.price;
  }, []);
  const deletePrice = useCallback(async (id) => {
    await api.delete(`/prices/${id}`);
    setPrices(prev => prev.filter(p => p.id !== id));
  }, []);
  /* Enstrüman başına en güncel fiyat (tarih, eşitse kayıt zamanı) */
  const latestByInstrument = useMemo(() => {
    const out = {};
    prices.forEach(p => {
      const cur = out[p.instrument];
      const key = (p.date || '') + '#' + (p.createdAt || '');
      const curKey = cur ? (cur.date || '') + '#' + (cur.createdAt || '') : '';
      if (!cur || key.localeCompare(curKey) > 0) out[p.instrument] = p;
    });
    return out;
  }, [prices]);
  return { prices, fetchPrices, addPrice, deletePrice, latestByInstrument };
}

function usePortfolio() {
  const [transactions, setTransactions] = useState([]);
  const fetchTransactions = useCallback(async () => {
    try { const res = await api.get('/portfolio'); const t = res?.transactions || []; setTransactions(t); return t; }
    catch { return []; }
  }, []);
  const addTransaction = useCallback(async (data) => {
    const res = await api.post('/portfolio', data);
    setTransactions(prev => [...prev, res.transaction]);
    return res.transaction;
  }, []);
  const deleteTransaction = useCallback(async (id) => {
    await api.delete(`/portfolio/${id}`);
    setTransactions(prev => prev.filter(t => t.id !== id));
  }, []);
  return { transactions, fetchTransactions, addTransaction, deleteTransaction };
}

/* ═══════════════════════════════════════════════════════════════════
   COMPONENTS
   ═══════════════════════════════════════════════════════════════════ */

function AuthScreen({ auth }) {
  const { login, register, fetchCompanies, companies, loading, error, setError } = auth;
  const [tab, setTab] = useState('login');
  const [loginCid, setLoginCid] = useState('');
  const [loginName, setLoginName] = useState('');
  const [loginRole, setLoginRole] = useState('superintendent');
  const [loginPin, setLoginPin] = useState('');
  const [regName, setRegName] = useState('');
  const [regImo, setRegImo] = useState('');
  const [regCountry, setRegCountry] = useState('');
  const [regUserName, setRegUserName] = useState('');
  const [regPin, setRegPin] = useState('');
  const [regPin2, setRegPin2] = useState('');

  useEffect(() => { fetchCompanies(); }, [tab, fetchCompanies]);
  useEffect(() => { if (companies.length > 0 && !loginCid) setLoginCid(companies[0].id); }, [companies, loginCid]);

  const handleLogin = async () => {
    setError('');
    if (!loginCid) return setError('Şirket seçiniz.');
    if (!loginName.trim()) return setError('Adınızı giriniz.');
    if (!loginPin || loginPin.length < 4) return setError('En az 4 haneli PIN giriniz.');
    try { await login({ companyId: loginCid, userName: loginName.trim(), role: loginRole, pin: loginPin }); } catch {}
  };

  const handleRegister = async () => {
    setError('');
    if (!regName.trim()) return setError('Şirket adı zorunludur.');
    if (!regUserName.trim()) return setError('Adınızı giriniz.');
    if (!regPin || regPin.length < 4) return setError('En az 4 haneli PIN giriniz.');
    if (regPin !== regPin2) return setError("PIN'ler eşleşmiyor.");
    try { await register({ companyName: regName.trim(), imoCompanyNo: regImo.trim(), country: regCountry.trim(), userName: regUserName.trim(), pin: regPin }); } catch {}
  };

  const iC = "w-full bg-slate-800/80 border border-slate-600/60 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none transition-colors";
  const tabBtn = (t, l) => (
    <button onClick={() => { setTab(t); setError(''); }} className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${tab === t ? 'bg-cyan-500 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>{l}</button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-[#0a1628] to-blue-950 text-white flex items-center justify-center p-4">
      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-3">
            <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-2xl shadow-lg shadow-cyan-500/20"><Ship className="w-8 h-8 text-white" /></div>
            <div className="text-left"><h1 className="text-2xl font-bold tracking-tight">Ship Carbon Pro</h1><p className="text-cyan-400 text-xs font-medium tracking-widest uppercase">Multi-Company Fleet Platform</p></div>
          </div>
        </div>
        <div className="flex bg-slate-800/60 rounded-xl p-1 mb-6 border border-slate-700/50">{tabBtn('login', 'Giriş Yap')}{tabBtn('register', 'Yeni Şirket Kaydı')}</div>
        <div className="bg-slate-800/40 backdrop-blur-xl rounded-2xl border border-slate-700/50 p-6 shadow-2xl">
          <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-3 mb-4 text-cyan-200 text-xs">
            <p className="font-semibold mb-1">☁️ Bulut Modu</p>
            <p className="text-cyan-300/80 leading-relaxed">Veriler AWS bulut altyapısında (DynamoDB) güvenle saklanır. Yeni kullanıcılar yalnızca şirket yöneticisi tarafından eklenebilir.</p>
          </div>
          {error && <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 mb-4 text-red-300 text-sm">{error}</div>}
          {tab === 'login' ? (
            <div className="space-y-4">
              <div><label className="block text-sm text-slate-300 mb-1.5">Şirket Seç</label>
                {companies.length > 0 ? (
                  <select value={loginCid} onChange={e => setLoginCid(e.target.value)} className={iC}>
                    {companies.map(c => <option key={c.id} value={c.id}>{c.name}{c.imoCompanyNo ? ` (IMO: ${c.imoCompanyNo})` : ''}</option>)}
                  </select>
                ) : <p className="text-slate-500 text-sm py-2">Henüz kayıtlı şirket yok — Kayıt olun</p>}
              </div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Adınız</label><input value={loginName} onChange={e => setLoginName(e.target.value)} className={iC} placeholder="Ahmet K." /></div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Rolünüz</label>
                <select value={loginRole} onChange={e => setLoginRole(e.target.value)} className={iC}>
                  {ROLE_OPTIONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                </select>
              </div>
              <div><label className="block text-sm text-slate-300 mb-1.5">PIN</label><input type="password" value={loginPin} onChange={e => setLoginPin(e.target.value)} className={iC} placeholder="••••" maxLength={8} /></div>
              <button onClick={handleLogin} disabled={loading || companies.length === 0} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl py-3 mt-2 disabled:opacity-50">{loading ? 'Yükleniyor...' : 'Giriş Yap'}</button>
            </div>
          ) : (
            <div className="space-y-4">
              <div><label className="block text-sm text-slate-300 mb-1.5">Şirket Adı *</label><input value={regName} onChange={e => setRegName(e.target.value)} className={iC} placeholder="Denizcilik A.Ş." /></div>
              <div><label className="block text-sm text-slate-300 mb-1.5">IMO Şirket Numarası</label><input value={regImo} onChange={e => setRegImo(e.target.value)} className={iC} placeholder="1234567" maxLength={7} /></div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Ülke</label><input value={regCountry} onChange={e => setRegCountry(e.target.value)} className={iC} placeholder="Türkiye" /></div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Adınız *</label><input value={regUserName} onChange={e => setRegUserName(e.target.value)} className={iC} placeholder="Ahmet K." /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-sm text-slate-300 mb-1.5">PIN *</label><input type="password" value={regPin} onChange={e => setRegPin(e.target.value)} className={iC} placeholder="••••" maxLength={8} /></div>
                <div><label className="block text-sm text-slate-300 mb-1.5">PIN Tekrar</label><input type="password" value={regPin2} onChange={e => setRegPin2(e.target.value)} className={iC} placeholder="••••" maxLength={8} /></div>
              </div>
              <button onClick={handleRegister} disabled={loading} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl py-3 mt-2 disabled:opacity-50">{loading ? 'Oluşturuluyor...' : 'Şirket Kaydı Oluştur'}</button>
            </div>
          )}
        </div>
        <p className="text-slate-500 text-xs text-center mt-6 max-w-sm mx-auto leading-relaxed">ℹ️ Demo ve ön analiz amaçlıdır; resmi IMO/EU ETS belgesi değildir.</p>
      </div>
    </div>
  );
}

function DashboardView({ fleet, selectedShip, voyages, currentShip, carbonPrice, summary, fuelEUData, can, onAddVoyage, onDeleteVoyage, onNavigate }) {
  const currentScope = getComplianceScope(currentShip);
  const shipVoyages = voyages.filter(v => v.shipId === selectedShip).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  return (
    <div className="space-y-6">
      {currentShip && !currentScope.euEts && <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/30 p-4 text-yellow-200 text-sm">⚠️ Bu gemi (GT: {currentScope.gt.toLocaleString()} &lt; 5 000) kapsam dışındadır.</div>}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Ship, label: 'Toplam Mesafe', value: summary.totalDistance.toLocaleString('tr-TR') + ' nm', sub: summary.voyageCount + ' sefer', g: 'from-blue-500/15 to-cyan-500/15', b: 'border-blue-500/25', ic: 'text-blue-400' },
          { icon: TrendingUp, label: 'Toplam Emisyon', value: summary.totalCO2.toLocaleString('tr-TR', { maximumFractionDigits: 0 }) + ' t', sub: 'CO₂', g: 'from-purple-500/15 to-pink-500/15', b: 'border-purple-500/25', ic: 'text-purple-400' },
          { icon: DollarSign, label: 'Karbon Maliyeti', value: '€' + (summary.totalCost / 1000).toFixed(0) + 'k', sub: 'EU ETS', g: 'from-red-500/15 to-orange-500/15', b: 'border-red-500/25', ic: 'text-red-400' },
          { icon: Activity, label: 'Ort. CII (AER)', value: summary.voyageCount > 0 ? summary.avgCII.toFixed(2) : '—', sub: summary.voyageCount === 0 ? 'Veri yok' : summary.overallCIIResult.label, g: summary.voyageCount === 0 ? 'from-slate-500/15 to-slate-500/15' : summary.overallCIIResult.grade === 'A' || summary.overallCIIResult.grade === 'B' ? 'from-green-500/15 to-emerald-500/15' : summary.overallCIIResult.grade === 'C' ? 'from-yellow-500/15 to-amber-500/15' : 'from-red-500/15 to-pink-500/15', b: summary.voyageCount === 0 ? 'border-slate-500/25' : summary.overallCIIResult.grade === 'A' || summary.overallCIIResult.grade === 'B' ? 'border-green-500/25' : summary.overallCIIResult.grade === 'C' ? 'border-yellow-500/25' : 'border-red-500/25', ic: 'text-emerald-400' },
        ].map((c, i) => { const Icon = c.icon; return <div key={i} className={`rounded-2xl p-5 border bg-gradient-to-br ${c.g} ${c.b}`}><div className="flex items-center justify-between mb-3"><Icon className={`w-7 h-7 ${c.ic}`} /><span className="text-slate-400 text-xs font-semibold">{c.sub}</span></div><p className="text-2xl font-bold">{c.value}</p><p className="text-slate-400 text-xs mt-1">{c.label}</p></div>; })}
      </div>
      {summary.voyageCount > 0 && <p className="text-slate-500 text-xs px-1">{CII_ANNUAL_DISCLAIMER}</p>}

      {(() => {
        const sv = voyages.filter(v => v.shipId === selectedShip);
        const bdnOk = sv.filter(v => v.bdnVerified).length;
        return sv.length > 0 && (
          <div className={`rounded-xl p-4 border text-sm flex items-center justify-between ${bdnOk === sv.length ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-300' : 'bg-orange-500/10 border-orange-500/25 text-orange-300'}`}>
            <div className="flex items-center gap-2">{bdnOk === sv.length ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}<span>BDN Doğrulama: {bdnOk}/{sv.length} sefer</span></div>
            {bdnOk < sv.length && can('upload_bdn') && <button onClick={() => onNavigate('bdn')} className="text-xs bg-orange-500/20 hover:bg-orange-500/30 px-3 py-1 rounded-lg font-semibold">BDN Yönet →</button>}
          </div>
        );
      })()}

      {fuelEUData && (
        <div className={`rounded-2xl p-5 border cursor-pointer hover:scale-[1.005] transition-all ${fuelEUData.isCompliant ? "bg-gradient-to-br from-emerald-500/15 to-green-500/15 border-emerald-500/25" : "bg-gradient-to-br from-red-500/15 to-orange-500/15 border-red-500/25"}`} onClick={() => can('view_report') && onNavigate('fueleu-report')}>
          <div className="flex items-center justify-between mb-2"><h3 className="text-base font-bold flex items-center gap-2"><Leaf className="w-5 h-5 text-emerald-400" />FuelEU Maritime</h3><span className={`px-3 py-1 rounded-full text-xs font-bold ${fuelEUData.isCompliant ? "bg-emerald-500/20 text-emerald-300" : "bg-red-500/20 text-red-300"}`}>{fuelEUData.isCompliant ? '✓ Uyumlu' : '✗ Uyumsuz'}</span></div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
            {[['GHG Hedef', fuelEUData.target.limit.toFixed(2), 'gCO₂eq/MJ', false], ['GHG Gerçekleşen', fuelEUData.ghgIntensity.toFixed(2), 'gCO₂eq/MJ', !fuelEUData.isCompliant], ['Uyum', (fuelEUData.complianceBalanceTons >= 0 ? '+' : '') + fuelEUData.complianceBalanceTons.toFixed(1) + ' t', fuelEUData.isCompliant ? 'Fazla' : 'Açık', !fuelEUData.isCompliant], ['Ceza', '€' + (fuelEUData.penalty / 1000).toFixed(0) + 'k', 'Tahmini', fuelEUData.penalty > 0]].map(([l, v, s, warn], i) => (<div key={i} className="text-center"><p className="text-xs text-slate-400">{l}</p><p className={`text-sm font-bold ${warn ? "text-red-400" : "text-slate-300"}`}>{v}</p><p className="text-[10px] text-slate-500">{s}</p></div>))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl p-5 border bg-slate-800/40 border-slate-700/50"><h3 className="text-lg font-bold mb-4 flex items-center gap-2"><TrendingUp className="w-5 h-5 text-cyan-400" />Aylık CO₂</h3>{summary.monthlyData.length > 0 ? <ResponsiveContainer width="100%" height={240}><AreaChart data={summary.monthlyData}><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#06b6d4" stopOpacity={0.6} /><stop offset="95%" stopColor="#06b6d4" stopOpacity={0} /></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#334155" /><XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} /><YAxis stroke="#64748b" tick={{ fontSize: 11 }} /><Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', fontSize: 12 }} /><Area type="monotone" dataKey="co2" stroke="#06b6d4" strokeWidth={2} fill="url(#cg)" /></AreaChart></ResponsiveContainer> : <div className="h-60 flex items-center justify-center text-slate-500">Henüz veri yok</div>}</div>
        <div className="rounded-2xl p-5 border bg-slate-800/40 border-slate-700/50"><h3 className="text-lg font-bold mb-4 flex items-center gap-2"><Activity className="w-5 h-5 text-cyan-400" />Rota Bazlı CO₂</h3>{summary.routeBreakdown.length > 0 ? <ResponsiveContainer width="100%" height={240}><RechartsPie><Pie data={summary.routeBreakdown} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => name + ' ' + (percent * 100).toFixed(0) + '%'} outerRadius={80} dataKey="value">{summary.routeBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /></RechartsPie></ResponsiveContainer> : <div className="h-60 flex items-center justify-center text-slate-500">Henüz veri yok</div>}</div>
      </div>

      <div className="rounded-2xl p-5 border bg-slate-800/40 border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2"><Anchor className="w-5 h-5 text-cyan-400" />Son Seferler</h3>
          {can('create_voyage') && <button onClick={onAddVoyage} className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl px-4 py-2 text-sm flex items-center gap-2"><Plus className="w-4 h-4" />Yeni Sefer</button>}
        </div>
        {shipVoyages.length > 0 ? (
          <div className="space-y-2">{shipVoyages.slice(0, 8).map(v => { const r = calculateVoyageEmissions(v, currentShip, carbonPrice); return (
            <div key={v.id} className="bg-slate-700/25 rounded-xl p-4 flex items-center gap-4 hover:bg-slate-700/40 transition-colors">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center bg-slate-600/50 text-cyan-300 font-bold text-xs flex-shrink-0">{v.fuelType}</div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{v.from || '—'} → {v.to || '—'}</p>
                <p className="text-slate-400 text-xs mt-0.5">{v.date} · {v.distance}nm · {(parseFloat(v.fuelAmount) || 0).toFixed(1)}t</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <p className="text-xs" style={{ color: r.riskStatus.startsWith('🔴') ? '#f87171' : r.riskStatus.startsWith('🟠') ? '#fb923c' : r.riskStatus.startsWith('🟢') ? '#4ade80' : '#94a3b8' }}>{r.riskStatus.split(':')[0]}</p>
                  {v.bdnVerified ? <span className="text-[10px] text-emerald-400 bg-emerald-500/15 px-1.5 py-0.5 rounded">BDN ✓</span> : <span className="text-[10px] text-orange-400 bg-orange-500/15 px-1.5 py-0.5 rounded">BDN —</span>}
                  {v.chainSeq && <span className="text-[10px] text-slate-500">#{v.chainSeq}</span>}
                </div>
              </div>
              <div className="text-right flex-shrink-0"><p className="font-bold text-sm">€{r.carbonCost.toLocaleString('tr-TR', { maximumFractionDigits: 0 })}</p><p className="text-slate-400 text-xs">{r.totalCO2.toFixed(0)} tCO₂</p></div>
              {can('delete_voyage') && <button onClick={() => onDeleteVoyage(v)} className="text-red-400/60 hover:text-red-400 flex-shrink-0"><Trash2 className="w-4 h-4" /></button>}
            </div>); })}</div>
        ) : (<div className="text-center py-16 text-slate-500"><Ship className="w-14 h-14 mx-auto mb-3 opacity-30" /><p>Henüz sefer yok</p></div>)}
      </div>
    </div>
  );
}

function FleetView({ fleet, selectedShip, setSelectedShip, voyages, carbonPrice, can, onAddShip, onNavigate }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Filo Yönetimi</h2>
        {can('create_ship') && <button onClick={onAddShip} className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl px-5 py-2.5 text-sm flex items-center gap-2"><Plus className="w-4 h-4" />Yeni Gemi</button>}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {fleet.map(ship => {
          const sv = voyages.filter(v => v.shipId === ship.id);
          const st = sv.reduce((a, v) => {
            const r = calculateVoyageEmissions(v, ship, carbonPrice);
            return { co2: a.co2 + r.totalCO2, cost: a.cost + r.carbonCost, n: a.n + 1 };
          }, { co2: 0, cost: 0, n: 0 });
          const isActive = selectedShip === ship.id;
          const sc = getComplianceScope(ship);
          return (
            <div key={ship.id} onClick={() => { setSelectedShip(ship.id); onNavigate('dashboard'); }} className={`rounded-2xl p-5 border cursor-pointer transition-all bg-slate-800/40 ${isActive ? 'border-cyan-500 shadow-lg shadow-cyan-500/10' : 'border-slate-700/50 hover:border-slate-600'}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3"><Ship className="w-7 h-7 text-cyan-400" /><div><h3 className="font-bold">{ship.name}</h3><p className="text-slate-400 text-xs">IMO: {ship.imoNumber || '—'}</p></div></div>
                {isActive && <span className="bg-cyan-500 text-white px-2 py-0.5 rounded-lg text-xs font-semibold">Aktif</span>}
              </div>
              <div className="mb-3"><span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${sc.gt >= 5000 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{sc.gt >= 5000 ? 'CII ✓ | ETS ✓ | FuelEU ✓' : 'CII — | ETS — | FuelEU —'}</span></div>
              <div className="space-y-1.5 text-sm">{[['Tip', ship.type], ['GT', (ship.grossTonnage || 0).toLocaleString()], ['DWT', (ship.capacityDWT || '—').toLocaleString() + ' t'], ['Sefer', st.n], ['Maliyet', '€' + (st.cost / 1000).toFixed(0) + 'k']].map(([k, v]) => <div key={k} className="flex justify-between"><span className="text-slate-400">{k}</span><span className="font-semibold">{v}</span></div>)}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AddShipModal({ onSave, onClose }) {
  const [form, setForm] = useState({ name: '', imoNumber: '', mmsi: '', type: 'Bulk Carrier', dailyFuel: '', capacityDWT: '', grossTonnage: '', engineType: '' });
  const [formError, setFormError] = useState('');
  const iC = "w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none";
  const imoValidation = useMemo(() => validateIMO(form.imoNumber), [form.imoNumber]);
  const u = (key, val) => { setFormError(''); setForm(prev => ({ ...prev, [key]: val })); };

  const handleSave = () => {
    if (!form.name.trim()) return setFormError('Gemi adı girin');
    if (!form.capacityDWT || parseFloat(form.capacityDWT) <= 0) return setFormError('DWT girin');
    if (form.grossTonnage && parseFloat(form.grossTonnage) < 0) return setFormError('GT negatif olamaz');
    if (form.dailyFuel && parseFloat(form.dailyFuel) < 0) return setFormError('Günlük tüketim negatif olamaz');
    if (form.imoNumber && !imoValidation.valid) return setFormError('IMO hatalı: ' + imoValidation.msg);
    if (form.mmsi && !/^\d{9}$/.test(form.mmsi)) return setFormError('MMSI 9 haneli sayı olmalı');
    const shipData = { name: form.name, imoNumber: form.imoNumber, type: form.type, capacityDWT: parseFloat(form.capacityDWT), grossTonnage: parseFloat(form.grossTonnage) || 0, active: true };
    if (form.mmsi) shipData.mmsi = form.mmsi;
    if (form.dailyFuel && parseFloat(form.dailyFuel) > 0) shipData.dailyFuel = parseFloat(form.dailyFuel);
    if (form.engineType) shipData.engineType = form.engineType;
    onSave(shipData);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl p-5 max-w-md w-full border border-slate-700 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4"><h3 className="text-lg font-bold">Yeni Gemi Ekle</h3><button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button></div>
        {formError && <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 mb-3 text-red-300 text-xs">{formError}</div>}
        <div className="space-y-3">
          <div><label className="block text-xs text-slate-300 mb-1">Gemi Adı</label><input type="text" value={form.name} onChange={e => u('name', e.target.value)} className={iC} placeholder="MV Example" /></div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">IMO Number</label>
            <input type="text" value={form.imoNumber} onChange={e => u('imoNumber', e.target.value)} className={iC + (form.imoNumber ? (imoValidation.valid ? ' !border-emerald-500' : ' !border-red-500') : '')} placeholder="9123456" maxLength={7} />
            {form.imoNumber && imoValidation.valid && <p className="text-emerald-400 text-xs mt-0.5">✓ Geçerli</p>}
            {form.imoNumber && !imoValidation.valid && <p className="text-red-400 text-xs mt-0.5">✗ {imoValidation.msg}</p>}
          </div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">MMSI <span className="text-slate-500">(AIS takibi için, isteğe bağlı)</span></label>
            <input type="text" value={form.mmsi} onChange={e => u('mmsi', e.target.value.replace(/\D/g, ''))} className={iC} placeholder="271000000" maxLength={9} />
          </div>
          <div><label className="block text-xs text-slate-300 mb-1">Tip</label><select value={form.type} onChange={e => u('type', e.target.value)} className={iC}>{Object.keys(SHIP_PROFILES).map(t => <option key={t} value={t}>{t} ({SHIP_PROFILES[t].dailyFuel} t/gün)</option>)}</select></div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">Gross Tonnage (GT)</label>
            <input type="number" value={form.grossTonnage} onChange={e => u('grossTonnage', e.target.value)} className={iC} placeholder="35000" />
            <p className="text-slate-500 text-xs mt-0.5">{parseFloat(form.grossTonnage) >= 5000 ? <span className="text-emerald-400">✓ ≥ 5000 GT — Kapsamda</span> : parseFloat(form.grossTonnage) > 0 ? <span className="text-yellow-400">⚠️ &lt; 5000 GT</span> : 'Kapsam kontrolü için'}</p>
          </div>
          <div><label className="block text-xs text-slate-300 mb-1">DWT (ton) <span className="text-red-400">*</span></label><input type="number" value={form.capacityDWT} onChange={e => u('capacityDWT', e.target.value)} className={iC} placeholder="58000" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Günlük Tüketim (ton/gün)</label><input type="number" step="0.1" value={form.dailyFuel} onChange={e => u('dailyFuel', e.target.value)} className={iC} placeholder={`Varsayılan: ${SHIP_PROFILES[form.type]?.dailyFuel}`} /></div>
          {['LNG', 'LPG'].includes(form.type) && (
            <div>
              <label className="block text-xs text-slate-300 mb-1">LNG Motor Tipi</label>
              <select value={form.engineType} onChange={e => u('engineType', e.target.value)} className={iC}>
                <option value="">Varsayılan (Otto DF Medium Speed)</option>
                {Object.entries(LNG_ENGINE_TYPES).map(([k, v]) => (<option key={k} value={k}>{v.label} — Cslip: {(v.cslip * 100).toFixed(1)}%</option>))}
              </select>
            </div>
          )}
        </div>
        <div className="flex gap-3 mt-4">
          <button onClick={handleSave} disabled={form.imoNumber && !imoValidation.valid} className={`flex-1 text-white font-semibold rounded-xl py-2.5 text-sm ${form.imoNumber && !imoValidation.valid ? 'bg-slate-600 cursor-not-allowed' : 'bg-gradient-to-r from-cyan-500 to-blue-600'}`}>Gemi Ekle</button>
          <button onClick={onClose} className="px-6 bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2.5 rounded-xl text-sm">İptal</button>
        </div>
      </div>
    </div>
  );
}

function AddVoyageModal({ currentShip, onSave, onClose }) {
  const INITIAL = { date: '', distance: '', dwt: '', routeType: 'AB içi', fuelType: 'HFO', from: '', to: '', fuelAmount: '', portFuelAmount: '', secondaryFuelType: '', secondaryFuelAmount: '', fcVoyageDeduction: '', reeferKwh: '', fcBoiler: '', fcOthers: '', stsSts: false, speedOverride: '', redCertified: false, wtTCert: '', secondaryRedCertified: false, secondaryWtTCert: '' };
  // DÜZELTME: DWT gemi kartından otomatik dolduruluyor (elle tekrar girme hatası önlenir)
  const [form, setForm] = useState({ ...INITIAL, date: new Date().toISOString().split('T')[0], dwt: currentShip?.capacityDWT ? String(currentShip.capacityDWT) : '' });
  const [showCorrectionPanel, setShowCorrectionPanel] = useState(false);
  const [formError, setFormError] = useState('');
  const iC = "w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none";

  const computedFuel = useMemo(() => {
    if (!currentShip || !form.distance) return 0;
    return calculateFuelAmount(form.distance, form.dwt, currentShip.type, form.fuelType, currentShip.dailyFuel, form.speedOverride);
  }, [form.distance, form.dwt, form.fuelType, form.speedOverride, currentShip]);

  const handleSave = () => {
    if (!currentShip) return setFormError('Önce bir gemi seçin');
    const dist = parseFloat(form.distance), dwtVal = parseFloat(form.dwt);
    if (!dist || dist <= 0) return setFormError('Geçerli bir mesafe girin (> 0 nm)');
    if (!dwtVal || dwtVal <= 0) return setFormError('Geçerli bir DWT girin (> 0 ton)');
    const today = new Date().toISOString().split('T')[0];
    if (form.date && form.date > today) return setFormError('Sefer tarihi gelecekte olamaz');
    if (form.date && form.date < '2020-01-01') return setFormError('Tarih 2020 öncesi olamaz');
    for (const [k, l] of [['fuelAmount', 'Seyir yakıtı'], ['portFuelAmount', 'Liman yakıtı'], ['secondaryFuelAmount', 'İkincil yakıt'], ['fcVoyageDeduction', 'Düşülecek yakıt'], ['fcBoiler', 'Kazan yakıtı'], ['fcOthers', 'Pompa yakıtı'], ['speedOverride', 'Hız']]) {
      if (form[k] !== '' && parseFloat(form[k]) < 0) return setFormError(`${l} negatif olamaz`);
    }
    if (form.secondaryFuelType && !(parseFloat(form.secondaryFuelAmount) > 0)) return setFormError('İkincil yakıt seçiliyse miktar girin');
    const autoFuel = calculateFuelAmount(form.distance, form.dwt, currentShip.type, form.fuelType, currentShip.dailyFuel, form.speedOverride);
    const finalFuel = form.fuelAmount ? parseFloat(form.fuelAmount) : autoFuel;
    if (!finalFuel || finalFuel <= 0) return setFormError('Yakıt hesaplanamadı — yakıt miktarı girin');
    const reeferKwh = parseFloat(form.reeferKwh) || 0;
    const fcElectrical = reeferKwh > 0 ? (reeferKwh * 200 / 1000000) : 0;
    onSave({
      date: form.date || new Date().toISOString().split('T')[0],
      distance: form.distance, dwt: form.dwt, routeType: form.routeType, fuelType: form.fuelType,
      from: form.from, to: form.to,
      fuelAmount: finalFuel.toFixed(2),
      speedKnot: form.speedOverride || '',
      portFuelAmount: form.portFuelAmount || '',
      secondaryFuelType: form.secondaryFuelType || '',
      secondaryFuelAmount: form.secondaryFuelAmount || '',
      redCertified: !!form.redCertified,
      wtTCert: form.redCertified ? (form.wtTCert || '') : '',
      secondaryRedCertified: !!form.secondaryRedCertified,
      secondaryWtTCert: form.secondaryRedCertified ? (form.secondaryWtTCert || '') : '',
      fcVoyageDeduction: form.fcVoyageDeduction || '',
      fcElectrical: fcElectrical > 0 ? fcElectrical.toFixed(4) : '',
      reeferKwh: form.reeferKwh || '',
      fcBoiler: form.fcBoiler || '', fcOthers: form.fcOthers || '',
      stsSts: form.stsSts || false,
      bdnId: null, bdnVerified: false,
    });
  };

  const u = (key, val) => { setFormError(''); setForm(prev => ({ ...prev, [key]: val })); };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl p-5 max-w-2xl w-full border border-slate-700 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4"><h3 className="text-lg font-bold">Yeni Sefer Ekle</h3><button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button></div>
        {formError && <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 mb-3 text-red-300 text-xs">{formError}</div>}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div><label className="block text-xs text-slate-300 mb-1">Tarih</label><input type="date" value={form.date} onChange={e => u('date', e.target.value)} className={iC} /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Mesafe (nm)</label><input type="number" value={form.distance} onChange={e => u('distance', e.target.value)} className={iC} placeholder="2100" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Kalkış</label><input type="text" value={form.from} onChange={e => u('from', e.target.value)} className={iC} placeholder="Rotterdam" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Varış</label><input type="text" value={form.to} onChange={e => u('to', e.target.value)} className={iC} placeholder="Singapore" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Rota</label><select value={form.routeType} onChange={e => u('routeType', e.target.value)} className={iC}><option>AB içi</option><option>Yarı AB</option><option>AB dışı</option></select></div>
          <div><label className="block text-xs text-slate-300 mb-1">Ana Yakıt</label><select value={form.fuelType} onChange={e => u('fuelType', e.target.value)} className={iC}><optgroup label="Fosil">{FUEL_CATEGORIES.Fossil.map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup><optgroup label="Biyoyakıt">{FUEL_CATEGORIES.Biofuel.map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup><optgroup label="RFNBO / e-Fuel">{FUEL_CATEGORIES.RFNBO.map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup></select></div>
          <div><label className="block text-xs text-slate-300 mb-1">DWT (ton)</label><input type="number" value={form.dwt} onChange={e => u('dwt', e.target.value)} className={iC} placeholder="58000" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">⚡ Hız (kn)</label><input type="number" step="0.1" value={form.speedOverride} onChange={e => u('speedOverride', e.target.value)} className={iC} placeholder={currentShip ? `Vars: ${SHIP_PROFILES[currentShip.type]?.defaultSpeed || '-'} kn` : '—'} /></div>
          <div className="sm:col-span-2"><label className="block text-xs text-slate-300 mb-1">Seyir Yakıtı (ton)</label><input type="number" step="0.01" value={form.fuelAmount} onChange={e => u('fuelAmount', e.target.value)} className={iC} placeholder={computedFuel > 0 ? `Otomatik: ${computedFuel.toFixed(2)}` : 'Mesafe girin...'} />{computedFuel > 0 && !form.fuelAmount && <p className="text-emerald-400 text-xs mt-0.5">Otomatik: {computedFuel.toFixed(2)} ton</p>}</div>
          <div className="sm:col-span-2"><label className="block text-xs text-slate-300 mb-1">🏭 Liman Yakıtı (ton)</label><input type="number" step="0.01" value={form.portFuelAmount} onChange={e => u('portFuelAmount', e.target.value)} className={iC} placeholder="0" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">🔄 İkincil Yakıt</label><select value={form.secondaryFuelType} onChange={e => u('secondaryFuelType', e.target.value)} className={iC}><option value="">Yok</option><optgroup label="Fosil">{FUEL_CATEGORIES.Fossil.filter(f => f !== form.fuelType).map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup><optgroup label="Biyoyakıt">{FUEL_CATEGORIES.Biofuel.filter(f => f !== form.fuelType).map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup><optgroup label="RFNBO / e-Fuel">{FUEL_CATEGORIES.RFNBO.filter(f => f !== form.fuelType).map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup></select></div>
          {form.secondaryFuelType && <div><label className="block text-xs text-slate-300 mb-1">İkincil Yakıt Miktarı (ton)</label><input type="number" step="0.01" value={form.secondaryFuelAmount} onChange={e => u('secondaryFuelAmount', e.target.value)} className={iC} placeholder="0" /></div>}
        </div>
        {(fuelClassOf(form.fuelType) !== 'Fossil' || (form.secondaryFuelType && fuelClassOf(form.secondaryFuelType) !== 'Fossil')) && (
          <div className="mt-3 bg-emerald-500/10 border border-emerald-500/25 rounded-lg p-3 space-y-2">
            <p className="text-xs font-semibold text-emerald-300">🌱 RED II Sürdürülebilirlik Sertifikası</p>
            <p className="text-[11px] text-emerald-200/60 leading-relaxed">Sertifikalı yakıtın yanma CO₂'si biyojenik sayılır ve WtT değeri sertifikadaki E-değerinden alınır. Sertifikasız biyoyakıt/RFNBO mevzuat gereği en olumsuz fosil yol (94 gCO₂eq/MJ) olarak hesaplanır.</p>
            {fuelClassOf(form.fuelType) !== 'Fossil' && (
              <div className="space-y-1.5">
                <label className="flex items-center gap-2 text-xs text-slate-200"><input type="checkbox" checked={form.redCertified} onChange={e => u('redCertified', e.target.checked)} />{FUELEU_FACTORS[form.fuelType]?.name || form.fuelType} — RED II sertifikalı (PoS mevcut)</label>
                {form.redCertified && <input type="number" step="0.1" min="0" value={form.wtTCert} onChange={e => u('wtTCert', e.target.value)} className={iC} placeholder={`Sertifika E-değeri gCO₂eq/MJ (boş: tipik ${WTT_CERT_DEFAULTS[form.fuelType] ?? 20})`} />}
              </div>
            )}
            {form.secondaryFuelType && fuelClassOf(form.secondaryFuelType) !== 'Fossil' && (
              <div className="space-y-1.5">
                <label className="flex items-center gap-2 text-xs text-slate-200"><input type="checkbox" checked={form.secondaryRedCertified} onChange={e => u('secondaryRedCertified', e.target.checked)} />{FUELEU_FACTORS[form.secondaryFuelType]?.name || form.secondaryFuelType} — RED II sertifikalı (PoS mevcut)</label>
                {form.secondaryRedCertified && <input type="number" step="0.1" min="0" value={form.secondaryWtTCert} onChange={e => u('secondaryWtTCert', e.target.value)} className={iC} placeholder={`Sertifika E-değeri gCO₂eq/MJ (boş: tipik ${WTT_CERT_DEFAULTS[form.secondaryFuelType] ?? 20})`} />}
              </div>
            )}
          </div>
        )}
        <div className="mt-3 border-t border-slate-700/50 pt-3">
          <button type="button" onClick={() => setShowCorrectionPanel(!showCorrectionPanel)} className="flex items-center gap-2 text-xs text-slate-300 hover:text-white font-semibold">
            {showCorrectionPanel ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}CII Düzeltme Faktörleri (Opsiyonel)
          </button>
          {showCorrectionPanel && (
            <div className="mt-2 space-y-2 bg-slate-700/20 rounded-lg p-3">
              <div><label className="block text-xs text-slate-400 mb-0.5">Düşülecek Yakıt (ton)</label><input type="number" step="0.01" value={form.fcVoyageDeduction} onChange={e => u('fcVoyageDeduction', e.target.value)} className={iC} placeholder="0" /></div>
              {currentShip?.type === 'Container' && <div><label className="block text-xs text-slate-400 mb-0.5">Reefer kWh</label><input type="number" value={form.reeferKwh} onChange={e => u('reeferKwh', e.target.value)} className={iC} placeholder="0" /></div>}
              {currentShip?.type === 'Tanker' && (<>
                <div><label className="block text-xs text-slate-400 mb-0.5">Kazan Yakıtı (ton)</label><input type="number" step="0.01" value={form.fcBoiler} onChange={e => u('fcBoiler', e.target.value)} className={iC} placeholder="0" /></div>
                <div><label className="block text-xs text-slate-400 mb-0.5">Pompa Yakıtı (ton)</label><input type="number" step="0.01" value={form.fcOthers} onChange={e => u('fcOthers', e.target.value)} className={iC} placeholder="0" /></div>
                <div className="flex items-center gap-2"><input type="checkbox" checked={form.stsSts} onChange={e => u('stsSts', e.target.checked)} /><label className="text-xs text-slate-300">STS (AF=0.97)</label></div>
              </>)}
            </div>
          )}
        </div>
        <div className="flex gap-3 mt-4">
          <button onClick={handleSave} className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl py-2.5 text-sm">Kaydet</button>
          <button onClick={onClose} className="px-6 bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2.5 rounded-xl text-sm">İptal</button>
        </div>
      </div>
    </div>
  );
}

function WhatIfSection({ summary, runWhatIf, whatIfScenarios, setWhatIfScenarios }) {
  const [active, setActive] = useState(null);
  const [val, setVal] = useState('');
  const scenarios = [
    { id: 'speed', title: 'Hız Azaltma', icon: TrendingDown, desc: 'Slow steaming ile yakıt tasarrufu', placeholder: '15', grad: 'from-green-500/15 to-emerald-500/15', border: 'border-green-500/25' },
    { id: 'fuel', title: 'Yakıt Değişimi', icon: Zap, desc: 'Farklı yakıt tipinin etkisi', isSelect: true, opts: ['HFO', 'VLSFO', 'MGO', 'LNG', 'Methanol'], grad: 'from-blue-500/15 to-cyan-500/15', border: 'border-blue-500/25' },
    { id: 'route', title: 'Rota Optimizasyonu', icon: Target, desc: 'EU rotalarını azaltma', placeholder: '20', grad: 'from-purple-500/15 to-pink-500/15', border: 'border-purple-500/25' },
    { id: 'price', title: 'Karbon Fiyatı', icon: DollarSign, desc: 'Gelecek fiyat senaryosu', placeholder: '100', grad: 'from-red-500/15 to-orange-500/15', border: 'border-red-500/25' },
  ];
  const calc = (id) => {
    if (!val) return;
    setWhatIfScenarios(prev => [runWhatIf(id, val), ...prev.slice(0, 4)]);
    setActive(null); setVal('');
  };
  return (
    <div className="space-y-6">
      <div className="rounded-2xl p-6 bg-gradient-to-br from-purple-500/15 to-pink-500/15 border border-purple-500/25">
        <h2 className="text-2xl font-bold flex items-center gap-3"><RefreshCw className="w-7 h-7 text-purple-400" />What-If Analiz Merkezi</h2>
        <p className="text-purple-200/80 mt-1">Farklı senaryoların finansal ve çevresel etkilerini analiz edin</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scenarios.map(s => { const Icon = s.icon; return (
          <div key={s.id} className={`rounded-2xl p-5 border bg-gradient-to-br ${s.grad} ${s.border}`}>
            <div className="flex items-center gap-3 mb-3"><div className="bg-white/10 p-2.5 rounded-xl"><Icon className="w-5 h-5" /></div><div><h3 className="font-bold">{s.title}</h3><p className="text-white/60 text-xs">{s.desc}</p></div></div>
            {active === s.id ? (
              <div className="space-y-2">
                {s.isSelect
                  ? <select value={val} onChange={e => setVal(e.target.value)} className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2.5 text-white focus:outline-none"><option value="">Seçiniz...</option>{s.opts.map(o => <option key={o} value={o}>{o}</option>)}</select>
                  : <input type="number" value={val} onChange={e => setVal(e.target.value)} placeholder={s.placeholder} className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none" />}
                <div className="flex gap-2"><button onClick={() => calc(s.id)} className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-white px-4 py-2 rounded-xl font-semibold text-sm">Hesapla</button><button onClick={() => { setActive(null); setVal(''); }} className="bg-slate-600 hover:bg-slate-500 text-white px-3 py-2 rounded-xl"><X className="w-4 h-4" /></button></div>
              </div>
            ) : <button onClick={() => setActive(s.id)} className="w-full bg-white/10 hover:bg-white/15 text-white px-4 py-2 rounded-xl font-semibold text-sm">Senaryo Çalıştır</button>}
          </div>
        ); })}
      </div>
      {whatIfScenarios.length > 0 && (
        <div className="rounded-2xl p-5 bg-slate-800/40 border border-slate-700/50 space-y-4">
          <h3 className="text-lg font-bold">Sonuçlar</h3>
          {whatIfScenarios.map((sc, i) => (
            <div key={i} className="bg-slate-700/25 rounded-xl p-5"><h4 className="font-bold mb-3">{sc.desc}</h4>
              <div className="grid grid-cols-3 gap-4">
                <div><p className="text-slate-400 text-xs mb-1">CO₂ Tasarrufu</p><p className="text-xl font-bold" style={{ color: sc.savings.co2 >= 0 ? '#4ade80' : '#f87171' }}>{sc.savings.co2 >= 0 ? '-' : '+'}{Math.abs(sc.savings.co2).toLocaleString('tr-TR', { maximumFractionDigits: 0 })} t</p></div>
                <div><p className="text-slate-400 text-xs mb-1">Maliyet Tasarrufu</p><p className="text-xl font-bold" style={{ color: sc.savings.cost >= 0 ? '#4ade80' : '#f87171' }}>{sc.savings.cost >= 0 ? '-' : '+'}€{Math.abs(sc.savings.cost).toLocaleString('tr-TR', { maximumFractionDigits: 0 })}</p></div>
                <div><p className="text-slate-400 text-xs mb-1">Değişim</p><p className="text-xl font-bold">{sc.current.totalCost > 0 ? ((sc.savings.cost / sc.current.totalCost) * 100).toFixed(1) : 0}%</p></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EtsReportView({ fleet, selectedShip, voyages, carbonPrice, company, session, downloadMRVXml }) {
  const ship = fleet.find(s => s.id === selectedShip);
  if (!ship) return <div className="text-center py-20 text-slate-500">Gemi seçiniz</div>;

  // DÜZELTME (v3): Rapor tek raporlama yılını beyan ederken toplamlar TÜM
  // yılların seferlerini içeriyordu. Önce yıl belirlenir, sonra filtrelenir.
  const svAll = voyages.filter(v => v.shipId === selectedShip).sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  const years = [...new Set(svAll.map(v => (v.date || '').substring(0, 4)))].filter(Boolean).sort();
  const reportYear = years.length > 0 ? years[years.length - 1] : new Date().getFullYear().toString();
  const sv = svAll.filter(v => (v.date || '').startsWith(reportYear));
  const rows = sv.map(v => ({ ...v, ...calculateVoyageEmissions(v, ship, carbonPrice) }));
  const totals = rows.reduce((a, r) => ({
    distance: a.distance + (parseFloat(r.distance) || 0), fuel: a.fuel + r.fuel,
    totalCO2: a.totalCO2 + r.totalCO2, totalCO2eq: a.totalCO2eq + (r.totalCO2eq || r.totalCO2),
    totalCH4: a.totalCH4 + (r.totalCH4 || 0), totalN2O: a.totalN2O + (r.totalN2O || 0),
    slippedCH4: a.slippedCH4 + (r.slippedCH4 || 0),
    liableEmission: a.liableEmission + r.liableEmission, carbonCost: a.carbonCost + r.carbonCost,
  }), { distance: 0, fuel: 0, totalCO2: 0, totalCO2eq: 0, totalCH4: 0, totalN2O: 0, slippedCH4: 0, liableEmission: 0, carbonCost: 0 });

  const avgDWT = getCIICapacity(ship?.type, ship?.capacityDWT || 0);
  const correctedCO2gReport = sv.reduce((sum, v) => {
    const fi = (v.stsSts && ship?.type === 'Tanker') ? 0.97 : 1.0;
    return sum + calculateCorrectedCII_CO2(v) / fi;
  }, 0);
  const cllDegeri = (avgDWT > 0 && totals.distance > 0) ? correctedCO2gReport / (avgDWT * totals.distance) : 0;
  const reportYearInt = parseInt(reportYear) || 2024;
  const reportCII = getCIIGrade(cllDegeri, ship?.capacityDWT || 0, ship?.type, reportYear);
  const emissionLabel = reportYearInt >= 2026 ? 'tCO₂eq' : 'tCO₂';
  const pi = getEtsPhaseIn(reportYear + '-01-01');
  const bdnVerCount = sv.filter(v => v.bdnVerified).length;
  const fmt = (n, d) => (n || 0).toLocaleString('en-US', { maximumFractionDigits: d !== undefined ? d : 0 });
  const scope = getComplianceScope(ship);
  const hasLNG = rows.some(r => isLNGTypeFuel(r.fuelType) || isLNGTypeFuel(r.secondaryFuelType));
  const engineInfo = ship?.engineType || 'Otto DF Medium Speed';
  const cslip = LNG_ENGINE_TYPES[engineInfo]?.cslip || 0.031;

  const handleThetisExport = () => { if (ship) downloadMRVXml(ship, voyages, company, reportYear); };

  const sH = "text-base font-bold text-slate-200 mt-8 mb-3 pb-1.5 border-b-2 border-cyan-500/50";
  const thC = "bg-slate-700 text-left text-xs text-slate-300 font-semibold px-3 py-2";
  const tdC = "px-3 py-2 border-b border-slate-700/40 text-sm";
  const tdL = tdC + " text-slate-400 font-semibold";
  const tdV = tdC + " font-semibold";

  return (
    <div className="space-y-6">
      <div className="rounded-2xl p-6 bg-gradient-to-br from-blue-500/15 to-indigo-500/15 border border-blue-500/25">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div><h2 className="text-2xl font-bold flex items-center gap-3"><FileText className="w-7 h-7 text-blue-400" />IMO Carbon Emission Report</h2><p className="text-blue-200/80 mt-1">IMO DCS · IMO CII · EU MRV & EU ETS Maritime</p></div>
          <button onClick={handleThetisExport} className="bg-gradient-to-r from-emerald-500 to-green-600 text-white font-semibold rounded-xl px-4 py-2.5 text-sm flex items-center gap-2"><Download className="w-4 h-4" />THETIS XML</button>
        </div>
        <div className={`mt-3 rounded-xl p-3 text-sm flex items-center gap-2 ${bdnVerCount === sv.length && sv.length > 0 ? 'bg-emerald-500/10 border border-emerald-500/25 text-emerald-300' : 'bg-orange-500/10 border border-orange-500/25 text-orange-300'}`}>
          {bdnVerCount === sv.length && sv.length > 0 ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          BDN Durumu: {bdnVerCount}/{sv.length} sefer doğrulandı
        </div>
      </div>

      {!scope.euEts && <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/30 p-4 text-yellow-200 text-sm">⚠️ GT &lt; 5 000 — kapsam dışı.</div>}

      <div className="rounded-2xl border border-slate-700/50 bg-slate-800/40">
        <div className="p-8">
          <div style={{ textAlign: 'center', marginBottom: 24 }}><h1 className="text-xl font-bold text-slate-100">IMO CARBON EMISSION REPORT</h1><p className="text-slate-400 text-sm mt-2">IMO DCS · IMO CII · EU MRV & EU ETS</p></div>

          <div className="rounded-xl bg-slate-700/30 p-4 mb-6 text-sm space-y-1">
            <div className="flex justify-between"><span className="text-slate-400">Company:</span><span className="font-semibold">{company?.name}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">IMO Co.:</span><span className="font-semibold">{company?.imoCompanyNo || '—'}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">Prepared:</span><span className="font-semibold">{session?.userName}</span></div>
          </div>

          <h2 className={sH}>1. Vessel & Reporting</h2>
          <table className="w-full text-sm"><thead><tr><th className={thC} style={{ width: '40%' }}>Item</th><th className={thC}>Value</th></tr></thead>
            <tbody>{[['Vessel', ship.name], ['IMO', ship.imoNumber || '—'], ['Type', ship.type], ['GT', (ship.grossTonnage || 0).toLocaleString() + ' GT'], ['DWT', (ship.capacityDWT || 0).toLocaleString() + ' t'], ['Year', reportYear], ['Voyages', sv.length], ['BDN Verified', bdnVerCount + '/' + sv.length]].map(([k, v]) => <tr key={k}><td className={tdL}>{k}</td><td className={tdV}>{v}</td></tr>)}</tbody>
          </table>

          <h2 className={sH}>2. Total GHG Emissions</h2>
          <div className="rounded-xl bg-cyan-500/10 border border-cyan-500/30 p-5 text-center mb-3">
            <p className="text-slate-400 text-sm">Total {emissionLabel}</p>
            <p className="text-3xl font-bold text-cyan-300 mt-2">{fmt(reportYearInt >= 2026 ? totals.totalCO2eq : totals.totalCO2, 1)} {emissionLabel}</p>
            {reportYearInt >= 2026 && <p className="text-slate-400 text-xs mt-1">CO₂: {fmt(totals.totalCO2, 1)} · CH₄: {fmt(totals.totalCH4, 3)} · N₂O: {fmt(totals.totalN2O, 4)}</p>}
          </div>

          <h2 className={sH}>3. IMO CII Rating</h2>
          <table className="w-full text-sm"><thead><tr><th className={thC} style={{ width: '50%' }}>Parameter</th><th className={thC}>Value</th></tr></thead>
            <tbody>
              <tr><td className={tdL}>Attained CII (AER)</td><td className={tdV} style={{ color: getGradeColor(reportCII.grade) }}>{cllDegeri.toFixed(4)}</td></tr>
              {reportCII.required > 0 && <tr><td className={tdL}>Required CII ({reportYear})</td><td className={tdV}>{reportCII.required.toFixed(4)}</td></tr>}
              <tr><td className={tdL}>CII Rating</td><td className={tdC}><span className="inline-block px-3 py-1 rounded-lg text-white text-sm font-bold" style={{ backgroundColor: getGradeColor(reportCII.grade) }}>{reportCII.label}</span></td></tr>
            </tbody>
          </table>

          <h2 className={sH}>4. EU ETS Cost</h2>
          <table className="w-full text-sm"><thead><tr><th className={thC} style={{ width: '50%' }}>Item</th><th className={thC}>Value</th></tr></thead>
            <tbody>{[['Total Emissions', fmt(reportYearInt >= 2026 ? totals.totalCO2eq : totals.totalCO2, 1) + ' ' + emissionLabel], ['Phase-in', (pi * 100).toFixed(0) + '%'], ['Liable Emissions', fmt(totals.liableEmission, 1) + ' ' + emissionLabel], ['Carbon Price', carbonPrice + ' EUR/' + emissionLabel], ['Estimated Cost', '€' + fmt(totals.carbonCost)]].map(([k, v]) => <tr key={k}><td className={tdL}>{k}</td><td className={tdV}>{v}</td></tr>)}</tbody>
          </table>

          {rows.length > 0 && (
            <div style={{ marginTop: 28 }}>
              <h2 className={sH}>Appendix: Voyage Details</h2>
              <div className="overflow-x-auto rounded-xl border border-slate-700/50">
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead><tr>{['#', 'Date', 'From', 'To', 'Route', 'Fuel', 'F(t)', 'CO₂(t)', 'Cost(€)', 'BDN'].map(h => <th key={h} className={thC}>{h}</th>)}</tr></thead>
                  <tbody>{rows.map((r, i) => (
                    <tr key={r.id} className="hover:bg-slate-700/20">
                      <td className={tdC + " text-slate-400"}>{i + 1}</td>
                      <td className={tdC}>{r.date}</td>
                      <td className={tdC}>{r.from || '-'}</td>
                      <td className={tdC}>{r.to || '-'}</td>
                      <td className={tdC}>{r.routeType}</td>
                      <td className={tdC}>{r.fuelType}</td>
                      <td className={tdC + " text-right"}>{fmt(parseFloat(r.fuelAmount) || 0, 2)}</td>
                      <td className={tdC + " text-right"}>{fmt(r.totalCO2, 1)}</td>
                      <td className={tdC + " text-right text-cyan-300"}>{fmt(r.carbonCost)}</td>
                      <td className={tdC + " text-center"}>{r.bdnVerified ? '✓' : '—'}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          )}

          <div className="mt-8 pt-4 border-t border-slate-700/40">
            <p className="text-slate-500 text-xs">{REPORT_FOOTER_TEXT}</p>
            <p className="text-slate-500 text-xs mt-1">{BDN_DISCLAIMER}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function FuelEUReportView({ fleet, selectedShip, voyages, gwpVersion, setGwpVersion, company, session }) {
  const ship = fleet.find(s => s.id === selectedShip);
  if (!ship) return <div className="text-center py-20 text-slate-500">Gemi seçiniz</div>;

  const sv = voyages.filter(v => v.shipId === selectedShip).sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  const years = [...new Set(sv.map(v => (v.date || '').substring(0, 4)))].filter(Boolean).sort();
  const reportYear = years.length > 0 ? years[years.length - 1] : new Date().getFullYear().toString();
  const fmt = (n, d) => (n || 0).toLocaleString('en-US', { maximumFractionDigits: d !== undefined ? d : 0 });
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  const fuelEU = calculateFuelEUCompliance(sv, ship, reportYear, gwpVersion);
  const scope = getComplianceScope(ship);
  const engineType = ship?.engineType || 'Otto DF Medium Speed';
  const cslip = LNG_ENGINE_TYPES[engineType]?.cslip || 0.031;
  const hasLNG = fuelEU && Object.values(fuelEU.fuelAgg || {}).some(d => isLNGTypeFuel(d.baseFuel));

  const sH = "text-base font-bold text-slate-200 mt-8 mb-3 pb-1.5 border-b-2 border-emerald-500/50";
  const thC = "bg-emerald-900/60 text-left text-xs text-emerald-200 font-semibold px-3 py-2";
  const tdC = "px-3 py-2 border-b border-slate-700/40 text-sm";
  const tdL = tdC + " text-slate-400 font-semibold";
  const tdV = tdC + " font-semibold";

  return (
    <div className="space-y-6">
      <div className="rounded-2xl p-6 bg-gradient-to-br from-emerald-500/15 to-green-500/15 border border-emerald-500/25">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div><h2 className="text-2xl font-bold flex items-center gap-3"><Leaf className="w-7 h-7 text-emerald-400" />FuelEU Maritime Report</h2><p className="text-emerald-200/80 mt-1">Regulation (EU) 2023/1805 · WtW GHG Intensity</p></div>
        </div>
        <div className="flex items-center gap-3 mt-3 flex-wrap">
          <span className="text-emerald-200/70 text-xs font-semibold">GWP:</span>
          {Object.entries(FUELEU_GWP_SETS).map(([key, g]) => (
            <button key={key} onClick={() => setGwpVersion(key)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${gwpVersion === key ? "bg-emerald-500 text-white" : "bg-slate-700/60 text-slate-300 hover:bg-slate-600/60"}`}>
              {key} (CH₄={g.CH4}, N₂O={g.N2O})
            </button>
          ))}
        </div>
      </div>

      {!scope.fuelEU && <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/30 p-4 text-yellow-200 text-sm">⚠️ GT &lt; 5 000 — FuelEU kapsamı dışı.</div>}

      <div className="rounded-2xl border border-slate-700/50 bg-slate-800/40">
        <div className="p-8">
          <div style={{ textAlign: 'center', marginBottom: 24 }}><h1 className="text-xl font-bold text-slate-100">FuelEU MARITIME COMPLIANCE REPORT</h1><p className="text-slate-400 text-sm mt-2">Regulation (EU) 2023/1805</p></div>

          <h2 className={sH}>1. Vessel & Reporting</h2>
          <table className="w-full text-sm"><thead><tr><th className={thC} style={{ width: '40%' }}>Item</th><th className={thC}>Description</th></tr></thead>
            <tbody>{[['Vessel', ship.name], ['IMO', ship.imoNumber || '—'], ['Type', ship.type], ['GT', (ship.grossTonnage || 0).toLocaleString()], ['Year', reportYear], ['GWP Set', gwpVersion + ' (CH₄=' + gwp.CH4 + ', N₂O=' + gwp.N2O + ')']].map(([k, v]) => <tr key={k}><td className={tdL}>{k}</td><td className={tdV}>{v}</td></tr>)}</tbody>
          </table>

          {fuelEU ? (<>
            <h2 className={sH}>2. Compliance Result</h2>
            <div className={`rounded-xl p-5 text-center mb-4 ${fuelEU.isCompliant ? 'bg-emerald-500/10 border border-emerald-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
              <p className={`text-3xl font-bold ${fuelEU.isCompliant ? 'text-emerald-300' : 'text-red-400'}`}>{fuelEU.isCompliant ? '✓ COMPLIANT' : '✗ NON-COMPLIANT'}</p>
              <p className="text-slate-400 text-sm mt-2">Attained: <span className="font-semibold">{fuelEU.ghgIntensity.toFixed(4)}</span> {fuelEU.isCompliant ? '≤' : '>'} Target: <span className="font-semibold">{fuelEU.target.limit.toFixed(4)}</span> gCO₂eq/MJ</p>
            </div>

            <h2 className={sH}>3. GHG Intensity Summary</h2>
            <table className="w-full text-sm"><thead><tr><th className={thC} style={{ width: '50%' }}>Parameter</th><th className={thC}>Value</th></tr></thead>
              <tbody>
                <tr><td className={tdL}>Reference Value</td><td className={tdV}>91.16 gCO₂eq/MJ</td></tr>
                <tr><td className={tdL}>Reduction Target ({reportYear})</td><td className={tdV}>{(fuelEU.target.reduction * 100).toFixed(1)}% ↓</td></tr>
                <tr><td className={tdL}>Target Limit</td><td className={tdV}>{fuelEU.target.limit.toFixed(4)} gCO₂eq/MJ</td></tr>
                <tr><td className={tdL}>WtW GHG Intensity</td><td className={tdV + (fuelEU.isCompliant ? ' text-emerald-300' : ' text-red-400')}>{fuelEU.ghgIntensity.toFixed(4)} gCO₂eq/MJ</td></tr>
                <tr><td className={tdL}>In-Scope Energy</td><td className={tdV}>{fmt(fuelEU.totalEnergyInScope)} MJ</td></tr>
              </tbody>
            </table>

            <h2 className={sH}>4. Fuel Breakdown</h2>
            <div className="overflow-x-auto rounded-xl border border-slate-700/50">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>{['Fuel', 'Mass (t)', 'Energy (MJ)', '% Total', 'WtW Intensity'].map(h => <th key={h} className={thC}>{h}</th>)}</tr></thead>
                <tbody>
                  {Object.entries(fuelEU.fuelAgg).map(([ft, d]) => {
                    const f = FUELEU_FACTORS[d.baseFuel || ft];
                    const isAltFuel = f && f.fuelClass !== 'Fossil';
                    const pctEnergy = (d.energyMJ / fuelEU.totalEnergyInScope * 100);
                    return (
                      <tr key={ft}>
                        <td className={tdV}>{f?.name || ft}{isAltFuel && <span className={`ml-1.5 text-[10px] px-1.5 py-0.5 rounded ${d.certified ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>{d.certified ? 'RED II ✓' : 'sertifikasız → 94'}</span>}{d.rewardMult === 2 && <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300">×2</span>}<div className="text-xs text-slate-500 font-normal">Class: {f?.fuelClass || '—'}</div></td>
                        <td className={tdC + ' text-right'}>{fmt(d.massTons, 2)}</td>
                        <td className={tdC + ' text-right'}>{fmt(d.energyMJ)}</td>
                        <td className={tdC + ' text-right'}>{pctEnergy.toFixed(1)}%</td>
                        <td className={tdC + ' text-right font-semibold ' + (d.wtw <= fuelEU.target.limit ? 'text-emerald-300' : 'text-red-400')}>{d.wtw.toFixed(4)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <h2 className={sH}>5. Compliance Balance & Penalty</h2>
            <table className="w-full text-sm"><thead><tr><th className={thC} style={{ width: '55%' }}>Parameter</th><th className={thC}>Value</th></tr></thead>
              <tbody>
                <tr><td className={tdL}>Compliance Balance (tons)</td><td className={tdV + (fuelEU.isCompliant ? ' text-emerald-300' : ' text-red-400')}>{fuelEU.complianceBalanceTons >= 0 ? '+' : ''}{fmt(fuelEU.complianceBalanceTons, 2)} tCO₂eq</td></tr>
                {!fuelEU.isCompliant && <tr><td className={tdL}>Non-compliant VLSFO-eq</td><td className={tdV}>{fmt(fuelEU.nonCompliantVLSFOTons, 2)} t</td></tr>}
                {fuelEU.penaltyMultiplier > 1 && <tr><td className={tdL}>Ardışık Yıl Çarpanı (Md. 23/2)</td><td className={tdV + ' text-red-400'}>×{fuelEU.penaltyMultiplier.toFixed(1)} ({fuelEU.consecutiveDeficitYears}. ardışık açık yılı)</td></tr>}
                {fuelEU.rfnboRewardApplied && <tr><td className={tdL}>RFNBO Ödül Çarpanı (Md. 5)</td><td className={tdV + ' text-emerald-300'}>×2 (2025–2033 sertifikalı RFNBO enerjisi)</td></tr>}
                <tr><td className={tdL}>Penalty (Article 23)</td><td className={tdV + (fuelEU.penalty > 0 ? ' text-red-400 font-bold' : ' text-emerald-300')}>€{fmt(fuelEU.penalty)}</td></tr>
              </tbody>
            </table>
          </>) : (
            <div className="rounded-xl bg-slate-700/20 p-8 text-center mt-6"><AlertCircle className="w-14 h-14 mx-auto mb-3 text-slate-500 opacity-30" /><p className="text-slate-500">{!scope.fuelEU ? 'GT < 5 000 — kapsam dışı.' : 'AB içi/Yarı AB sefer ekleyin.'}</p></div>
          )}

          <div className="mt-8 pt-4 border-t border-slate-700/40">
            <p className="text-slate-500 text-xs">{REPORT_FOOTER_TEXT}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function BDNView({ bdn, fleet, voyages, can, onRefreshVoyages }) {
  const { bdnList, addBDN, verifyBDN } = bdn;
  const [showAdd, setShowAdd] = useState(false);
  const [filterShip, setFilterShip] = useState('all');
  const [form, setForm] = useState({ shipId: '', voyageId: '', fuelType: 'HFO', quantityTonnes: '', deliveryDate: '', supplierName: '', deliveryPort: '' });
  const [error, setError] = useState('');

  const shipVoyages = form.shipId ? voyages.filter(v => v.shipId === form.shipId) : [];

  const handleAdd = async () => {
    setError('');
    if (!form.fuelType || !form.quantityTonnes || !form.deliveryDate) return setError('Yakıt, miktar ve tarih zorunlu.');
    if (!(parseFloat(form.quantityTonnes) > 0)) return setError('Miktar 0\'dan büyük olmalı.');
    if (form.deliveryDate > new Date().toISOString().split('T')[0]) return setError('Teslimat tarihi gelecekte olamaz.');
    try {
      await addBDN({ shipId: form.shipId || null, voyageId: form.voyageId || null, fuelType: form.fuelType, quantityTonnes: parseFloat(form.quantityTonnes), deliveryDate: form.deliveryDate, supplierName: form.supplierName, deliveryPort: form.deliveryPort });
      setForm({ shipId: '', voyageId: '', fuelType: 'HFO', quantityTonnes: '', deliveryDate: '', supplierName: '', deliveryPort: '' });
      setShowAdd(false);
    } catch (e) { setError(e.message); }
  };

  const handleVerify = async (id) => {
    try {
      await verifyBDN(id);
      if (onRefreshVoyages) await onRefreshVoyages();
    } catch (e) { setError(e.message); }
  };

  const filtered = bdnList.filter(b => filterShip === 'all' || b.shipId === filterShip);
  const iC = "w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none text-sm";

  return (
    <div className="space-y-6">
      <div className="rounded-2xl p-6 bg-gradient-to-br from-orange-500/15 to-amber-500/15 border border-orange-500/25">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-3"><FileText className="w-7 h-7 text-orange-400" />BDN Yönetimi</h2>
            <p className="text-orange-200/70 mt-1">Bunker Delivery Note — Yakıt belgeleri</p>
          </div>
          {can('upload_bdn') && <button onClick={() => setShowAdd(true)} className="bg-gradient-to-r from-orange-500 to-amber-600 text-white font-semibold rounded-xl px-4 py-2.5 text-sm flex items-center gap-2"><Plus className="w-4 h-4" />BDN Ekle</button>}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[['Toplam', bdnList.length, 'bg-orange-500/10 border-orange-500/25'], ['Doğrulanmış', bdnList.filter(b => b.isVerified).length, 'bg-emerald-500/10 border-emerald-500/25'], ['Bekleyen', bdnList.filter(b => !b.isVerified).length, 'bg-yellow-500/10 border-yellow-500/25']].map(([l, v, cls]) => (
          <div key={l} className={`rounded-xl p-4 border text-center ${cls}`}>
            <p className="text-2xl font-bold">{v}</p><p className="text-xs text-slate-400 mt-1">{l}</p>
          </div>
        ))}
      </div>

      <select value={filterShip} onChange={e => setFilterShip(e.target.value)} className="bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2 text-sm text-white focus:outline-none">
        <option value="all">Tüm Gemiler</option>
        {fleet.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
      </select>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-slate-500"><FileText className="w-12 h-12 mx-auto mb-3 opacity-30" /><p>Henüz BDN kaydı yok</p></div>
        ) : filtered.map(b => {
          const ship = fleet.find(s => s.id === b.shipId);
          return (
            <div key={b.id} className="bg-slate-800/40 rounded-xl border border-slate-700/50 p-4">
              <div className="flex items-start justify-between flex-wrap gap-2">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold ${b.isVerified ? 'bg-emerald-500/20 text-emerald-300' : 'bg-orange-500/20 text-orange-300'}`}>{b.fuelType}</div>
                  <div>
                    <p className="font-semibold">{b.fuelType} — {b.quantityTonnes} t</p>
                    <p className="text-slate-400 text-xs">{b.deliveryDate} · {b.deliveryPort || '—'} · {b.supplierName || '—'}</p>
                    {ship && <p className="text-cyan-400 text-xs mt-0.5">⚓ {ship.name}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {b.isVerified ? (
                    <span className="flex items-center gap-1 bg-emerald-500/20 text-emerald-300 px-3 py-1 rounded-lg text-xs font-semibold"><CheckCircle className="w-3 h-3" />Doğrulandı</span>
                  ) : (
                    <>
                      <span className="flex items-center gap-1 bg-orange-500/20 text-orange-300 px-3 py-1 rounded-lg text-xs font-semibold"><AlertCircle className="w-3 h-3" />Bekliyor</span>
                      {can('verify_bdn') && <button onClick={() => handleVerify(b.id)} className="bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-semibold px-3 py-1 rounded-lg">Onayla</button>}
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowAdd(false)}>
          <div className="bg-slate-800 rounded-2xl p-6 max-w-lg w-full border border-slate-700 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6"><h3 className="text-xl font-bold">BDN Ekle</h3><button onClick={() => setShowAdd(false)} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button></div>
            {error && <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 mb-4 text-red-300 text-sm">{error}</div>}
            <div className="space-y-4">
              <div><label className="block text-sm text-slate-300 mb-1.5">Gemi</label>
                <select value={form.shipId} onChange={e => setForm({ ...form, shipId: e.target.value, voyageId: '' })} className={iC}>
                  <option value="">Gemi seçiniz...</option>{fleet.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              {form.shipId && (
                <div><label className="block text-sm text-slate-300 mb-1.5">Bağlanacak Sefer (opsiyonel)</label>
                  <select value={form.voyageId} onChange={e => setForm({ ...form, voyageId: e.target.value })} className={iC}>
                    <option value="">Sefere bağlama</option>
                    {shipVoyages.map(v => <option key={v.id} value={v.id}>{v.date} · {v.from || '—'} → {v.to || '—'} ({v.fuelType})</option>)}
                  </select>
                  <p className="text-slate-500 text-xs mt-1">BDN doğrulandığında bağlı seferin BDN durumu otomatik güncellenir.</p>
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-sm text-slate-300 mb-1.5">Yakıt Tipi *</label>
                  <select value={form.fuelType} onChange={e => setForm({ ...form, fuelType: e.target.value })} className={iC}>
                    <optgroup label="Fosil">{FUEL_CATEGORIES.Fossil.map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup>
                    <optgroup label="Biyoyakıt">{FUEL_CATEGORIES.Biofuel.map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup>
                    <optgroup label="RFNBO / e-Fuel">{FUEL_CATEGORIES.RFNBO.map(f => <option key={f} value={f}>{FUELEU_FACTORS[f]?.name || f}</option>)}</optgroup>
                  </select>
                </div>
                <div><label className="block text-sm text-slate-300 mb-1.5">Miktar (ton) *</label><input type="number" step="0.001" value={form.quantityTonnes} onChange={e => setForm({ ...form, quantityTonnes: e.target.value })} className={iC} placeholder="350.0" /></div>
              </div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Teslimat Tarihi *</label><input type="date" value={form.deliveryDate} onChange={e => setForm({ ...form, deliveryDate: e.target.value })} className={iC} /></div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Tedarikçi</label><input value={form.supplierName} onChange={e => setForm({ ...form, supplierName: e.target.value })} className={iC} placeholder="Marine Fuels Ltd." /></div>
              <div><label className="block text-sm text-slate-300 mb-1.5">Teslimat Limanı</label><input value={form.deliveryPort} onChange={e => setForm({ ...form, deliveryPort: e.target.value })} className={iC} placeholder="Rotterdam" /></div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={handleAdd} className="flex-1 bg-gradient-to-r from-orange-500 to-amber-600 text-white font-semibold rounded-xl py-3">Kaydet</button>
              <button onClick={() => setShowAdd(false)} className="px-6 bg-slate-700 text-white font-semibold py-3 rounded-xl">İptal</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AuditTrailView({ audit, company }) {
  const { auditLog, verifyChains, exportAuditJSON, loading: chainLoading } = audit;
  const [filter, setFilter] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [chainResult, setChainResult] = useState(null);
  const PER_PAGE = 50;
  const [visibleCount, setVisibleCount] = useState(PER_PAGE);

  const filtered = useMemo(() => {
    let list = auditLog || [];
    if (actionFilter !== 'all') list = list.filter(e => (e.action || '').startsWith(actionFilter));
    if (filter) list = list.filter(e => ((e.user || '') + (e.details || '') + (e.action || '')).toLowerCase().includes(filter.toLowerCase()));
    return list;
  }, [auditLog, filter, actionFilter]);

  // Filtre değişince sayfalamayı sıfırla
  useEffect(() => { setVisibleCount(PER_PAGE); }, [filter, actionFilter]);

  const pageItems = filtered.slice(0, visibleCount);

  const actionColor = (a) => {
    if (a?.startsWith('CREATE')) return 'text-emerald-400 bg-emerald-500/15';
    if (a?.startsWith('DELETE')) return 'text-red-400 bg-red-500/15';
    if (a?.startsWith('UPDATE')) return 'text-yellow-400 bg-yellow-500/15';
    if (a === 'LOGIN') return 'text-blue-400 bg-blue-500/15';
    return 'text-slate-400 bg-slate-500/15';
  };

  const handleChainVerify = async () => {
    try { setChainResult(await verifyChains()); } catch (e) { console.error(e); }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl p-6 bg-gradient-to-br from-violet-500/15 to-purple-500/15 border border-violet-500/25">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div><h2 className="text-2xl font-bold flex items-center gap-3"><Shield className="w-7 h-7 text-violet-400" />Denetim İzi — {company?.name}</h2></div>
          <div className="flex gap-2">
            <button onClick={handleChainVerify} disabled={chainLoading} className="bg-violet-500 hover:bg-violet-400 text-white font-semibold rounded-xl px-4 py-2 text-sm disabled:opacity-50">{chainLoading ? '...' : '🔐 Zincir Doğrula'}</button>
            <button onClick={exportAuditJSON} className="bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-sm text-slate-300 hover:text-white">⬇ JSON</button>
          </div>
        </div>
      </div>

      {chainResult && (
        <div className={`rounded-xl p-4 border ${chainResult.audit?.valid !== false ? 'bg-emerald-500/10 border-emerald-500/25' : 'bg-red-500/10 border-red-500/25'}`}>
          {chainResult.audit?.valid !== false ? (
            <p className="text-emerald-300 font-semibold">✓ Denetim zinciri bütünlüklü — {chainResult.audit?.total || 0} kayıt doğrulandı.</p>
          ) : (
            <p className="text-red-300 font-semibold">✗ Zincir ihlali: Seq #{chainResult.audit?.brokenAt?.seq}</p>
          )}
        </div>
      )}

      <div className="flex flex-wrap gap-3 items-center">
        <select value={actionFilter} onChange={e => setActionFilter(e.target.value)} className="bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2 text-sm text-white focus:outline-none">
          <option value="all">Tümü</option><option value="CREATE">Oluşturma</option><option value="DELETE">Silme</option><option value="LOGIN">Giriş</option>
        </select>
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Ara..." className="w-full bg-slate-700/50 border border-slate-600 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none" />
        </div>
      </div>

      <div className="rounded-xl border border-slate-700/50 overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="bg-slate-700/40">{['Tarih', 'Kullanıcı', 'İşlem', 'Detay'].map(h => <th key={h} className="text-left px-4 py-2.5 text-xs text-slate-400 font-semibold">{h}</th>)}</tr></thead>
          <tbody>
            {pageItems.length === 0 ? <tr><td colSpan={4} className="px-4 py-12 text-center text-slate-500">Kayıt bulunamadı</td></tr> : pageItems.map(e => (
              <tr key={e.id} className="border-t border-slate-700/30 hover:bg-slate-700/20">
                <td className="px-4 py-2.5 text-slate-400 text-xs whitespace-nowrap">{e.ts?.substring(0, 16).replace('T', ' ')}</td>
                <td className="px-4 py-2.5 font-semibold text-sm">{e.user}</td>
                <td className="px-4 py-2.5"><span className={`px-2 py-0.5 rounded text-xs font-semibold ${actionColor(e.action)}`}>{e.action}</span></td>
                <td className="px-4 py-2.5 text-slate-400 text-xs truncate max-w-[300px]">{e.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {filtered.length > visibleCount && (
        <button onClick={() => setVisibleCount(c => c + PER_PAGE)} className="w-full bg-slate-700/40 hover:bg-slate-700/60 border border-slate-600/50 rounded-xl py-2.5 text-sm text-slate-300 font-semibold">
          Daha fazla göster ({filtered.length - visibleCount} kayıt kaldı)
        </button>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   KULLANICI YÖNETİMİ — yalnızca company_admin
   (Girişte otomatik hesap oluşturma güvenlik nedeniyle kaldırıldı;
   yeni kullanıcılar buradan eklenir.)
   ═══════════════════════════════════════════════════════════════════ */
function UserManagementModal({ session, onClose }) {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ userName: '', role: 'officer', pin: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const iC = "w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none";

  const load = useCallback(async () => {
    try { const res = await api.get('/users'); setUsers(res?.users || []); }
    catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const handleAdd = async () => {
    setError('');
    if (!form.userName.trim()) return setError('Kullanıcı adı girin.');
    if (!form.pin || form.pin.length < 4) return setError('PIN en az 4 hane.');
    setBusy(true);
    try {
      await api.post('/users', { userName: form.userName.trim(), role: form.role, pin: form.pin });
      setForm({ userName: '', role: 'officer', pin: '' });
      await load();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  const handleDelete = async (u) => {
    setError('');
    try {
      await api.delete(`/users/${encodeURIComponent(u.userName)}/${encodeURIComponent(u.role)}`);
      await load();
    } catch (e) { setError(e.message); }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl p-5 max-w-lg w-full border border-slate-700 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4"><h3 className="text-lg font-bold flex items-center gap-2"><Key className="w-5 h-5 text-amber-400" />Kullanıcı Yönetimi</h3><button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button></div>
        {error && <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 mb-3 text-red-300 text-xs">{error}</div>}
        <div className="space-y-2 mb-5">
          {users.length === 0 ? <p className="text-slate-500 text-sm text-center py-4">Kullanıcı listesi yükleniyor...</p> : users.map(u => (
            <div key={u.userName + u.role} className="flex items-center justify-between bg-slate-700/30 rounded-lg px-3 py-2">
              <div><p className="font-semibold text-sm">{ROLES[u.role]?.badge} {u.userName}</p><p className="text-slate-400 text-xs">{ROLES[u.role]?.label || u.role}</p></div>
              {!(u.userName === session?.userName && u.role === session?.role) && (
                <button onClick={() => handleDelete(u)} className="text-red-400/60 hover:text-red-400" title="Kullanıcıyı sil"><Trash2 className="w-4 h-4" /></button>
              )}
            </div>
          ))}
        </div>
        <div className="border-t border-slate-700/50 pt-4 space-y-3">
          <p className="text-sm font-semibold text-slate-300">Yeni Kullanıcı Ekle</p>
          <div><label className="block text-xs text-slate-300 mb-1">Ad</label><input value={form.userName} onChange={e => setForm({ ...form, userName: e.target.value })} className={iC} placeholder="Ahmet Yılmaz" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Rol</label><select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} className={iC}>{ROLE_OPTIONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}</select></div>
          <div><label className="block text-xs text-slate-300 mb-1">PIN (en az 4 hane)</label><input type="password" value={form.pin} onChange={e => setForm({ ...form, pin: e.target.value })} className={iC} placeholder="••••" maxLength={12} /></div>
          <button onClick={handleAdd} disabled={busy} className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white font-semibold rounded-xl py-2.5 text-sm disabled:opacity-50">{busy ? 'Ekleniyor...' : 'Kullanıcı Ekle'}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════════════════════════════ */
/* ═══════════════════════════════════════════════════════════════════
   v4 VIEW — ŞİRKET (konsolide filo dashboard'u + DCS/ERP dışa aktarım)
   ═══════════════════════════════════════════════════════════════════ */
function FleetOverviewView({ fleet, voyages, carbonPrice, gwpVersion, setSelectedShip, onNavigate, exp, company, addLog, can }) {
  const rows = useMemo(() => fleet.map(ship => {
    const s = computeSummary(fleet, voyages, ship.id, carbonPrice, gwpVersion);
    const sv = voyages.filter(v => v.shipId === ship.id);
    const feu = sv.length > 0 ? calculateFuelEUCompliance(sv, ship, s.latestYear, gwpVersion) : null;
    let liableTons = 0;
    sv.forEach(v => { liableTons += calculateVoyageEmissions(v, ship, carbonPrice).liableEmission; });
    return { ship, s, feu, liableTons };
  }), [fleet, voyages, carbonPrice, gwpVersion]);

  const totals = useMemo(() => rows.reduce((a, r) => ({
    co2: a.co2 + r.s.totalCO2, co2eq: a.co2eq + r.s.totalCO2eq, cost: a.cost + r.s.totalCost,
    fuel: a.fuel + r.s.totalFuel, dist: a.dist + r.s.totalDistance, voyages: a.voyages + r.s.voyageCount,
    penalty: a.penalty + ((r.feu && !r.feu.isCompliant) ? r.feu.penalty : 0),
  }), { co2: 0, co2eq: 0, cost: 0, fuel: 0, dist: 0, voyages: 0, penalty: 0 }), [rows]);

  const chartData = rows.map(r => ({
    name: r.ship.name.length > 12 ? r.ship.name.slice(0, 12) + '…' : r.ship.name,
    co2: Math.round(r.s.totalCO2), etsCost: Math.round(r.s.totalCost),
  }));

  const [expShipId, setExpShipId] = useState('');
  const [expYear, setExpYear] = useState(String(new Date().getFullYear()));
  useEffect(() => { if (!expShipId && fleet.length > 0) setExpShipId(fleet[0].id); }, [fleet, expShipId]);
  const expShip = fleet.find(s => s.id === expShipId) || null;
  const fmt = (v, d = 0) => (parseFloat(v) || 0).toLocaleString('tr-TR', { maximumFractionDigits: d });
  const card = "rounded-2xl p-4 border bg-slate-800/40 border-slate-700/50";
  const th = "text-left text-[11px] font-semibold text-slate-400 px-3 py-2";
  const td = "px-3 py-2 text-sm";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          ['Toplam CO₂', fmt(totals.co2, 1) + ' t', Leaf, 'text-emerald-400'],
          ['ETS Maliyeti', '€' + fmt(totals.cost), DollarSign, 'text-cyan-400'],
          ['FuelEU Ceza Riski', '€' + fmt(totals.penalty), AlertCircle, totals.penalty > 0 ? 'text-red-400' : 'text-emerald-400'],
          ['Sefer / Mesafe', fmt(totals.voyages) + ' / ' + fmt(totals.dist) + ' nm', Activity, 'text-blue-400'],
        ].map(([label, val, Icon, color]) => (
          <div key={label} className={card}>
            <div className="flex items-center gap-2 text-slate-400 text-xs mb-1"><Icon className={`w-4 h-4 ${color}`} />{label}</div>
            <div className="text-lg font-bold">{val}</div>
          </div>
        ))}
      </div>

      {chartData.length > 0 && (
        <div className="grid md:grid-cols-2 gap-4">
          <div className={card}>
            <h4 className="text-sm font-bold mb-3">Gemi Bazlı CO₂ (t)</h4>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12 }} />
                <Bar dataKey="co2" name="CO₂ (t)" fill="#22d3ee" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className={card}>
            <h4 className="text-sm font-bold mb-3">Gemi Bazlı ETS Maliyeti (€)</h4>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12 }} />
                <Bar dataKey="etsCost" name="ETS (€)" fill="#818cf8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className={card + ' overflow-x-auto'}>
        <h4 className="text-sm font-bold mb-3">Filo Uyum Tablosu</h4>
        <table className="w-full min-w-[820px]">
          <thead><tr className="border-b border-slate-700">
            <th className={th}>Gemi</th><th className={th}>Sefer</th><th className={th}>CO₂ (t)</th>
            <th className={th}>ETS Yükümlü (t)</th><th className={th}>ETS Maliyet</th>
            <th className={th}>CII ({'son yıl'})</th><th className={th}>FuelEU</th><th className={th}></th>
          </tr></thead>
          <tbody>
            {rows.map(({ ship, s, feu, liableTons }) => (
              <tr key={ship.id} className="border-b border-slate-800 hover:bg-slate-800/40">
                <td className={td + ' font-semibold'}>{ship.name}<span className="block text-[10px] text-slate-500">{ship.type} · {fmt(ship.capacityDWT)} DWT</span></td>
                <td className={td}>{s.voyageCount}</td>
                <td className={td}>{fmt(s.totalCO2, 1)}</td>
                <td className={td}>{fmt(liableTons, 1)}</td>
                <td className={td}>€{fmt(s.totalCost)}</td>
                <td className={td}><span className="px-2 py-0.5 rounded-full text-xs font-bold" style={{ background: getGradeColor(s.overallCIIResult.grade) + '33', color: getGradeColor(s.overallCIIResult.grade) }}>{s.overallCIIResult.grade}</span></td>
                <td className={td}>{feu ? (feu.isCompliant ? <span className="text-emerald-400 text-xs font-semibold">✓ Uyumlu</span> : <span className="text-red-400 text-xs font-semibold">✗ €{fmt(feu.penalty)}</span>) : <span className="text-slate-500 text-xs">—</span>}</td>
                <td className={td}><button onClick={() => { setSelectedShip(ship.id); onNavigate('dashboard'); }} className="text-cyan-400 hover:text-cyan-300 text-xs font-semibold">Detay →</button></td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td className={td} colSpan={8}><span className="text-slate-500 text-sm">Gemi yok.</span></td></tr>}
          </tbody>
        </table>
      </div>

      {can('export_report') && (
        <div className={card}>
          <h4 className="text-sm font-bold mb-1">Raporlama Dışa Aktarımları</h4>
          <p className="text-xs text-slate-400 mb-3">IMO DCS taslağı (XML) ve ERP/muhasebe yıl sonu tahakkuk fişi (CSV, ; ayraçlı — Excel/Logo/Netsis içe aktarımına uygun şablon).</p>
          <div className="flex flex-wrap items-center gap-2">
            <select value={expShipId} onChange={e => setExpShipId(e.target.value)} className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm">
              {fleet.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <input type="number" value={expYear} onChange={e => setExpYear(e.target.value)} className="w-24 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm" min="2023" max="2050" />
            <button onClick={() => { if (!expShip) return; exp.downloadDCSXml(expShip, voyages, company, expYear); addLog('EXPORT_DCS', expShip.id, `IMO DCS ${expYear}`); }} className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-semibold rounded-xl px-4 py-2 flex items-center gap-1"><Download className="w-3.5 h-3.5" />IMO DCS XML</button>
            <button onClick={() => { if (!expShip) return; const n = exp.downloadErpCsv(expShip, voyages, company, expYear, carbonPrice, gwpVersion); addLog('EXPORT_ERP', expShip.id, `ERP fişi ${expYear} (${n || 0} satır)`); }} className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-xs font-semibold rounded-xl px-4 py-2 flex items-center gap-1"><Download className="w-3.5 h-3.5" />ERP Fişi CSV</button>
          </div>
          <p className="text-[10px] text-slate-500 mt-2">{REPORT_FOOTER_TEXT} ERP fişindeki 770/373 kodları şablondur; kendi hesap planınıza uyarlayın.</p>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   v4 VIEW — OPTİMİZASYON (hız / yakıt / maliyet)
   ═══════════════════════════════════════════════════════════════════ */
function OptimizationView({ currentShip, carbonPrice, gwpVersion }) {
  const [form, setForm] = useState({ distance: '3000', routeType: 'AB içi', year: String(new Date().getFullYear()), fuelType: 'HFO', fuelPrice: '500', dayCost: '12000' });
  const [priceMap, setPriceMap] = useState({});
  const u = (k, v) => setForm(prev => ({ ...prev, [k]: v }));
  const iC = "w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white focus:border-cyan-500 focus:outline-none";
  const card = "rounded-2xl p-4 border bg-slate-800/40 border-slate-700/50";
  const fmt = (v, d = 0) => (parseFloat(v) || 0).toLocaleString('tr-TR', { maximumFractionDigits: d });

  const sweep = useMemo(() => {
    if (!currentShip) return null;
    return computeSpeedSweep({
      shipType: currentShip.type, dwt: currentShip.capacityDWT,
      engineType: currentShip.engineType, fuelType: form.fuelType,
      distance: form.distance, routeType: form.routeType, year: form.year,
      fuelPrice: form.fuelPrice, carbonPrice, dayCost: form.dayCost,
      dailyFuelOverride: currentShip.dailyFuel,
    });
  }, [currentShip, form, carbonPrice]);

  const fuelCompare = useMemo(() => {
    if (!sweep) return [];
    return compareFuelsAtEnergy({
      baseFuelType: form.fuelType, baseFuelTons: sweep.best.fuelTons,
      year: form.year, engineType: currentShip?.engineType,
      routeType: form.routeType, carbonPrice, gwpVersion, priceMap,
    });
  }, [sweep, form.fuelType, form.year, form.routeType, currentShip, carbonPrice, gwpVersion, priceMap]);

  const savings = sweep ? sweep.base.total - sweep.best.total : 0;
  const chartData = sweep ? sweep.points.map(p => ({ speed: p.speed, Yakıt: Math.round(p.fuelCost), ETS: Math.round(p.etsCost), Zaman: Math.round(p.timeCost), Toplam: Math.round(p.total) })) : [];
  const th = "text-left text-[11px] font-semibold text-slate-400 px-2 py-2";
  const td = "px-2 py-1.5 text-xs";

  if (!currentShip) return <div className="text-center py-16 text-slate-400">Optimizasyon için önce bir gemi seçin.</div>;

  return (
    <div className="space-y-6">
      <div className={card}>
        <h4 className="text-sm font-bold mb-3 flex items-center gap-2"><Gauge className="w-4 h-4 text-cyan-400" />Sefer Parametreleri — {currentShip.name}</h4>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
          <div><label className="block text-[11px] text-slate-400 mb-1">Mesafe (nm)</label><input type="number" min="1" value={form.distance} onChange={e => u('distance', e.target.value)} className={iC} /></div>
          <div><label className="block text-[11px] text-slate-400 mb-1">Rota</label><select value={form.routeType} onChange={e => u('routeType', e.target.value)} className={iC}>{Object.keys(ROUTE_ETS_RATES).map(r => <option key={r} value={r}>{r}</option>)}</select></div>
          <div><label className="block text-[11px] text-slate-400 mb-1">Yıl</label><input type="number" min="2024" max="2050" value={form.year} onChange={e => u('year', e.target.value)} className={iC} /></div>
          <div><label className="block text-[11px] text-slate-400 mb-1">Yakıt</label><select value={form.fuelType} onChange={e => u('fuelType', e.target.value)} className={iC}>{Object.keys(OPT_FUEL_DEFAULT_PRICES).map(f => <option key={f} value={f}>{f}</option>)}</select></div>
          <div><label className="block text-[11px] text-slate-400 mb-1">Yakıt Fiyatı (€/t)</label><input type="number" min="0" value={form.fuelPrice} onChange={e => u('fuelPrice', e.target.value)} className={iC} /></div>
          <div><label className="block text-[11px] text-slate-400 mb-1">Gün Maliyeti (€/gün)</label><input type="number" min="0" value={form.dayCost} onChange={e => u('dayCost', e.target.value)} className={iC} /></div>
        </div>
        <p className="text-[10px] text-slate-500 mt-2">Model: günlük tüketim ∝ hız³ (küp yasası), referans {sweep ? sweep.vRef : '-'} kn / {sweep ? sweep.dailyRef : '-'} t-gün. Gün maliyeti = kira/fırsat maliyeti. ETS = rota oranı × phase-in × €{carbonPrice}. Karar destek amaçlıdır.</p>
      </div>

      {sweep && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              ['Optimum Hız', sweep.best.speed.toFixed(2) + ' kn', Target, 'text-emerald-400'],
              ['Optimumda Toplam', '€' + fmt(sweep.best.total), DollarSign, 'text-cyan-400'],
              ['Servis Hızına Göre Tasarruf', (savings >= 0 ? '€' + fmt(savings) : '—'), TrendingDown, savings > 0 ? 'text-emerald-400' : 'text-slate-400'],
              ['Süre / Yakıt', sweep.best.days.toFixed(1) + ' gün / ' + fmt(sweep.best.fuelTons, 1) + ' t', Activity, 'text-blue-400'],
            ].map(([label, val, Icon, color]) => (
              <div key={label} className={card}>
                <div className="flex items-center gap-2 text-slate-400 text-xs mb-1"><Icon className={`w-4 h-4 ${color}`} />{label}</div>
                <div className="text-lg font-bold">{val}</div>
              </div>
            ))}
          </div>

          <div className={card}>
            <h4 className="text-sm font-bold mb-3">Hız – Maliyet Eğrisi</h4>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="speed" tick={{ fill: '#94a3b8', fontSize: 11 }} unit=" kn" />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <ReferenceLine x={sweep.best.speed} stroke="#10b981" strokeDasharray="4 4" label={{ value: 'optimum', fill: '#10b981', fontSize: 10 }} />
                <Line type="monotone" dataKey="Toplam" stroke="#f59e0b" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="Yakıt" stroke="#22d3ee" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="ETS" stroke="#818cf8" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="Zaman" stroke="#94a3b8" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className={card + ' overflow-x-auto'}>
            <h4 className="text-sm font-bold mb-1">Alternatif Yakıt Karşılaştırması <span className="text-slate-500 font-normal">(optimum hızdaki enerji eşdeğeri, fiyatlar düzenlenebilir)</span></h4>
            <table className="w-full min-w-[760px]">
              <thead><tr className="border-b border-slate-700">
                <th className={th}>Yakıt</th><th className={th}>Miktar (t)</th><th className={th}>€/t</th><th className={th}>Yakıt €</th><th className={th}>ETS €</th><th className={th}>Toplam €</th><th className={th}>WtW g/MJ</th><th className={th}>FuelEU {form.year}</th>
              </tr></thead>
              <tbody>
                {fuelCompare.map(r => (
                  <tr key={r.fuelType} className={`border-b border-slate-800 ${r.fuelType === form.fuelType ? 'bg-cyan-500/5' : ''}`}>
                    <td className={td + ' font-semibold'}>{r.fuelType}{r.certified && <span className="text-emerald-400 text-[10px] ml-1">RED II✓*</span>}</td>
                    <td className={td}>{fmt(r.tons, 1)}</td>
                    <td className={td}><input type="number" min="0" value={priceMap[r.fuelType] !== undefined ? priceMap[r.fuelType] : r.price} onChange={e => setPriceMap(prev => ({ ...prev, [r.fuelType]: e.target.value }))} className="w-20 bg-slate-700/50 border border-slate-600 rounded px-1.5 py-0.5 text-xs" /></td>
                    <td className={td}>€{fmt(r.fuelCost)}</td>
                    <td className={td}>€{fmt(r.etsCost)}</td>
                    <td className={td + ' font-bold'}>€{fmt(r.total)}</td>
                    <td className={td}>{r.wtw.toFixed(1)}</td>
                    <td className={td}>{r.fuelEUCompliant ? <span className="text-emerald-400">✓ ≤ {r.fuelEULimit.toFixed(1)}</span> : <span className="text-red-400">✗ &gt; {r.fuelEULimit.toFixed(1)}</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="text-[10px] text-slate-500 mt-2">* Bio/RFNBO satırlarında RED II sertifikalı ve tipik sertifika WtT değeri varsayılmıştır — resmi hesapta PoS'taki gerçek E-değeri kullanılmalıdır. Yakıt fiyatları örnek başlangıç değerleridir.</p>
          </div>
        </>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   v4 VIEW — KARBON PORTFÖYÜ + FİYAT YÖNETİMİ
   ═══════════════════════════════════════════════════════════════════ */
const PORTFOLIO_INSTRUMENTS = ['EUA', 'VCC', 'CER', 'Diğer'];

function TxModal({ onSave, onClose }) {
  const [form, setForm] = useState({ side: 'buy', instrument: 'EUA', quantity: '', unitPrice: '', date: new Date().toISOString().split('T')[0], registryRef: '', note: '' });
  const [err, setErr] = useState('');
  const iC = "w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white focus:border-cyan-500 focus:outline-none";
  const u = (k, v) => { setErr(''); setForm(prev => ({ ...prev, [k]: v })); };
  const save = () => {
    const q = parseFloat(form.quantity), p = parseFloat(form.unitPrice);
    if (!Number.isFinite(q) || q <= 0) return setErr('Adet > 0 olmalı.');
    if (!Number.isFinite(p) || p < 0) return setErr('Birim fiyat ≥ 0 olmalı.');
    if (!form.date) return setErr('Tarih girin.');
    onSave({ ...form, quantity: q, unitPrice: p });
  };
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl p-5 max-w-md w-full border border-slate-700" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4"><h3 className="text-lg font-bold">Portföy İşlemi Kaydet</h3><button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button></div>
        {err && <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 mb-3 text-red-300 text-xs">{err}</div>}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs text-slate-300 mb-1">Yön</label><select value={form.side} onChange={e => u('side', e.target.value)} className={iC}><option value="buy">Alış</option><option value="sell">Satış</option></select></div>
            <div><label className="block text-xs text-slate-300 mb-1">Enstrüman</label><select value={form.instrument} onChange={e => u('instrument', e.target.value)} className={iC}>{PORTFOLIO_INSTRUMENTS.map(i => <option key={i} value={i}>{i}</option>)}</select></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs text-slate-300 mb-1">Adet (t / kredi)</label><input type="number" min="0" step="0.01" value={form.quantity} onChange={e => u('quantity', e.target.value)} className={iC} /></div>
            <div><label className="block text-xs text-slate-300 mb-1">Birim Fiyat (€)</label><input type="number" min="0" step="0.01" value={form.unitPrice} onChange={e => u('unitPrice', e.target.value)} className={iC} /></div>
          </div>
          <div><label className="block text-xs text-slate-300 mb-1">İşlem Tarihi</label><input type="date" value={form.date} onChange={e => u('date', e.target.value)} className={iC} /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Borsa/Sicil Referansı <span className="text-slate-500">(EEX/ICE emir no, Union Registry / Verra işlem no)</span></label><input type="text" value={form.registryRef} onChange={e => u('registryRef', e.target.value)} className={iC} placeholder="örn. EEX-2026-000123" /></div>
          <div><label className="block text-xs text-slate-300 mb-1">Not</label><input type="text" value={form.note} onChange={e => u('note', e.target.value)} className={iC} /></div>
        </div>
        <div className="flex gap-3 mt-4">
          <button onClick={save} className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl py-2.5 text-sm">Kaydet</button>
          <button onClick={onClose} className="px-6 bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2.5 rounded-xl text-sm">İptal</button>
        </div>
      </div>
    </div>
  );
}

function CarbonPortfolioView({ prices, portfolio, can, addLog, notifyError, setCarbonPrice }) {
  const [showTx, setShowTx] = useState(false);
  const [priceForm, setPriceForm] = useState({ instrument: 'EUA', price: '', date: new Date().toISOString().split('T')[0], source: 'manuel' });
  const card = "rounded-2xl p-4 border bg-slate-800/40 border-slate-700/50";
  const th = "text-left text-[11px] font-semibold text-slate-400 px-2 py-2";
  const td = "px-2 py-1.5 text-xs";
  const fmt = (v, d = 2) => (parseFloat(v) || 0).toLocaleString('tr-TR', { maximumFractionDigits: d, minimumFractionDigits: d > 0 ? 2 : 0 });
  const canWrite = can('edit_settings');

  const latestPrices = useMemo(() => {
    const out = {};
    Object.entries(prices.latestByInstrument).forEach(([k, v]) => { out[k] = v.price; });
    return out;
  }, [prices.latestByInstrument]);
  const { positions, realizedTotal, errors } = useMemo(
    () => computePortfolioPositions(portfolio.transactions, latestPrices),
    [portfolio.transactions, latestPrices]
  );
  const totalUnrealized = positions.reduce((s, p) => s + (p.unrealized || 0), 0);
  const totalMarket = positions.reduce((s, p) => s + (p.marketValue || 0), 0);

  const euaHistory = useMemo(() =>
    prices.prices.filter(p => p.instrument === 'EUA')
      .map(p => ({ date: p.date, fiyat: p.price }))
      .sort((a, b) => (a.date || '').localeCompare(b.date || '')),
    [prices.prices]);

  const saveTx = async (data) => {
    try {
      const tx = await portfolio.addTransaction(data);
      addLog('PORTFOLIO_TX', tx?.id, `${data.side === 'buy' ? 'Alış' : 'Satış'} ${data.quantity} ${data.instrument} @ €${data.unitPrice}`);
      setShowTx(false);
    } catch (e) { notifyError(e.message); }
  };
  const savePrice = async () => {
    const p = parseFloat(priceForm.price);
    if (!Number.isFinite(p) || p < 0) return notifyError('Geçerli fiyat girin.');
    if (!priceForm.date) return notifyError('Tarih girin.');
    try {
      const rec = await prices.addPrice({ ...priceForm, price: p });
      addLog('PRICE_SET', rec?.id, `${priceForm.instrument} = €${p} (${priceForm.date})`);
      setPriceForm(prev => ({ ...prev, price: '' }));
    } catch (e) { notifyError(e.message); }
  };
  const euaLatest = prices.latestByInstrument['EUA'];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          ['Piyasa Değeri', '€' + fmt(totalMarket), Wallet, 'text-cyan-400'],
          ['Gerçekleşmemiş K/Z', (totalUnrealized >= 0 ? '+' : '') + '€' + fmt(totalUnrealized), TrendingUp, totalUnrealized >= 0 ? 'text-emerald-400' : 'text-red-400'],
          ['Gerçekleşen K/Z', (realizedTotal >= 0 ? '+' : '') + '€' + fmt(realizedTotal), Award, realizedTotal >= 0 ? 'text-emerald-400' : 'text-red-400'],
          ['Güncel EUA', euaLatest ? '€' + fmt(euaLatest.price) + ' (' + euaLatest.date + ')' : '—', DollarSign, 'text-amber-400'],
        ].map(([label, val, Icon, color]) => (
          <div key={label} className={card}>
            <div className="flex items-center gap-2 text-slate-400 text-xs mb-1"><Icon className={`w-4 h-4 ${color}`} />{label}</div>
            <div className="text-base font-bold">{val}</div>
          </div>
        ))}
      </div>

      {errors.length > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl px-4 py-2 text-yellow-300 text-xs">⚠️ Kayıt tutarsızlığı: {errors.join(' · ')}</div>
      )}

      <div className={card + ' overflow-x-auto'}>
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-bold">Pozisyonlar</h4>
          {canWrite && <button onClick={() => setShowTx(true)} className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-semibold rounded-xl px-4 py-2 flex items-center gap-1"><Plus className="w-3.5 h-3.5" />İşlem Kaydet</button>}
        </div>
        <table className="w-full min-w-[700px]">
          <thead><tr className="border-b border-slate-700">
            <th className={th}>Enstrüman</th><th className={th}>Adet</th><th className={th}>Ort. Maliyet</th><th className={th}>Son Fiyat</th><th className={th}>Piyasa Değeri</th><th className={th}>Gerç.memiş K/Z</th><th className={th}>Gerç. K/Z</th>
          </tr></thead>
          <tbody>
            {positions.map(p => (
              <tr key={p.instrument} className="border-b border-slate-800">
                <td className={td + ' font-semibold'}>{p.instrument}</td>
                <td className={td}>{fmt(p.qty)}</td>
                <td className={td}>€{fmt(p.avgCost)}</td>
                <td className={td}>{p.lastPrice !== null ? '€' + fmt(p.lastPrice) : <span className="text-slate-500">fiyat girin</span>}</td>
                <td className={td}>{p.marketValue !== null ? '€' + fmt(p.marketValue) : '—'}</td>
                <td className={td}>{p.unrealized !== null ? <span className={p.unrealized >= 0 ? 'text-emerald-400' : 'text-red-400'}>{(p.unrealized >= 0 ? '+' : '') + '€' + fmt(p.unrealized)}</span> : '—'}</td>
                <td className={td}><span className={p.realized >= 0 ? 'text-emerald-400' : 'text-red-400'}>{(p.realized >= 0 ? '+' : '') + '€' + fmt(p.realized)}</span></td>
              </tr>
            ))}
            {positions.length === 0 && <tr><td className={td} colSpan={7}><span className="text-slate-500">Henüz işlem yok. {canWrite ? '"İşlem Kaydet" ile başlayın.' : ''}</span></td></tr>}
          </tbody>
        </table>
        <p className="text-[10px] text-slate-500 mt-2">Bu modül kayıt/portföy yönetimi içindir; gerçek EUA/kredi alım-satımı borsa (EEX/ICE) veya aracı kurum üzerinden yapılır ve sicil referansıyla buraya işlenir. Değerleme: ağırlıklı ortalama maliyet.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className={card}>
          <h4 className="text-sm font-bold mb-3">Fiyat Yönetimi</h4>
          {canWrite ? (
            <div className="flex flex-wrap items-end gap-2 mb-3">
              <div><label className="block text-[11px] text-slate-400 mb-1">Enstrüman</label><select value={priceForm.instrument} onChange={e => setPriceForm(p => ({ ...p, instrument: e.target.value }))} className="bg-slate-700/50 border border-slate-600 rounded-lg px-2 py-1.5 text-xs">{PORTFOLIO_INSTRUMENTS.map(i => <option key={i} value={i}>{i}</option>)}</select></div>
              <div><label className="block text-[11px] text-slate-400 mb-1">€</label><input type="number" min="0" step="0.01" value={priceForm.price} onChange={e => setPriceForm(p => ({ ...p, price: e.target.value }))} className="w-24 bg-slate-700/50 border border-slate-600 rounded-lg px-2 py-1.5 text-xs" /></div>
              <div><label className="block text-[11px] text-slate-400 mb-1">Tarih</label><input type="date" value={priceForm.date} onChange={e => setPriceForm(p => ({ ...p, date: e.target.value }))} className="bg-slate-700/50 border border-slate-600 rounded-lg px-2 py-1.5 text-xs" /></div>
              <button onClick={savePrice} className="bg-cyan-500 text-white text-xs font-semibold rounded-lg px-3 py-1.5">Ekle</button>
            </div>
          ) : <p className="text-xs text-slate-500 mb-3">Fiyat girişi süpervizör/yönetici yetkisi gerektirir.</p>}
          {euaLatest && setCarbonPrice && (
            <button onClick={() => setCarbonPrice(euaLatest.price)} className="text-xs bg-slate-700 hover:bg-slate-600 rounded-lg px-3 py-1.5 mb-3">↺ Güncel EUA fiyatını (€{fmt(euaLatest.price)}) ETS hesabında kullan</button>
          )}
          <p className="text-[10px] text-slate-500">Gerçek zamanlı EUA verisi (EEX/ICE) lisanslıdır; günlük kapanışları buraya girin veya bir market-data aboneliği bağlandığında kaynak alanına yazın.</p>
        </div>
        <div className={card}>
          <h4 className="text-sm font-bold mb-3">EUA Fiyat Geçmişi</h4>
          {euaHistory.length > 1 ? (
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={euaHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} domain={['auto', 'auto']} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12 }} />
                <Line type="monotone" dataKey="fiyat" stroke="#f59e0b" strokeWidth={2} dot={{ r: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : <p className="text-xs text-slate-500">Grafik için en az 2 EUA fiyat kaydı girin.</p>}
        </div>
      </div>

      <div className={card + ' overflow-x-auto'}>
        <h4 className="text-sm font-bold mb-3">İşlem Geçmişi</h4>
        <table className="w-full min-w-[700px]">
          <thead><tr className="border-b border-slate-700">
            <th className={th}>Tarih</th><th className={th}>Yön</th><th className={th}>Enstrüman</th><th className={th}>Adet</th><th className={th}>Birim €</th><th className={th}>Tutar €</th><th className={th}>Referans</th><th className={th}>Kaydeden</th>
          </tr></thead>
          <tbody>
            {[...portfolio.transactions].sort((a, b) => ((b.date || '') + (b.createdAt || '')).localeCompare((a.date || '') + (a.createdAt || ''))).map(t => (
              <tr key={t.id} className="border-b border-slate-800">
                <td className={td}>{t.date}</td>
                <td className={td}><span className={t.side === 'buy' ? 'text-emerald-400 font-semibold' : 'text-red-400 font-semibold'}>{t.side === 'buy' ? 'ALIŞ' : 'SATIŞ'}</span></td>
                <td className={td}>{t.instrument}</td>
                <td className={td}>{fmt(t.quantity)}</td>
                <td className={td}>€{fmt(t.unitPrice)}</td>
                <td className={td}>€{fmt((parseFloat(t.quantity) || 0) * (parseFloat(t.unitPrice) || 0))}</td>
                <td className={td + ' text-slate-400'}>{t.registryRef || '—'}</td>
                <td className={td + ' text-slate-400'}>{t.createdBy}</td>
              </tr>
            ))}
            {portfolio.transactions.length === 0 && <tr><td className={td} colSpan={8}><span className="text-slate-500">Kayıt yok.</span></td></tr>}
          </tbody>
        </table>
      </div>

      {showTx && canWrite && <TxModal onSave={saveTx} onClose={() => setShowTx(false)} />}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   v4 VIEW — AIS CANLI TAKİP (aisstream.io WebSocket)
   API anahtarı yalnızca bu tarayıcıda saklanır (localStorage) ve
   doğrudan aisstream.io'ya gönderilir — backend'e geçmez.
   ═══════════════════════════════════════════════════════════════════ */
const AIS_KEY_STORAGE = 'scp:aisKey';
const isValidMMSI = (m) => /^\d{9}$/.test(String(m || '').trim());

function AISView({ fleet, refreshFleet, notifyError, can }) {
  const [apiKey, setApiKey] = useState(() => safeGet(AIS_KEY_STORAGE) || '');
  const [status, setStatus] = useState('idle'); // idle | connecting | open | closed | error
  const [positions, setPositions] = useState({});
  const [mmsiDraft, setMmsiDraft] = useState({});
  const wsRef = useRef(null);
  const card = "rounded-2xl p-4 border bg-slate-800/40 border-slate-700/50";
  const iC = "bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white focus:border-cyan-500 focus:outline-none";
  const tracked = fleet.filter(s => isValidMMSI(s.mmsi));

  const disconnect = useCallback(() => {
    if (wsRef.current) { try { wsRef.current.close(); } catch {} wsRef.current = null; }
    setStatus('closed');
  }, []);
  useEffect(() => () => { if (wsRef.current) { try { wsRef.current.close(); } catch {} } }, []);

  const connect = useCallback(() => {
    const key = apiKey.trim();
    if (!key) return notifyError('aisstream.io API anahtarı girin (ücretsiz: aisstream.io).');
    if (tracked.length === 0) return notifyError('Önce en az bir gemiye 9 haneli MMSI tanımlayın.');
    safeSet(AIS_KEY_STORAGE, key);
    if (wsRef.current) { try { wsRef.current.close(); } catch {} }
    setStatus('connecting');
    let ws;
    try { ws = new WebSocket('wss://stream.aisstream.io/v0/stream'); }
    catch { setStatus('error'); return notifyError('WebSocket başlatılamadı.'); }
    wsRef.current = ws;
    ws.onopen = () => {
      setStatus('open');
      ws.send(JSON.stringify({
        APIKey: key,
        BoundingBoxes: [[[-90, -180], [90, 180]]],
        FiltersShipMMSI: tracked.map(s => String(s.mmsi)),
        FilterMessageTypes: ['PositionReport'],
      }));
    };
    ws.onmessage = (ev) => {
      try {
        const d = JSON.parse(ev.data);
        if (d.MessageType !== 'PositionReport') return;
        const meta = d.MetaData || {};
        const pr = (d.Message && d.Message.PositionReport) || {};
        const mmsi = String(meta.MMSI || pr.UserID || '');
        if (!mmsi) return;
        setPositions(prev => ({
          ...prev,
          [mmsi]: {
            lat: meta.latitude ?? pr.Latitude, lon: meta.longitude ?? pr.Longitude,
            sog: pr.Sog, cog: pr.Cog, shipName: (meta.ShipName || '').trim(),
            time: meta.time_utc || new Date().toISOString(), receivedAt: Date.now(),
          },
        }));
      } catch {}
    };
    ws.onerror = () => setStatus('error');
    ws.onclose = () => setStatus(prev => (prev === 'error' ? 'error' : 'closed'));
  }, [apiKey, tracked, notifyError]);

  const saveMmsi = async (ship) => {
    const val = String(mmsiDraft[ship.id] || '').trim();
    if (!isValidMMSI(val)) return notifyError('MMSI 9 haneli sayı olmalı.');
    try {
      await api.put(`/ships/${ship.id}`, { ...ship, mmsi: val });
      setMmsiDraft(prev => ({ ...prev, [ship.id]: '' }));
      await refreshFleet();
    } catch (e) { notifyError(e.message); }
  };

  const statusInfo = {
    idle: ['text-slate-400', 'Bağlı değil'],
    connecting: ['text-yellow-400', 'Bağlanıyor…'],
    open: ['text-emerald-400', '● Canlı akış açık'],
    closed: ['text-slate-400', 'Bağlantı kapalı'],
    error: ['text-red-400', 'Bağlantı hatası — anahtarı ve MMSI listesini kontrol edin'],
  }[status];
  const fmtC = (v, d = 4) => (v === undefined || v === null ? '—' : Number(v).toFixed(d));

  return (
    <div className="space-y-6">
      <div className={card}>
        <h4 className="text-sm font-bold mb-1 flex items-center gap-2"><Radio className="w-4 h-4 text-cyan-400" />AIS Canlı Gemi Takibi</h4>
        <p className="text-xs text-slate-400 mb-3">Veri kaynağı: <span className="text-cyan-400">aisstream.io</span> (ücretsiz API anahtarı gerekir). Akış yalnızca bu sekme açıkken çalışır; anahtar tarayıcınızda saklanır.</p>
        <div className="flex flex-wrap items-center gap-2">
          <input type="password" value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="aisstream.io API anahtarı" className={iC + ' w-72'} />
          {status !== 'open'
            ? <button onClick={connect} className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-semibold rounded-xl px-4 py-2">Bağlan</button>
            : <button onClick={disconnect} className="bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-xl px-4 py-2">Kes</button>}
          <span className={`text-xs font-semibold ${statusInfo[0]}`}>{statusInfo[1]}</span>
        </div>
      </div>

      <div className={card + ' overflow-x-auto'}>
        <h4 className="text-sm font-bold mb-3">Filo Konumları</h4>
        <table className="w-full min-w-[820px]">
          <thead><tr className="border-b border-slate-700">
            {['Gemi', 'MMSI', 'Enlem', 'Boylam', 'Hız (kn)', 'Rota (°)', 'Son Sinyal (UTC)', 'Harita'].map(h => <th key={h} className="text-left text-[11px] font-semibold text-slate-400 px-2 py-2">{h}</th>)}
          </tr></thead>
          <tbody>
            {fleet.map(ship => {
              const p = isValidMMSI(ship.mmsi) ? positions[String(ship.mmsi)] : null;
              return (
                <tr key={ship.id} className="border-b border-slate-800">
                  <td className="px-2 py-1.5 text-xs font-semibold">{ship.name}</td>
                  <td className="px-2 py-1.5 text-xs">
                    {isValidMMSI(ship.mmsi) ? <span className="text-slate-300">{ship.mmsi}</span> : (
                      can('create_ship') ? (
                        <span className="flex items-center gap-1">
                          <input type="text" maxLength={9} value={mmsiDraft[ship.id] || ''} onChange={e => setMmsiDraft(prev => ({ ...prev, [ship.id]: e.target.value.replace(/\D/g, '') }))} placeholder="9 hane" className="w-24 bg-slate-700/50 border border-slate-600 rounded px-1.5 py-0.5 text-xs" />
                          <button onClick={() => saveMmsi(ship)} className="text-cyan-400 hover:text-cyan-300 text-xs font-semibold">Kaydet</button>
                        </span>
                      ) : <span className="text-slate-500">tanımsız</span>
                    )}
                  </td>
                  <td className="px-2 py-1.5 text-xs">{p ? fmtC(p.lat) : '—'}</td>
                  <td className="px-2 py-1.5 text-xs">{p ? fmtC(p.lon) : '—'}</td>
                  <td className="px-2 py-1.5 text-xs">{p && p.sog !== undefined && p.sog !== null ? Number(p.sog).toFixed(1) : '—'}</td>
                  <td className="px-2 py-1.5 text-xs">{p && p.cog !== undefined && p.cog !== null ? Number(p.cog).toFixed(0) : '—'}</td>
                  <td className="px-2 py-1.5 text-xs text-slate-400">{p ? String(p.time).replace('T', ' ').slice(0, 19) : '—'}</td>
                  <td className="px-2 py-1.5 text-xs">
                    {p && Number.isFinite(p.lat) && Number.isFinite(p.lon)
                      ? <a href={`https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lon}#map=9/${p.lat}/${p.lon}`} target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"><MapPin className="w-3 h-3" />Aç</a>
                      : '—'}
                  </td>
                </tr>
              );
            })}
            {fleet.length === 0 && <tr><td className="px-2 py-3 text-xs text-slate-500" colSpan={8}>Filo boş.</td></tr>}
          </tbody>
        </table>
        <p className="text-[10px] text-slate-500 mt-2">AIS sinyali VHF menzili/uydu kapsamına bağlıdır; açık denizde gecikme veya boşluk normaldir. Konumlar seyir emniyeti için değil, yönetim görünürlüğü içindir.</p>
      </div>
    </div>
  );
}

function ShipCarbonApp({ auth }) {
  const { session, company, logout } = auth;
  const ships = useShips();
  const voy = useVoyages();
  const bdn = useBDN();
  const audit = useAuditChain();
  const exp = useExport();
  const prices = usePrices();
  const portfolio = usePortfolio();

  const [activeView, setActiveView] = useState('dashboard');
  const [carbonPrice, setCarbonPrice] = useState(84);
  const [gwpVersion, setGwpVersion] = useState(FUELEU_GWP_DEFAULT);
  const [showAddVoyage, setShowAddVoyage] = useState(false);
  const [showAddShip, setShowAddShip] = useState(false);
  const [showUsers, setShowUsers] = useState(false);
  const [whatIfScenarios, setWhatIfScenarios] = useState([]);
  const [appError, setAppError] = useState('');
  const errTimer = useRef(null);
  const notifyError = useCallback((msg) => {
    setAppError(msg);
    if (errTimer.current) clearTimeout(errTimer.current);
    errTimer.current = setTimeout(() => setAppError(''), 5000);
  }, []);
  useEffect(() => () => { if (errTimer.current) clearTimeout(errTimer.current); }, []);

  const { fleet, selectedShip, setSelectedShip, currentShip } = ships;
  const { voyages } = voy;
  const { addLog } = audit;

  const dashboard = useDashboard(fleet, voyages, selectedShip, carbonPrice, gwpVersion);
  const { summary, fuelEUData, runWhatIf } = dashboard;

  const can = useCallback((action) => checkPermission(session?.role, action), [session]);

  useEffect(() => {
    if (!session?.companyId) return;
    ships.fetchFleet();
    voy.fetchVoyages();
    bdn.fetchBDN();
    audit.fetchAuditLog();
    prices.fetchPrices();
    portfolio.fetchTransactions();
    // DÜZELTME: sayfa her yenilendiğinde LOGIN kaydı atılıyordu → audit zinciri
    // gereksiz şişiyordu. Tarayıcı oturumu başına bir kez logla.
    try {
      const k = 'scp:login-logged:' + session.companyId;
      if (!sessionStorage.getItem(k)) {
        addLog('LOGIN', null, (ROLES[session.role]?.label || '') + ' girişi');
        sessionStorage.setItem(k, '1');
      }
    } catch { addLog('LOGIN', null, (ROLES[session.role]?.label || '') + ' girişi'); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.companyId]);

  const handleAddVoyage = async (voyageData) => {
    try {
      const v = await voy.addVoyage({ ...voyageData, shipId: selectedShip });
      addLog('CREATE_VOYAGE', v?.id, `${voyageData.from || '?'}→${voyageData.to || '?'}, ${voyageData.distance}nm`);
      setShowAddVoyage(false);
    } catch (e) { notifyError(e.message); }
  };

  const handleDeleteVoyage = async (v) => {
    try {
      await voy.deleteVoyage(v.id);
      addLog('DELETE_VOYAGE', v.id, `${v.from || '?'}→${v.to || '?'} silindi`);
    } catch (e) { notifyError(e.message); }
  };

  const handleAddShip = async (shipData) => {
    try {
      const s = await ships.addShip(shipData);
      addLog('CREATE_SHIP', s?.id, shipData.name);
      setShowAddShip(false);
    } catch (e) { notifyError(e.message); }
  };

  const handleLogout = async () => {
    // DÜZELTME: setTimeout ile yarış durumu vardı — audit kaydı bazen
    // token silindikten sonra gidip 401 alıyordu. Önce kaydı bekle, sonra çık.
    try { await addLog('LOGOUT', null, 'Çıkış'); } catch {}
    try { sessionStorage.removeItem('scp:login-logged:' + session?.companyId); } catch {}
    logout();
  };

  const currentScope = getComplianceScope(currentShip);
  const latestYearInt = parseInt(summary.latestYear) || 2024;
  const dashEmissionLabel = latestYearInt >= 2026 ? 'tCO₂eq' : 'tCO₂';
  const roleInfo = ROLES[session?.role] || {};
  const navBtn = (v) => activeView === v
    ? "px-3 py-1.5 rounded-xl font-semibold text-xs bg-cyan-500 text-white shadow-lg shadow-cyan-500/25"
    : "px-3 py-1.5 rounded-xl font-semibold text-xs text-slate-400 hover:text-white hover:bg-slate-700/50";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white">
      <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-xl border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-2 rounded-xl"><Ship className="w-5 h-5 text-white" /></div>
            <div><h1 className="text-base font-bold leading-tight">Ship Carbon Pro</h1><p className="text-cyan-400 text-xs">{company?.name}</p></div>
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            {[['dashboard', 'Dashboard'], ['fleet', 'Filo']].map(([v, l]) => <button key={v} onClick={() => setActiveView(v)} className={navBtn(v)}>{l}</button>)}
            {can('view_dashboard') && <button onClick={() => setActiveView('overview')} className={navBtn('overview')}>Şirket</button>}
            {can('view_fleet') && <button onClick={() => setActiveView('ais')} className={navBtn('ais')}>📡 AIS</button>}
            {can('upload_bdn') && <button onClick={() => setActiveView('bdn')} className={navBtn('bdn')}>📄 BDN</button>}
            {can('view_whatif') && <button onClick={() => setActiveView('what-if')} className={navBtn('what-if')}>What-If</button>}
            {can('view_whatif') && <button onClick={() => setActiveView('optimize')} className={navBtn('optimize')}>Optimizasyon</button>}
            {can('view_report') && <button onClick={() => setActiveView('report')} className={navBtn('report')}>ETS</button>}
            {can('view_report') && <button onClick={() => setActiveView('fueleu-report')} className={navBtn('fueleu-report')}>FuelEU</button>}
            {can('view_report') && <button onClick={() => setActiveView('portfolio')} className={navBtn('portfolio')}>💼 Portföy</button>}
            {can('view_audit') && <button onClick={() => setActiveView('audit')} className={navBtn('audit')}>📋 Denetim</button>}
            <div className="h-5 w-px bg-slate-700 mx-1" />
            <span className="text-xs text-slate-400 hidden md:inline">{roleInfo.badge} {session?.userName}</span>
            {session?.role === 'company_admin' && (
              <button onClick={() => setShowUsers(true)} className="text-slate-400 hover:text-amber-400" title="Kullanıcı Yönetimi"><Key className="w-4 h-4" /></button>
            )}
            <button onClick={handleLogout} className="ml-1 text-slate-400 hover:text-red-400" title="Çıkış"><LogOut className="w-4 h-4" /></button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {['dashboard', 'what-if', 'optimize', 'report', 'fueleu-report'].includes(activeView) && fleet.length > 0 && (
          <div className="rounded-2xl p-4 border bg-slate-800/40 border-slate-700/50 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Ship className="w-5 h-5 text-cyan-400" />
              <select value={selectedShip} onChange={e => setSelectedShip(e.target.value)} className="bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2 text-white text-sm font-semibold focus:outline-none">
                {fleet.map(s => <option key={s.id} value={s.id}>{s.name} ({s.type})</option>)}
              </select>
              {currentShip && <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${currentScope.gt >= 5000 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{currentScope.gt >= 5000 ? 'CII ✓ | ETS ✓ | FuelEU ✓' : 'GT < 5000'}</span>}
            </div>
            {can('edit_settings') && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-slate-400">Karbon:</span>
                <input type="number" min="0" value={carbonPrice} onChange={e => { const v = parseFloat(e.target.value); setCarbonPrice(v >= 0 ? v : 0); }} className="w-20 bg-slate-700/50 border border-slate-600 rounded-lg px-2 py-1.5 text-white text-center focus:outline-none" />
                <span className="text-slate-400">€/{dashEmissionLabel}</span>
              </div>
            )}
          </div>
        )}

        {fleet.length === 0 && activeView === 'dashboard' && (
          <div className="text-center py-20"><Ship className="w-16 h-16 mx-auto mb-4 text-slate-600" /><h3 className="text-xl font-bold mb-2">Filo Boş</h3><p className="text-slate-400 mb-4">Başlamak için ilk geminizi ekleyin.</p>{can('create_ship') && <button onClick={() => setShowAddShip(true)} className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl px-6 py-3"><Plus className="w-4 h-4 inline mr-2" />Yeni Gemi</button>}</div>
        )}

        {activeView === 'dashboard' && fleet.length > 0 && (
          <DashboardView fleet={fleet} selectedShip={selectedShip} voyages={voyages} currentShip={currentShip} carbonPrice={carbonPrice} summary={summary} fuelEUData={fuelEUData} gwpVersion={gwpVersion} can={can} onAddVoyage={() => setShowAddVoyage(true)} onDeleteVoyage={handleDeleteVoyage} onNavigate={setActiveView} />
        )}
        {activeView === 'fleet' && (
          <FleetView fleet={fleet} selectedShip={selectedShip} setSelectedShip={setSelectedShip} voyages={voyages} carbonPrice={carbonPrice} can={can} onAddShip={() => setShowAddShip(true)} onNavigate={setActiveView} />
        )}
        {activeView === 'bdn' && (
          <BDNView bdn={bdn} fleet={fleet} voyages={voyages} can={can} onRefreshVoyages={voy.fetchVoyages} />
        )}
        {activeView === 'what-if' && can('view_whatif') && (
          <WhatIfSection summary={summary} runWhatIf={runWhatIf} whatIfScenarios={whatIfScenarios} setWhatIfScenarios={setWhatIfScenarios} />
        )}
        {activeView === 'report' && can('view_report') && (
          <EtsReportView fleet={fleet} selectedShip={selectedShip} voyages={voyages} carbonPrice={carbonPrice} company={company} session={session} downloadMRVXml={exp.downloadMRVXml} />
        )}
        {activeView === 'fueleu-report' && can('view_report') && (
          <FuelEUReportView fleet={fleet} selectedShip={selectedShip} voyages={voyages} carbonPrice={carbonPrice} gwpVersion={gwpVersion} setGwpVersion={setGwpVersion} company={company} session={session} />
        )}
        {activeView === 'audit' && can('view_audit') && (
          <AuditTrailView audit={audit} company={company} session={session} />
        )}
        {activeView === 'overview' && can('view_dashboard') && (
          <FleetOverviewView fleet={fleet} voyages={voyages} carbonPrice={carbonPrice} gwpVersion={gwpVersion} setSelectedShip={setSelectedShip} onNavigate={setActiveView} exp={exp} company={company} addLog={addLog} can={can} />
        )}
        {activeView === 'optimize' && can('view_whatif') && (
          <OptimizationView currentShip={currentShip} carbonPrice={carbonPrice} gwpVersion={gwpVersion} />
        )}
        {activeView === 'portfolio' && can('view_report') && (
          <CarbonPortfolioView prices={prices} portfolio={portfolio} can={can} addLog={addLog} notifyError={notifyError} setCarbonPrice={can('edit_settings') ? setCarbonPrice : null} />
        )}
        {activeView === 'ais' && can('view_fleet') && (
          <AISView fleet={fleet} refreshFleet={ships.fetchFleet} notifyError={notifyError} can={can} />
        )}
      </div>

      {appError && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 bg-red-600 text-white text-sm font-semibold px-5 py-3 rounded-xl shadow-2xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />{appError}
          <button onClick={() => setAppError('')} className="ml-2 opacity-70 hover:opacity-100"><X className="w-4 h-4" /></button>
        </div>
      )}

      {showAddVoyage && can('create_voyage') && (
        <AddVoyageModal currentShip={currentShip} onSave={handleAddVoyage} onClose={() => setShowAddVoyage(false)} />
      )}
      {showAddShip && can('create_ship') && (
        <AddShipModal onSave={handleAddShip} onClose={() => setShowAddShip(false)} />
      )}
      {showUsers && session?.role === 'company_admin' && (
        <UserManagementModal session={session} onClose={() => setShowUsers(false)} />
      )}
    </div>
  );
}

export default function ShipCarbonPro() {
  const auth = useAuth();

  if (auth.loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="text-center"><Ship className="w-12 h-12 text-cyan-400 mx-auto mb-3 animate-pulse" /><p className="text-slate-400">Yükleniyor...</p></div>
    </div>
  );

  if (!auth.isAuthenticated) return <AuthScreen auth={auth} />;
  return <ShipCarbonApp auth={auth} />;
}
