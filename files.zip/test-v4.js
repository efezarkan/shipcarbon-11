const assert = require('assert');
const P = require('./pure.js');

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('✓', name); };
const approx = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps * Math.max(1, Math.abs(a), Math.abs(b)), `${a} ≉ ${b}`);

/* ── computeSpeedSweep ───────────────────────────────────────────── */
const baseParams = {
  shipType: 'Bulk Carrier', dwt: 58000, fuelType: 'HFO', distance: 3000,
  routeType: 'AB içi', year: 2026, fuelPrice: 500, carbonPrice: 84, dayCost: 12000,
};
const sw = P.computeSpeedSweep(baseParams);
t('sweep üretildi ve noktalar sıralı', () => {
  assert.ok(sw && sw.points.length > 10);
  for (let i = 1; i < sw.points.length; i++) assert.ok(sw.points[i].speed > sw.points[i - 1].speed);
});
t('referans hızda calculateFuelAmount ile birebir aynı yakıt', () => {
  const ref = sw.points.find(p => Math.abs(p.speed - sw.vRef) < 1e-9);
  assert.ok(ref, 'vRef sweep içinde olmalı');
  const expected = P.calculateFuelAmount(3000, 58000, 'Bulk Carrier', 'HFO', undefined, sw.vRef);
  approx(ref.fuelTons, expected, 1e-9);
});
t('küp yasası: hız düştükçe toplam yakıt azalır', () => {
  for (let i = 1; i < sw.points.length; i++)
    assert.ok(sw.points[i].fuelTons > sw.points[i - 1].fuelTons, 'yakıt hızla artmalı');
});
t('süre × hız = mesafe', () => {
  sw.points.forEach(p => approx(p.days * 24 * p.speed, 3000, 1e-9));
});
t('best, tüm noktaların minimumu ve base servis hızı', () => {
  sw.points.forEach(p => assert.ok(sw.best.total <= p.total + 1e-6));
  approx(sw.base.speed, sw.vRef, 1e-9);
});
t('gün maliyeti 0 iken optimum en düşük hızdır (yakıt+ETS monoton)', () => {
  const s0 = P.computeSpeedSweep({ ...baseParams, dayCost: 0 });
  approx(s0.best.speed, s0.points[0].speed, 1e-9);
});
t('AB dışı rotada ETS maliyeti 0', () => {
  const s = P.computeSpeedSweep({ ...baseParams, routeType: 'AB dışı' });
  s.points.forEach(p => assert.strictEqual(p.etsCost, 0));
});
t('2024 phase-in %40 etkisi: birim emisyon başına maliyet oranı 2.5', () => {
  // 2026'da co2eq tanımı CH4/N2O içerir (GWP); bu yüzden oran co2eq bazına
  // normalize edilerek yalnız phase-in etkisi test edilir: (1.0 / 0.4) = 2.5
  const s24 = P.computeSpeedSweep({ ...baseParams, year: 2024 });
  const p26 = sw.points[0], p24 = s24.points[0];
  approx((p26.etsCost / p26.co2eq) / (p24.etsCost / p24.co2eq), 1.0 / 0.4, 1e-9);
  // Ek doğrulama: 2024'te co2eq = yalnız CO2 (mevcut motor davranışı)
  approx(p24.co2eq, p24.co2, 1e-9);
});
t('ETS maliyeti = CO2eq × oran × phase-in × fiyat (nokta bazında)', () => {
  const p = sw.best;
  approx(p.etsCost, p.co2eq * 1.0 * 1.0 * 84, 1e-9);
});

/* ── compareFuelsAtEnergy ────────────────────────────────────────── */
const cmp = P.compareFuelsAtEnergy({
  baseFuelType: 'HFO', baseFuelTons: 500, year: 2026, routeType: 'AB içi',
  carbonPrice: 84, gwpVersion: 'AR4',
});
t('enerji korunumu: tüm yakıtlarda ton × LCV sabit', () => {
  const eBase = 500 * P.FUELEU_FACTORS['HFO'].lcv;
  cmp.forEach(r => approx(r.tons * P.FUELEU_FACTORS[r.fuelType].lcv, eBase, 1e-9));
});
t('HFO satırı ton=500 ve WtW = calcWtWIntensity(HFO)', () => {
  const hfo = cmp.find(r => r.fuelType === 'HFO');
  approx(hfo.tons, 500, 1e-9);
  approx(hfo.wtw, P.calcWtWIntensity('HFO', 'AR4'), 1e-9);
});
t('sertifikasız biyoyakıt WtW = 94 (fosil karşılaştırıcısı)', () => {
  const c2 = P.compareFuelsAtEnergy({
    baseFuelType: 'HFO', baseFuelTons: 500, year: 2026, routeType: 'AB içi',
    carbonPrice: 84, gwpVersion: 'AR4', redCertifiedAlt: false,
  });
  const bio = c2.find(r => r.fuelType === 'Biodiesel');
  approx(bio.wtw, P.FOSSIL_COMPARATOR_WTW, 1e-9);
  assert.strictEqual(bio.fuelEUCompliant, false);
});
t('sertifikalı biyodizel ETS yanma CO₂\'si sıfırlanır (< fosil)', () => {
  const bio = cmp.find(r => r.fuelType === 'Biodiesel');
  const hfo = cmp.find(r => r.fuelType === 'HFO');
  assert.ok(bio.co2eq < hfo.co2eq * 0.05, 'sertifikalı bio CO2eq çok küçük olmalı');
});
t('sıralama toplam maliyete göre artan', () => {
  for (let i = 1; i < cmp.length; i++) assert.ok(cmp[i].total >= cmp[i - 1].total - 1e-9);
});
t('FuelEU uyum bayrağı limitle tutarlı', () => {
  const lim = P.getFuelEUTarget(2026).limit;
  cmp.forEach(r => assert.strictEqual(r.fuelEUCompliant, r.wtw <= lim + 1e-9));
});

/* ── computePortfolioPositions ───────────────────────────────────── */
t('portföy: ağırlıklı ortalama + gerçekleşen/gerçekleşmemiş K/Z', () => {
  const txs = [
    { side: 'buy', instrument: 'EUA', quantity: 100, unitPrice: 80, date: '2026-01-10', createdAt: 'a' },
    { side: 'buy', instrument: 'EUA', quantity: 100, unitPrice: 90, date: '2026-02-10', createdAt: 'b' },
    { side: 'sell', instrument: 'EUA', quantity: 50, unitPrice: 100, date: '2026-03-10', createdAt: 'c' },
  ];
  const r = P.computePortfolioPositions(txs, { EUA: 95 });
  const p = r.positions[0];
  approx(p.avgCost, 85);              // (100×80+100×90)/200
  approx(p.qty, 150);
  approx(p.realized, 50 * (100 - 85)); // 750
  approx(r.realizedTotal, 750);
  approx(p.unrealized, 150 * (95 - 85)); // 1500
  approx(p.marketValue, 150 * 95);
  assert.strictEqual(r.errors.length, 0);
});
t('portföy: tarih sırası kayıt sırasından bağımsız', () => {
  const txs = [
    { side: 'sell', instrument: 'EUA', quantity: 50, unitPrice: 100, date: '2026-03-10', createdAt: 'c' },
    { side: 'buy', instrument: 'EUA', quantity: 100, unitPrice: 90, date: '2026-02-10', createdAt: 'b' },
    { side: 'buy', instrument: 'EUA', quantity: 100, unitPrice: 80, date: '2026-01-10', createdAt: 'a' },
  ];
  const r = P.computePortfolioPositions(txs, {});
  approx(r.realizedTotal, 750);
});
t('portföy: aşırı satış hatası işaretlenir, negatif pozisyon oluşmaz', () => {
  const txs = [
    { side: 'buy', instrument: 'VCC', quantity: 10, unitPrice: 10, date: '2026-01-01', createdAt: 'a' },
    { side: 'sell', instrument: 'VCC', quantity: 25, unitPrice: 12, date: '2026-01-02', createdAt: 'b' },
  ];
  const r = P.computePortfolioPositions(txs, {});
  assert.strictEqual(r.errors.length, 1);
  approx(r.positions[0].qty, 0);
  approx(r.realizedTotal, 10 * (12 - 10)); // yalnızca eldeki 10 için
});
t('portföy: fiyat yoksa unrealized/marketValue null', () => {
  const r = P.computePortfolioPositions([{ side: 'buy', instrument: 'CER', quantity: 5, unitPrice: 3, date: '2026-01-01', createdAt: 'a' }], {});
  assert.strictEqual(r.positions[0].unrealized, null);
  assert.strictEqual(r.positions[0].marketValue, null);
});

/* ── buildErpJournalRows ─────────────────────────────────────────── */
t('ERP fişi: borç = alacak dengesi ve satır içerikleri', () => {
  const rows = P.buildErpJournalRows({
    ship: { name: 'MV Test', imoNumber: '9074729' }, reportYear: 2026,
    etsLiableTons: 1234.567, carbonPrice: 84, fuelEUPenalty: 25000.456,
  });
  assert.strictEqual(rows.length, 4);
  const debit = rows.reduce((s, r) => s + r.debit, 0);
  const credit = rows.reduce((s, r) => s + r.credit, 0);
  approx(debit, credit, 1e-12);
  approx(rows[0].debit, Math.round(1234.567 * 84 * 100) / 100);
  assert.ok(rows.every(r => r.date === '2026-12-31'));
});
t('ERP fişi: sıfır yükümlülükte satır üretilmez', () => {
  const rows = P.buildErpJournalRows({ ship: { name: 'X' }, reportYear: 2026, etsLiableTons: 0, carbonPrice: 84, fuelEUPenalty: 0 });
  assert.strictEqual(rows.length, 0);
});

/* ── CSV ─────────────────────────────────────────────────────────── */
t('CSV: BOM, ; ayraç ve kaçış kuralları', () => {
  const csv = P.rowsToCsv(['A', 'B'], [['x;y', 'de"f'], ['düz', 'satır\niçi']]);
  assert.ok(csv.startsWith('\uFEFF'));
  const lines = csv.slice(1).split('\r\n');
  assert.strictEqual(lines[0], 'A;B');
  assert.strictEqual(lines[1], '"x;y";"de""f"');
  assert.ok(lines[2].startsWith('düz;"satır'));
});

/* ── Regresyon: mevcut motorlara dokunulmadığının kanıtı ─────────── */
t('regresyon: computeSummary ve FuelEU mevcut davranışını koruyor', () => {
  const ship = { id: 's1', name: 'MV R', type: 'Bulk Carrier', capacityDWT: 58000, grossTonnage: 35000 };
  const voyages = [{ id: 'v1', shipId: 's1', date: '2026-04-01', distance: 3000, dwt: 58000, routeType: 'AB içi', fuelType: 'HFO', fuelAmount: 260, portFuelAmount: 10 }];
  const s = P.computeSummary([ship], voyages, 's1', 84, 'AR4');
  assert.strictEqual(s.voyageCount, 1);
  approx(s.totalCO2, 270 * 3.114, 1e-9); // 260 + 10 liman, HFO Cf
  const feu = P.calculateFuelEUCompliance(voyages, ship, '2026', 'AR4');
  assert.ok(feu && typeof feu.ghgIntensity === 'number' && feu.ghgIntensity > 85 && feu.ghgIntensity < 95);
  const ve = P.calculateVoyageEmissions(voyages[0], ship, 84);
  approx(ve.liableEmission, ve.totalCO2eq * 1.0, 1e-9); // AB içi 2026: %100 × phase-in 1.0
});

console.log(`\n${n} test — TÜMÜ GEÇTİ`);

/* ── v4.1 düzeltme testleri ─────────────────────────────────────── */
const t2 = (name, fn) => { fn(); console.log('✓', name); };
t2('v4.1: karbon fiyatı 0 girilince maliyet 0 (84 fallback hatası giderildi)', () => {
  const ship = { id: 's1', name: 'MV R', type: 'Bulk Carrier', capacityDWT: 58000, grossTonnage: 35000 };
  const v = { id: 'v1', shipId: 's1', date: '2026-04-01', distance: 3000, dwt: 58000, routeType: 'AB içi', fuelType: 'HFO', fuelAmount: 260 };
  const r0 = P.calculateVoyageEmissions(v, ship, 0);
  assert.strictEqual(r0.carbonCost, 0);
  const rU = P.calculateVoyageEmissions(v, ship, undefined);
  approx(rU.carbonCost, rU.liableEmission * 84, 1e-9); // varsayılan korunur
});
console.log('v4.1 testleri geçti');
