# ShipCarbon Pro — AWS Backend

Mimari: **API Gateway (HTTP API) → Lambda (Node.js 20, arm64) → DynamoDB (single-table)**, JWT (HS256) kimlik doğrulama. Sıfır npm bağımlılığı — Lambda çalışma zamanındaki yerleşik AWS SDK v3 kullanılır. Maliyet: DynamoDB on-demand + Lambda; düşük trafikte aylık ~0 $ (free tier içinde).

## Klasör Yapısı

```
backend/
  template.yaml        # SAM altyapı tanımı (API + Lambda + DynamoDB)
  src/index.mjs        # Tüm API rotaları
frontend/
  ship-carbon-pro-aws.jsx   # Yamalı, kullanıma hazır frontend
  api-client.js             # Sadece değişen blok (manuel yama için)
```

## 1. Ön Koşullar

- AWS hesabı + [AWS CLI](https://docs.aws.amazon.com/cli/) (`aws configure` ile kimlik girilmiş)
- [AWS SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html)

## 2. Backend Deploy

```bash
cd backend

# Güçlü bir JWT anahtarı üret (kaydet!)
JWT=$(openssl rand -hex 32)

sam deploy \
  --stack-name shipcarbon-pro \
  --resolve-s3 \
  --capabilities CAPABILITY_IAM \
  --region eu-central-1 \
  --parameter-overrides JwtSecret=$JWT CorsOrigin="*"
```

Deploy bitince çıktıda **ApiUrl** görünür, örn:
`https://abc123xyz.execute-api.eu-central-1.amazonaws.com`

Hızlı test:
```bash
curl https://ABC.execute-api.eu-central-1.amazonaws.com/health
# → {"ok":true,...}
```

## 3. Frontend Bağlantısı

`frontend/ship-carbon-pro-aws.jsx` içinde tek satırı düzenle (satır ~447):

```js
const API_BASE_URL = 'https://ABC.execute-api.eu-central-1.amazonaws.com';
```

Bu dosya, orijinal `ship-carbon-pro-fixed.jsx`'in mock API bloğu gerçek
fetch istemcisiyle değiştirilmiş halidir; başka değişiklik gerekmez.

İlk kullanımda **"Kayıt Ol"** sekmesinden şirketinizi oluşturun
(mock'taki demo veriler artık otomatik yüklenmez).

## 4. API Rotaları

| Metot | Yol | Açıklama |
|---|---|---|
| GET | /health | Sağlık kontrolü (açık) |
| GET | /auth/companies | Şirket listesi (açık) |
| POST | /auth/login, /auth/register | Giriş / kayıt (açık) |
| GET | /auth/session | JWT ile oturum geri yükleme |
| POST | /auth/change-pin, /auth/logout | PIN değiştir / çıkış |
| GET/POST | /ships · PUT/DELETE /ships/{id} | Filo yönetimi |
| GET/POST | /voyages · PUT/DELETE /voyages/{id} | Seferler (hash zincirli) |
| GET/POST | /bdn · POST /bdn/link · PUT /bdn/{id}/verify | BDN |
| GET/POST | /audit | Denetim kaydı (hash zincirli) |
| GET | /chain/verify | Zincir bütünlük kontrolü |
| GET/POST | /verifier/sessions · PUT .../{id}/revoke | Doğrulayıcı erişimi |

## 5. Güvenlik Notları

- PIN'ler **salt + SHA-256** ile hashlenip saklanır; düz metin tutulmaz.
- JWT 12 saat geçerlidir; süre dolunca uygulama otomatik login ekranına döner.
- Prod'da `CorsOrigin` parametresini frontend alan adınla sınırla:
  `--parameter-overrides ... CorsOrigin="https://app.senindomainin.com"`
- DynamoDB'de Point-in-Time Recovery açıktır (35 güne kadar geri yükleme).
- Mock'taki davranış korunmuştur: bilinmeyen kullanıcı + geçerli PIN girildiğinde
  kullanıcı otomatik oluşturulur. Bunu istemiyorsan `index.mjs` içindeki
  `login` fonksiyonundaki otomatik kayıt bloğunu kaldır.

## 6. Güncelleme / Silme

```bash
# Kod değişikliğinden sonra tekrar deploy:
sam deploy --stack-name shipcarbon-pro --resolve-s3 --capabilities CAPABILITY_IAM

# Tüm altyapıyı kaldır (veriler dahil!):
sam delete --stack-name shipcarbon-pro
```

---

## v2 Değişiklikleri (Sorun Analizi ve Düzeltmeler)

### 🔴 P0 — Güvenlik
1. **Girişte otomatik hesap oluşturma kaldırıldı.** Eski davranışta şirket listesi herkese açık olduğundan, herhangi biri herhangi bir şirkete kendi PIN'iyle **yönetici hesabı** açabiliyordu (tam veri sızıntısı). Artık kullanıcıları yalnızca şirket yöneticisi ekler: header'daki 🔑 simgesi → Kullanıcı Yönetimi (yeni `GET/POST/DELETE /users` uçları).
2. **PK/SK enjeksiyonu kapatıldı.** İstek gövdesine `PK`/`SK` alanı ekleyerek başka şirketin verisine yazma açığı vardı; çift katmanlı düzeltildi (gövde temizleme + anahtarların her zaman sona yayılması).
3. **Brute-force kilidi.** 4 haneli PIN'e karşı 5 hatalı denemede 15 dk hesap kilidi. Giriş hataları tek mesajda birleştirildi (kullanıcı adı keşfini önler).
4. **"Hızlı Demo Girişi" kaldırıldı** — gerçek backend'de ilk şirkete yönetici hesabı açmaya çalışıyordu.
5. **Yetki kontrolleri sunucuya taşındı:** BDN doğrulama ve verifier oturumları artık rol bazlı sunucu tarafında da denetleniyor (yalnızca istemci tarafı RBAC atlatılabilirdi).
6. Geçersiz JSON, eksik alanlar ve `null` gövdelerde 500 çökmesi yerine 400 doğrulama hatası.

### 🟠 P1 — Hesaplama Doğruluğu (mevzuat)
7. **Liman yakıtı ETS'e hiç dahil edilmiyordu** → eksik beyan riski. AB temaslı rotalarda rıhtım emisyonları %100 kapsama alındı (Dir. 2003/87/EC Md. 3ga).
8. **Liman yakıtı CII'dan da dışlanıyordu** → CII notu olduğundan iyi görünüyordu. IMO CII tüm yıllık tüketimi kapsar; düzeltildi.
9. **FuelEU'da liman yakıtı Yarı AB rotasında %50 sayılıyordu**; Reg. (EU) 2023/1805 Md. 2'ye göre AB limanındaki rıhtım enerjisi %100 kapsamdadır; düzeltildi.
10. **STS fi faktörü (0.97) tutarsızlığı:** sefer bazlı AER'de uygulanıp yıllık özette atlanıyordu; iki ekran farklı CII gösteriyordu. Eşitlendi.

### 🟡 P2 — Dayanıklılık ve UX
11. JWT süresi dolduğunda uygulama sessizce boş veri göstermek yerine otomatik login ekranına döner (`scp:unauthorized` olayı).
12. Çıkışta LOGOUT audit kaydının kaybolmasına yol açan yarış durumu düzeltildi.
13. Her sayfa yenilemesinde tekrarlanan LOGIN kaydı (audit şişmesi) oturum başına bire indirildi.
14. Sefer formu: DWT gemiden otomatik dolar; negatif değer, gelecek tarih ve eksik ikincil yakıt miktarı engellenir.
15. BDN formu: yalnızca fosil yakıt listeleniyordu; biyoyakıt ve RFNBO eklendi. Miktar > 0 ve tarih doğrulaması eklendi.
16. İkincil yakıt listesine eksik RFNBO kategorisi eklendi.
17. Denetim izi 50 kayıtla sınırlıydı; "Daha fazla göster" eklendi.
18. Zincir doğrulama artık yalnızca sıra numarasını değil, kayıtlarda saklanan `prevHash` ile **gerçek hash bağını** da kontrol eder (silinen/değiştirilen kayıt tespit edilir).
19. Token yokken açılışta gereksiz `/auth/session` çağrısı yapılmaz; XML dosya adındaki güvensiz karakterler temizlenir.

### ⚠️ Deploy notu
v1'i zaten kurduysanız aynı komutla üzerine deploy edin; tablo şeması değişmedi. **Ancak** v1'de login ile otomatik oluşmuş şüpheli kullanıcılar varsa DynamoDB konsolundan `USER#` kayıtlarını gözden geçirin.

---

## v3 Değişiklikleri — Mevzuat ve Hesaplama Düzeltmeleri

Tüm sabitler birincil kaynaklardan doğrulandı (IMO MEPC.353(78)/354(78) tabloları, FuelEU Reg. 2023/1805 Annex IV) ve 41 otomatik testle sınandı.

### CII (IMO)
1. **LNG taşıyıcı referans parametreleri yanlıştı** (tek satır 14405/0.718). MEPC.353(78)'e göre parçalı yapıldı: ≥100k DWT → sabit 9.827; <100k → a=14479×10¹⁰, c=2.673; <65k DWT'de kapasite 65.000'e sabitlenir. Derece sınır vektörleri de düzeltildi (eski kod LNG'ye gaz taşıyıcı vektörünü atamıştı).
2. **Gaz taşıyıcı (LPG) ≥65k DWT dalı eksikti**: a=14405×10⁷, c=2.071 + doğru dd vektörü eklendi.
3. **Bulk ≥279k DWT kapasite sınırı** eklendi (hem referans hem gerçekleşen AER'de).
4. **CII yıl karışması**: dashboard tüm yılların seferlerini tek CII'da topluyordu; CII artık yalnızca son raporlama yılından hesaplanır (maliyet/emisyon toplamları tüm veriyi kapsamaya devam eder). ETS raporu da rapor yılına filtrelenir.

### FuelEU Maritime
5. **Sertifikalı/sertifikasız biyoyakıt-RFNBO ayrımı eklendi** (en kritik düzeltme). Sefer formunda "RED II sertifikalı" kutusu + sertifika E-değeri alanı var. Sertifikalı: yanma CO₂'si biyojenik (0), WtT sertifikadan. Sertifikasız: mevzuat gereği en olumsuz fosil yol = 94 gCO₂eq/MJ. Eski kod her iki durumda da yanlış (WtT=0 + fosil yanma) hesaplıyordu. *E-değeri girilmezse kullanılan varsayılanlar tipik yer tutuculardır; resmi hesapta PoS'taki gerçek değer girilmelidir.*
6. **Ceza formülü düzeltildi** (Annex IV): bölen hedef değil **gerçekleşen** yoğunluktur — eski formül cezayı olduğundan düşük gösteriyordu.
7. **RFNBO ×2 ödül çarpanı** (2025–2033, Md. 5) enerji paydasına eklendi.
8. **Ardışık yıl ceza artışı** (Md. 23/2): n. ardışık açık yılında ×(1+(n−1)/10); önceki yılların verisinden otomatik hesaplanır ve raporda gösterilir.
9. **Yıl filtresi**: FuelEU uyum hesabı tüm yılların yakıtını tek yılın hedefine karşı topluyordu; artık yalnızca raporlama yılı sayılır.

### EU ETS
10. **RED II sertifikalı biyoyakıt/RFNBO yanma CO₂'si sıfır faktörlü** (Dir. 2003/87/EC Annex IV biyokütle kuralı). CH₄/N₂O ve metan kaçağı sayılmaya devam eder. Eski kod sertifikalı biodizeli tam fosil CO₂ ile ücretlendiriyordu.

### Bilinçli olarak DEĞİŞTİRİLMEYENLER (dokümante edildi)
- **VLSFO 3.151 (LFO) faktörüyle eşli**: pratikte VLSFO çoğunlukla rezidüel gradelerde (3.114) raporlanır; iki yaklaşım da savunulabilir olduğundan faktör korundu — BDN'deki gerçek grade'e göre HFO/VLSFO seçimi kullanıcıya bırakıldı.
- **CII'da biyoyakıt Cf değerleri tank-to-wake tutuldu**: IMO'nun biyoyakıt Cf esnekliği (MEPC.1/Circ.905) ayrı bir onay sürecine bağlıdır; muhafazakâr varsayılan korundu.
- **Modellenmeyen mekanizmalar**: FuelEU pooling/banking/borrowing, OPS bağlantı yükümlülüğü (2030+), buz klası/ada muafiyetleri. Bunlar kapsam dışıdır ve rapor dipnotundaki "karar destek aracı" uyarısı bu nedenle geçerliliğini korur.

---

# v4 — Yeni Modüller (Şirket Dashboard, Optimizasyon, Portföy, AIS, DCS/ERP)

Bu sürüm mevcut hesap motorlarına **dokunmadan** (23 birim testiyle doğrulandı, regresyon testleri dahil) şu modülleri ekler. Tablo şeması değişmedi; `sam deploy` ile mevcut stack üzerine dağıtılır, veri kaybı olmaz.

## Yeni Backend Uçları (`src/index.mjs`)
| Uç | Yetki | Açıklama |
|---|---|---|
| `GET /prices` | tüm roller | Şirket fiyat kayıtları (EUA/VCC…), tarih sıralı |
| `POST /prices` | süpervizör+ | `{instrument, price, date, source}` fiyat girişi |
| `DELETE /prices/{id}` | admin | Fiyat kaydı sil |
| `GET /portfolio` | tüm roller | Karbon kredi işlem kayıtları |
| `POST /portfolio` | süpervizör+ | `{side: buy/sell, instrument, quantity, unitPrice, date, registryRef, note}` — satışta eldeki pozisyon sunucuda doğrulanır |
| `DELETE /portfolio/{id}` | admin | İşlem kaydı sil |

## Yeni Frontend Görünümleri
- **Şirket** (konsolide dashboard): tüm filo tek tabloda — gemi başına CO₂, ETS yükümlülüğü/maliyeti, CII notu, FuelEU uyum/ceza; toplam kartları ve gemi bazlı grafikler. Altında **IMO DCS XML** ve **ERP fişi CSV** dışa aktarımı.
- **Optimizasyon**: hız–yakıt–maliyet motoru (günlük tüketim ∝ hız³; referans hızda mevcut `calculateFuelAmount` ile birebir tutarlılığı test edilmiştir). Yakıt + ETS + zaman maliyetini hız taramasıyla minimize eder; optimum hız, tasarruf ve maliyet eğrisi. Ek olarak enerji-eşdeğer **alternatif yakıt karşılaştırması** (ETS + FuelEU WtW/limit, düzenlenebilir fiyatlar).
- **Portföy**: karbon kredisi kayıt/portföy yönetimi — pozisyonlar (ağırlıklı ortalama maliyet), gerçekleşen/gerçekleşmemiş K/Z, işlem geçmişi, fiyat yönetimi + EUA fiyat geçmişi grafiği, güncel EUA fiyatını ETS hesabına tek tıkla uygulama. *Gerçek alım-satım borsa/aracı kurum üzerinden yapılır; bu modül sicil referansıyla kayıt tutar (yasal gereklilik).*
- **AIS**: aisstream.io WebSocket ile canlı konum takibi. Ücretsiz API anahtarı [aisstream.io](https://aisstream.io) adresinden alınır, yalnızca tarayıcıda saklanır. Gemilere 9 haneli MMSI tanımlanır (yeni gemi formunda veya AIS ekranında satır içi). Konumlar tablo + OpenStreetMap bağlantısıyla gösterilir; akış sekme açıkken çalışır.

## Dışa Aktarımlar
- **IMO DCS XML**: yıllık yakıt (tip bazında, liman dahil), mesafe, sefer sayısı; "hours underway" profil hızından **tahminidir** ve `estimated="true"` ile işaretlenir — resmi DCS'te jurnal verisi kullanılmalıdır.
- **ERP fişi CSV**: yıl sonu ETS ve FuelEU tahakkuku için borç/alacak dengeli fiş satırları (`;` ayraçlı + BOM — Türkçe Excel/Logo/Netsis içe aktarımına uygun). 770.10/373.10 (ETS) ve 770.11/373.11 (FuelEU) kodları **şablondur**, hesap planınıza uyarlayın.

## Bilinçli Sınırlar (dürüst kapsam)
- **Canlı EUA borsa feed'i yok**: EEX/ICE gerçek zamanlı verisi lisanslıdır. Fiyatlar manuel/entegrasyonla girilir; kaynak alanı vardır.
- **Borsada emir iletimi yok**: Emisyon tahsisatı ticareti düzenlemeye tabidir; uygulama işlem *kaydı* tutar.
- **Rota optimizasyonu hava/akıntı içermez**: motor, hız–maliyet optimizasyonudur; weather routing ayrı bir servis (ör. DTN/StormGeo) gerektirir.
- AIS verisi VHF/uydu kapsamına bağlıdır; seyir emniyeti aracı değildir.

## Test
`work/test.js` (teslimata dahil değildir, istenirse verilir): hız taraması tutarlılığı, küp yasası monotonluğu, phase-in oranı, enerji korunumu, 94 g/MJ fosil karşılaştırıcısı, portföy muhasebesi (ortalama maliyet, K/Z, aşırı satış), ERP borç=alacak dengesi, CSV kaçış kuralları ve mevcut motor regresyonları — **23/23 geçti**.

---

# v4.1 — Hata Taraması ve Düzeltmeler

Sistematik hata taraması sonucu düzeltilen **gerçek** hatalar (önem sırasıyla):

1. **[KRİTİK / GÜVENLİK] Sunucu tarafı RBAC boşluğu** — `POST/PUT/DELETE /ships`, `POST/PUT/DELETE /voyages`, `POST /bdn`, `POST /bdn/link` uçlarında rol denetimi yoktu; salt-okunur **auditor** rolü bile doğrudan API çağrısıyla gemi silebilir, sefer ekleyebilirdi (UI engelliyordu ama sunucu engellemiyordu). Artık UI izinleriyle birebir: sefer yazma = subay+, gemi yazma/BDN = süpervizör+, gemi silme = yönetici.
2. **[DOĞRULUK] Karbon fiyatı 0 hatası** — `carbonPrice || 84` deseni fiyat 0 girildiğinde sessizce 84 kullanıyordu (0 falsy). `Number.isFinite` kontrolüyle düzeltildi; 0 artık gerçekten 0 maliyet üretir (regresyon testi eklendi).
3. **[MODELLEME] What-If hız senaryosu fizik hatası** — sabit mesafeli seferde yakıt ∝ hız² olmalıyken (günlük ∝ v³ × süre ∝ 1/v) v³ kullanılıyordu; tasarruf abartılıyor ve yeni Optimizasyon modülüyle çelişiyordu. v² olarak düzeltildi.
4. **[VERİ BÜTÜNLÜĞÜ] Sefer doğrulaması** — `POST /voyages` artık `shipId` ve geçerli `date` (YYYY-AA-GG) zorunlu kılar; tarihsiz kayıt CII/FuelEU yıl filtrelerini sessizce bozabiliyordu.

Test durumu: **24/24 geçti** (23 v4 + 1 v4.1 regresyonu). `pure-v4.js` + `test-v4.js` ile yeniden çalıştırılabilir: `node test-v4.js` (test dosyasında `require('./pure.js')` yolunu `pure-v4.js` olarak okuyun ya da dosyayı `pure.js` adıyla koyun).
