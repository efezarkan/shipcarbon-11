const SHIP_PROFILES = {
  'Bulk Carrier': { dailyFuel: 28, defaultSpeed: 13.5, refDWT: 58000 },
  'Tanker':       { dailyFuel: 40, defaultSpeed: 14.0, refDWT: 80000 },
  'Container':    { dailyFuel: 115, defaultSpeed: 17.0, refDWT: 50000 },
  'Ro-Ro':        { dailyFuel: 50, defaultSpeed: 16.0, refDWT: 12000 },
  'LPG':          { dailyFuel: 35, defaultSpeed: 15.0, refDWT: 45000 },
  'LNG':          { dailyFuel: 65, defaultSpeed: 19.0, refDWT: 70000 },
};

const LNG_ENGINE_TYPES = {
  'Otto DF Medium Speed': { label: 'Otto Dual Fuel Medium Speed', cslip: 0.031 },
  'Otto DF Slow Speed':   { label: 'Otto Dual Fuel Slow Speed',   cslip: 0.017 },
  'Diesel DF Slow Speed': { label: 'Diesel Dual Fuel Slow Speed', cslip: 0.002 },
  'LBSI':                 { label: 'Lean-Burn Spark-Ignited',     cslip: 0.026 },
};
const LNG_ENGINE_DEFAULT = 'Otto DF Medium Speed';

const FUEL_EMISSION_FACTORS = {
  'HFO': 3.114, 'VLSFO': 3.151, 'MGO': 3.206, 'LNG': 2.750, 'Methanol': 1.375,
  'LPG_Butane': 3.030, 'LPG_Propane': 3.000,
  'Ethanol': 1.913, 'Biodiesel': 2.834, 'HVO': 3.115,
  'Bio-LNG': 2.750, 'Bio-Methanol': 1.375,
  'e-Diesel': 3.206, 'e-Methanol': 1.375, 'e-LNG': 2.750,
  'H2_Fossil': 0, 'NH3_Fossil': 0, 'Bio-H2': 0, 'e-H2': 0, 'e-NH3': 0,
};

const FUEL_GHG_FACTORS = {
  'HFO':          { co2: 3.114, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'VLSFO':        { co2: 3.151, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'MGO':          { co2: 3.206, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'LNG':          { co2: 2.750, ch4: 0.00000, n2o: 0.00011, isLNG: true },
  'LPG_Butane':   { co2: 3.030, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'LPG_Propane':  { co2: 3.000, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'H2_Fossil':    { co2: 0,     ch4: 0,       n2o: 0.00018, isLNG: false },
  'NH3_Fossil':   { co2: 0,     ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Methanol':     { co2: 1.375, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Ethanol':      { co2: 1.913, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Biodiesel':    { co2: 2.834, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'HVO':          { co2: 3.115, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Bio-LNG':      { co2: 2.750, ch4: 0.00000, n2o: 0.00011, isLNG: true },
  'Bio-Methanol': { co2: 1.375, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'Bio-H2':       { co2: 0,     ch4: 0,       n2o: 0,       isLNG: false },
  'e-Diesel':     { co2: 3.206, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'e-Methanol':   { co2: 1.375, ch4: 0.00005, n2o: 0.00018, isLNG: false },
  'e-LNG':        { co2: 2.750, ch4: 0.00000, n2o: 0.00011, isLNG: true },
  'e-H2':         { co2: 0,     ch4: 0,       n2o: 0,       isLNG: false },
  'e-NH3':        { co2: 0,     ch4: 0.00005, n2o: 0.00018, isLNG: false },
};

const ROUTE_ETS_RATES = { 'AB içi': 1.00, 'Yarı AB': 0.50, 'AB dışı': 0.00 };
const ETS_PHASE_IN = { 2023: 0.00, 2024: 0.40, 2025: 0.70, 2026: 1.00 };
const ETS_GWP = { CO2: 1, CH4: 28, N2O: 265 };

const FUELEU_GWP_SETS = {
  AR4: { CO2: 1, CH4: 25, N2O: 298, label: 'AR4 — Geçerli (FuelEU Annex II)', source: 'Regulation (EU) 2023/1805, Annex II', status: 'current' },
  AR5: { CO2: 1, CH4: 28, N2O: 265, label: 'AR5 — EU ETS / MRV Geçerli', source: 'Delegated Reg. (EU) 2020/1044', status: 'current' },
};
const FUELEU_GWP_DEFAULT = 'AR4';

const FUELEU_TARGETS = {
  2025: { reduction: 0.02, limit: 91.16 * 0.98 },
  2030: { reduction: 0.06, limit: 91.16 * 0.94 },
  2035: { reduction: 0.145, limit: 91.16 * 0.855 },
  2040: { reduction: 0.31, limit: 91.16 * 0.69 },
  2045: { reduction: 0.62, limit: 91.16 * 0.38 },
  2050: { reduction: 0.80, limit: 91.16 * 0.20 },
};

const FUELEU_VLSFO_LCV_PER_TON = 41000;
const FUELEU_PENALTY_PER_TON_VLSFO = 2400;

const FUELEU_FACTORS = {
  'HFO':      { name: 'HFO (Grades RME–RMK)', fuelClass: 'Fossil', lcv: 0.0405, wtT: 13.5, cfCO2: 3.114, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'VLSFO':    { name: 'LFO / VLSFO (Grades RMA–RMD)', fuelClass: 'Fossil', lcv: 0.0410, wtT: 13.2, cfCO2: 3.151, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'MGO':      { name: 'MDO / MGO (Grades DMX–DMB)', fuelClass: 'Fossil', lcv: 0.0427, wtT: 14.4, cfCO2: 3.206, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'LNG':      { name: 'LNG', fuelClass: 'Fossil', lcv: 0.0491, wtT: 18.5, cfCO2: 2.750, cfCH4: 0.00000, cfN2O: 0.00011, cslip: null, cslipByEngine: { 'Otto DF Medium Speed': 0.031, 'Otto DF Slow Speed': 0.017, 'Diesel DF Slow Speed': 0.002, 'LBSI': 0.026 } },
  'LPG_Butane':  { name: 'LPG (Butane)', fuelClass: 'Fossil', lcv: 0.0459, wtT: 7.8, cfCO2: 3.030, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'LPG_Propane': { name: 'LPG (Propane)', fuelClass: 'Fossil', lcv: 0.0461, wtT: 7.8, cfCO2: 3.000, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'H2_Fossil':   { name: 'H₂ (Fossil)', fuelClass: 'Fossil', lcv: 0.1200, wtT: 132.0, cfCO2: 0, cfCH4: 0, cfN2O: 0.00018, cslip: 0.0 },
  'NH3_Fossil':  { name: 'NH₃ (Fossil)', fuelClass: 'Fossil', lcv: 0.0186, wtT: 121.0, cfCO2: 0, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Methanol':    { name: 'Fossil Methanol', fuelClass: 'Fossil', lcv: 0.0199, wtT: 31.3, cfCO2: 1.375, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Ethanol':      { name: 'Ethanol', fuelClass: 'Biofuel', lcv: 0.0267, wtT: null, cfCO2: 1.913, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Biodiesel':    { name: 'Bio-diesel (FAME)', fuelClass: 'Biofuel', lcv: 0.0372, wtT: null, cfCO2: 2.834, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'HVO':          { name: 'HVO', fuelClass: 'Biofuel', lcv: 0.0440, wtT: null, cfCO2: 3.115, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Bio-LNG':      { name: 'Bio-LNG', fuelClass: 'Biofuel', lcv: 0.0491, wtT: null, cfCO2: 2.750, cfCH4: 0.00000, cfN2O: 0.00011, cslip: null, cslipByEngine: { 'Otto DF Medium Speed': 0.031, 'Otto DF Slow Speed': 0.017, 'Diesel DF Slow Speed': 0.002, 'LBSI': 0.026 } },
  'Bio-Methanol': { name: 'Bio-methanol', fuelClass: 'Biofuel', lcv: 0.0199, wtT: null, cfCO2: 1.375, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'Bio-H2':       { name: 'Bio-H₂', fuelClass: 'Biofuel', lcv: 0.1200, wtT: null, cfCO2: 0, cfCH4: 0, cfN2O: 0, cslip: 0.0 },
  'e-Diesel':   { name: 'e-Diesel', fuelClass: 'RFNBO', lcv: 0.0427, wtT: null, cfCO2: 3.206, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'e-Methanol': { name: 'e-Methanol', fuelClass: 'RFNBO', lcv: 0.0199, wtT: null, cfCO2: 1.375, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
  'e-LNG':      { name: 'e-LNG', fuelClass: 'RFNBO', lcv: 0.0491, wtT: null, cfCO2: 2.750, cfCH4: 0.00000, cfN2O: 0.00011, cslip: null, cslipByEngine: { 'Otto DF Medium Speed': 0.031, 'Otto DF Slow Speed': 0.017, 'Diesel DF Slow Speed': 0.002, 'LBSI': 0.026 } },
  'e-H2':       { name: 'e-H₂', fuelClass: 'RFNBO', lcv: 0.1200, wtT: null, cfCO2: 0, cfCH4: 0, cfN2O: 0, cslip: 0.0 },
  'e-NH3':      { name: 'e-NH₃', fuelClass: 'RFNBO', lcv: 0.0186, wtT: null, cfCO2: 0, cfCH4: 0.00005, cfN2O: 0.00018, cslip: 0.0 },
};

const FUEL_CATEGORIES = {
  'Fossil':  ['HFO', 'VLSFO', 'MGO', 'LNG', 'Methanol', 'LPG_Butane', 'LPG_Propane'],
  'Biofuel': ['Biodiesel', 'HVO', 'Bio-LNG', 'Bio-Methanol', 'Ethanol'],
  'RFNBO':   ['e-Diesel', 'e-Methanol', 'e-LNG', 'e-H2', 'e-NH3'],
};

const isLNGTypeFuel = (fuelType) => ['LNG', 'Bio-LNG', 'e-LNG'].includes(fuelType);

const resolveCslip = (fuelType, engineType) => {
  const f = FUELEU_FACTORS[fuelType];
  if (!f) return 0;
  if (f.cslip !== null && f.cslip !== undefined) return f.cslip;
  if (f.cslipByEngine && engineType) return f.cslipByEngine[engineType] || 0.031;
  if (f.cslipByEngine) return f.cslipByEngine[LNG_ENGINE_DEFAULT] || 0.031;
  return 0;
};

const FUELEU_SCOPE_RATES = { 'AB içi': 1.00, 'Yarı AB': 0.50, 'AB dışı': 0.00 };
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

/* MEPC.353(78) Tablo 1 + MEPC.354(78) dd vektörleri.
   DÜZELTME (v3): LNG ve Gaz taşıyıcı (LPG) parametreleri DWT'ye göre
   parçalıdır ve eski kod bunu tek satıra indirgemişti (LNG'ye üstelik
   gaz taşıyıcının dd vektörü atanmıştı). Bulk ≥279k DWT'de kapasite
   279.000'e sabitlenir (Capacity cap). Kaynak: IMO MEPC 78/17/Add.1. */
const CII_REF_LINES = {
  'Bulk Carrier': { a: 4745, c: 0.622, d: [0.86, 0.94, 1.06, 1.18] },
  'Tanker':       { a: 5247, c: 0.610, d: [0.82, 0.93, 1.08, 1.28] },
  'Container':    { a: 1984, c: 0.489, d: [0.83, 0.94, 1.07, 1.19] },
  'Ro-Ro':        { a: 5739, c: 0.631, d: [0.86, 0.94, 1.06, 1.16] },
};

// CII hesabında kullanılacak Kapasite (MEPC.353(78) Capacity sütunu)
const getCIICapacity = (shipType, dwt) => {
  const w = parseFloat(dwt) || 0;
  if (shipType === 'Bulk Carrier' && w >= 279000) return 279000;
  if (shipType === 'LNG' && w < 65000) return 65000; // LNG <65k: Capacity=65.000
  return w;
};

// Gemi tipi + DWT'ye göre referans hattı parametreleri {a, c, d}
const getCIIRefParams = (shipType, dwt) => {
  const w = parseFloat(dwt) || 0;
  if (shipType === 'LNG') {
    if (w >= 100000) return { a: 9.827, c: 0.000, d: [0.89, 0.98, 1.06, 1.13] };
    return { a: 14479e10, c: 2.673, d: [0.78, 0.92, 1.10, 1.37] }; // <100k (kapasite <65k'da 65k'ya sabitlenir)
  }
  if (shipType === 'LPG') {
    if (w >= 65000) return { a: 14405e7, c: 2.071, d: [0.81, 0.91, 1.12, 1.44] };
    return { a: 8104, c: 0.639, d: [0.85, 0.95, 1.06, 1.25] };
  }
  return CII_REF_LINES[shipType] || null;
};

const CII_REDUCTION_Z = {
  2023: 5, 2024: 7, 2025: 9, 2026: 11,
  2027: 13.625, 2028: 16.250, 2029: 18.875, 2030: 21.500,
};

const REPORT_FOOTER_TEXT = "Bu rapor karar destek aracı niteliğindedir. Resmi IMO DCS, CII ve EU ETS beyanı için akredite doğrulayıcı onayı gereklidir.";
const BDN_DISCLAIMER = "ℹ️ Yakıt verileri BDN ile doğrulanmamıştır. Klas kuruluşu onayı için BDN tabanlı veri kaynağı zorunludur.";
const CII_ANNUAL_DISCLAIMER = "* CII notu tüm yıl seferlerinin toplamına dayanır. Resmi CII, takvim yılı sonu klas kuruluşunca doğrulanır.";

/* ═══════════════════════════════════════════════════════════════════
   RBAC — Roller ve izinler
   ═══════════════════════════════════════════════════════════════════ */
const ROLES = {
  officer: { label: 'Gemi Subayı', badge: '⚓', can: ['create_voyage', 'view_dashboard', 'view_fleet'], color: 'blue' },
  superintendent: { label: 'Süpervizör', badge: '🏢', can: ['create_voyage', 'delete_voyage', 'create_ship', 'view_dashboard', 'view_fleet', 'view_whatif', 'view_report', 'export_report', 'view_audit', 'edit_settings', 'upload_bdn', 'verify_bdn', 'create_verifier'], color: 'cyan' },
  auditor: { label: 'Doğrulayıcı', badge: '🔍', can: ['view_dashboard', 'view_fleet', 'view_report', 'export_report', 'view_audit'], color: 'purple', readOnly: true },
  company_admin: { label: 'Şirket Yöneticisi', badge: '👑', can: ['all'], color: 'amber' },
};

const ROLE_OPTIONS = [
  { value: 'officer',        label: '⚓ Gemi Subayı' },
  { value: 'superintendent', label: '🏢 Süpervizör' },
  { value: 'auditor',        label: '🔍 Doğrulayıcı' },
  { value: 'company_admin',  label: '👑 Şirket Yöneticisi' },
];

const checkPermission = (role, action) => {
  const r = ROLES[role];
  if (!r) return false;
  if (r.can.includes('all')) return true;
  return r.can.includes(action);
};

/* ═══════════════════════════════════════════════════════════════════
   CALCULATIONS — CII, ETS, FuelEU hesaplama motoru
   ═══════════════════════════════════════════════════════════════════ */
const getEtsPhaseIn = (dateStr) => {
  const y = parseInt((dateStr || '').substring(0, 4)) || new Date().getFullYear();
  if (y < 2024) return 0.00;
  return ETS_PHASE_IN[y] !== undefined ? ETS_PHASE_IN[y] : 1.00;
};

const getZFactor = (year) => {
  const y = parseInt(year) || new Date().getFullYear();
  return CII_REDUCTION_Z[y] !== undefined ? CII_REDUCTION_Z[y] : null;
};

const getCIIGrade = (attainedCII, dwt, shipType, year) => {
  const capacity = getCIICapacity(shipType, dwt);
  const params = getCIIRefParams(shipType, dwt);
  if (!params || !capacity || !attainedCII || attainedCII <= 0)
    return { grade: '-', label: '⚠️ Veri Eksik', required: 0, boundaries: null, disclaimer: false };
  const z = getZFactor(year);
  if (z === null)
    return { grade: '?', label: '⚠️ 2031+ IMO faktör yok', required: 0, boundaries: null, disclaimer: true };
  const ciiRef = params.a * Math.pow(capacity, -params.c);
  const ciiRequired = ciiRef * (1 - z / 100);
  const bounds = { A: ciiRequired * params.d[0], B: ciiRequired * params.d[1], C: ciiRequired * params.d[2], D: ciiRequired * params.d[3] };
  let grade, label;
  if (attainedCII <= bounds.A) { grade = 'A'; label = 'A - Mükemmel'; }
  else if (attainedCII <= bounds.B) { grade = 'B'; label = 'B - İyi'; }
  else if (attainedCII <= bounds.C) { grade = 'C'; label = 'C - Hedef'; }
  else if (attainedCII <= bounds.D) { grade = 'D'; label = 'D - Riskli'; }
  else { grade = 'E'; label = 'E - Kritik'; }
  return { grade, label, required: ciiRequired, boundaries: bounds, disclaimer: false };
};

const getGradeColor = (grade) =>
  ({ A: '#16a34a', B: '#2563eb', C: '#ca8a04', D: '#ea580c', E: '#dc2626' }[grade] || '#6b7280');

const getComplianceScope = (ship) => {
  const gt = ship?.grossTonnage || 0;
  return { cii: gt >= 5000, euEts: gt >= 5000, fuelEU: gt >= 5000, gt };
};

const validateIMO = (imo) => {
  if (!imo) return { valid: true, msg: '' };
  const digits = String(imo).replace(/\D/g, '');
  if (digits.length !== 7) return { valid: false, msg: '7 hane olmalıdır' };
  if (digits[0] === '0') return { valid: false, msg: 'İlk hane 0 olamaz' };
  const weights = [7, 6, 5, 4, 3, 2];
  const sum = weights.reduce((acc, w, i) => acc + w * parseInt(digits[i]), 0);
  const check = sum % 10;
  if (check !== parseInt(digits[6])) return { valid: false, msg: `Kontrol rakamı hatalı. Beklenen: ${check}` };
  return { valid: true, msg: '' };
};

const calcEtsCO2eqForFuel = (fuelTons, fuelType, voyageYear, engineType, redCertified) => {
  const factors = FUEL_GHG_FACTORS[fuelType] || FUEL_GHG_FACTORS['HFO'];
  // DÜZELTME (v3): RED II sertifikalı biyoyakıt/RFNBO'nun yanma CO₂'si
  // EU ETS'te sıfır faktörlüdür (Dir. 2003/87/EC Annex IV — biyokütle).
  // CH₄/N₂O ve metan kaçağı fiziksel emisyon olarak sayılmaya devam eder.
  const isAlt = (FUELEU_FACTORS[fuelType]?.fuelClass || 'Fossil') !== 'Fossil';
  const co2Factor = (isAlt && redCertified) ? 0 : factors.co2;
  let cslip = 0;
  if (factors.isLNG) {
    const engKey = engineType || LNG_ENGINE_DEFAULT;
    cslip = (LNG_ENGINE_TYPES[engKey] || LNG_ENGINE_TYPES[LNG_ENGINE_DEFAULT]).cslip;
  }
  const combustedFuel = fuelTons * (1 - cslip);
  const slippedFuel = fuelTons * cslip;
  const co2 = combustedFuel * co2Factor;
  const ch4 = combustedFuel * factors.ch4 + slippedFuel;
  const n2o = combustedFuel * factors.n2o;
  let co2eq;
  if (voyageYear >= 2026) co2eq = co2 * ETS_GWP.CO2 + ch4 * ETS_GWP.CH4 + n2o * ETS_GWP.N2O;
  else co2eq = co2;
  return { co2, ch4, n2o, co2eq, fuel: fuelTons };
};

const calculateCorrectedCII_CO2 = (voyage) => {
  const fuel1 = parseFloat(voyage.fuelAmount) || 0;
  const fuel2 = parseFloat(voyage.secondaryFuelAmount) || 0;
  // DÜZELTME: IMO CII takvim yılındaki TÜM yakıt tüketimini kapsar (liman dahil).
  // Liman yakıtı önceden hesaba katılmıyordu → CII olduğundan iyi görünüyordu.
  const portFuel = parseFloat(voyage.portFuelAmount) || 0;
  const type1 = voyage.fuelType || 'HFO';
  const type2 = voyage.secondaryFuelType;
  const factors1 = FUEL_GHG_FACTORS[type1] || FUEL_GHG_FACTORS['HFO'];
  const factors2 = type2 ? (FUEL_GHG_FACTORS[type2] || FUEL_GHG_FACTORS['HFO']) : null;
  const rawCO2g = ((fuel1 + portFuel) * factors1.co2 + (type2 && fuel2 > 0 ? fuel2 * factors2.co2 : 0)) * 1_000_000;
  const fcDed  = (parseFloat(voyage.fcVoyageDeduction) || 0) * factors1.co2 * 1_000_000;
  const fcBoil = (parseFloat(voyage.fcBoiler)          || 0) * factors1.co2 * 1_000_000;
  const fcOth  = (parseFloat(voyage.fcOthers)          || 0) * factors1.co2 * 1_000_000;
  const fcElec = (parseFloat(voyage.fcElectrical)      || 0) * 1_000_000;
  return Math.max(0, rawCO2g - fcDed - fcBoil - fcOth - fcElec);
};

const calcWtWIntensity = (fuelType, gwpVersion, engineType) => {
  const f = FUELEU_FACTORS[fuelType];
  if (!f) return 0;
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  const cslip = resolveCslip(fuelType, engineType);
  const combustion = (1 - cslip) * (f.cfCO2 * gwp.CO2 + f.cfCH4 * gwp.CH4 + f.cfN2O * gwp.N2O);
  const slip = cslip * gwp.CH4;
  const wtT = f.wtT !== null ? f.wtT : 0;
  return wtT + (combustion + slip) / f.lcv;
};

const getFuelEUTarget = (year) => {
  const y = parseInt(year) || 2025;
  if (y >= 2050) return FUELEU_TARGETS[2050];
  if (y >= 2045) return FUELEU_TARGETS[2045];
  if (y >= 2040) return FUELEU_TARGETS[2040];
  if (y >= 2035) return FUELEU_TARGETS[2035];
  if (y >= 2030) return FUELEU_TARGETS[2030];
  return FUELEU_TARGETS[2025];
};

/* ═══ FuelEU v3 — Reg. (EU) 2023/1805 tam uyumlu hesap ═══
   Düzeltmeler:
   1. Rapor yılı filtresi: eski kod TÜM yılların seferlerini tek yılın
      hedefine karşı topluyordu (Md. 4: yıllık ortalama yoğunluk).
   2. Sertifikalı biyoyakıt/RFNBO: yanma CO₂'si biyojenik = 0 sayılır,
      WtT sertifikadaki E-değerinden gelir (Annex I / RED II).
   3. Sertifikasız biyoyakıt/RFNBO: "en olumsuz fosil yol" = WtW 94 g/MJ
      fosil karşılaştırıcısı uygulanır (Annex II dipnotu).
   4. Ceza formülü Annex IV: bölen HEDEF değil GERÇEKLEŞEN yoğunluktur.
   5. RFNBO ödül çarpanı ×2 (2025–2033, Md. 5) enerji paydasında.
   6. Ardışık yıl ceza artışı: n. ardışık açık yılında ×(1+(n−1)/10) (Md. 23). */
const FOSSIL_COMPARATOR_WTW = 94.0; // gCO2eq/MJ — RED II fosil karşılaştırıcısı
const RFNBO_REWARD_START = 2025, RFNBO_REWARD_END = 2033;
// Sertifika E-değeri girilmezse kullanılacak TİPİK varsayılanlar (gCO2eq/MJ).
// UYARI: Resmi hesapta RED II Sürdürülebilirlik Kanıtı'ndaki (PoS) gerçek
// değer girilmelidir; bunlar yalnızca planlama için makul yer tutuculardır.
const WTT_CERT_DEFAULTS = {
  'Biodiesel': 16.0, 'HVO': 16.0, 'Bio-LNG': 14.0, 'Bio-Methanol': 10.0,
  'Ethanol': 25.0, 'Bio-H2': 10.0,
  'e-Diesel': 12.0, 'e-Methanol': 10.0, 'e-LNG': 12.0, 'e-H2': 3.6, 'e-NH3': 5.0,
};
const fuelClassOf = (fType) => FUELEU_FACTORS[fType]?.fuelClass || 'Fossil';

// Tek raporlama yılı için çekirdek hesap (ceza çarpanı hariç)
const computeFuelEUYear = (yearVoyages, ship, reportYear, gwpVersion) => {
  if (!yearVoyages || yearVoyages.length === 0) return null;
  const scope = getComplianceScope(ship);
  if (!scope.fuelEU) return null;
  const yr = parseInt(reportYear) || 2025;
  const target = getFuelEUTarget(reportYear);
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  const fuelAgg = {};
  let totalEnergyInScope = 0, totalWtTEmissions = 0, totalTtWEmissions = 0;
  let rfnboRewardApplied = false;
  const engineType = ship?.engineType || LNG_ENGINE_DEFAULT;

  const processFuelEntry = (fuelMassTons, fType, scopeRate, portFuelTons, certified, wtTCertRaw) => {
    const f = FUELEU_FACTORS[fType];
    if (!f) return;
    const portScopeRate = scopeRate > 0 ? 1.0 : 0; // AB temaslı rota → liman %100
    const inScopeMassTons = fuelMassTons * scopeRate + portFuelTons * portScopeRate;
    if (inScopeMassTons <= 0) return;
    const cls = f.fuelClass;
    const isAlt = cls !== 'Fossil';
    const cslip = resolveCslip(fType, engineType);
    const grams = inScopeMassTons * 1e6;
    const energyMJ = grams * f.lcv;
    // Yanma CO₂: sertifikalı bio/RFNBO'da biyojenik → 0; aksi halde fosil eşdeğeri
    const cfCO2eff = (isAlt && certified) ? 0 : f.cfCO2;
    const combustionPerGram = (1 - cslip) * (cfCO2eff * gwp.CO2 + f.cfCH4 * gwp.CH4 + f.cfN2O * gwp.N2O);
    const slipPerGram = cslip * gwp.CH4;
    const ttWEmissions = grams * (combustionPerGram + slipPerGram);
    // WtT g/MJ:
    let wtTperMJ;
    if (!isAlt) wtTperMJ = f.wtT !== null && f.wtT !== undefined ? f.wtT : 0;
    else if (certified) {
      const certVal = parseFloat(wtTCertRaw);
      wtTperMJ = Number.isFinite(certVal) && certVal >= 0 ? certVal : (WTT_CERT_DEFAULTS[fType] ?? 20);
    } else {
      // Sertifikasız: toplam WtW tam 94 g/MJ olacak şekilde tamamla
      const ttWIntensity = energyMJ > 0 ? ttWEmissions / energyMJ : 0;
      wtTperMJ = Math.max(0, FOSSIL_COMPARATOR_WTW - ttWIntensity);
    }
    const wtTEmissions = energyMJ * wtTperMJ;
    // RFNBO ödül çarpanı yalnızca sertifikalı RFNBO'da, 2025–2033
    const rewardMult = (cls === 'RFNBO' && certified && yr >= RFNBO_REWARD_START && yr <= RFNBO_REWARD_END) ? 2 : 1;
    if (rewardMult === 2) rfnboRewardApplied = true;
    totalEnergyInScope += energyMJ * rewardMult;
    totalWtTEmissions += wtTEmissions;
    totalTtWEmissions += ttWEmissions;
    const key = fType + (isAlt ? (certified ? ' (RED II ✓)' : ' (sertifikasız)') : '');
    if (!fuelAgg[key]) fuelAgg[key] = { baseFuel: fType, massTons: 0, energyMJ: 0, wtT: 0, ttW: 0, certified: !!certified, rewardMult, wtw: 0 };
    fuelAgg[key].massTons += inScopeMassTons;
    fuelAgg[key].energyMJ += energyMJ;
    fuelAgg[key].wtT += wtTEmissions;
    fuelAgg[key].ttW += ttWEmissions;
  };

  yearVoyages.forEach(v => {
    const scopeRate = FUELEU_SCOPE_RATES[v.routeType] || 0;
    const primaryFuel = parseFloat(v.fuelAmount) || 0;
    const portFuel = parseFloat(v.portFuelAmount) || 0;
    const primaryType = v.fuelType || 'HFO';
    processFuelEntry(primaryFuel, primaryType, scopeRate, portFuel, !!v.redCertified, v.wtTCert);
    const secFuel = parseFloat(v.secondaryFuelAmount) || 0;
    const secType = v.secondaryFuelType;
    if (secType && secFuel > 0) processFuelEntry(secFuel, secType, scopeRate, 0, !!v.secondaryRedCertified, v.secondaryWtTCert);
  });

  if (totalEnergyInScope === 0) return null;
  Object.values(fuelAgg).forEach(a => { a.wtw = a.energyMJ > 0 ? (a.wtT + a.ttW) / a.energyMJ : 0; });
  const ghgIntensity = (totalWtTEmissions + totalTtWEmissions) / totalEnergyInScope;
  const complianceBalance = (target.limit - ghgIntensity) * totalEnergyInScope;
  const complianceBalanceTons = complianceBalance / 1000000;
  let penaltyBase = 0, nonCompliantVLSFOTons = 0;
  if (complianceBalance < 0 && ghgIntensity > 0) {
    // Annex IV: Ceza = |CB| / (GHGIE_gerçekleşen × 41.000) × 2.400 €
    nonCompliantVLSFOTons = Math.abs(complianceBalance) / (ghgIntensity * FUELEU_VLSFO_LCV_PER_TON);
    penaltyBase = nonCompliantVLSFOTons * FUELEU_PENALTY_PER_TON_VLSFO;
  }
  return { target, fuelAgg, totalEnergyInScope, totalWtTEmissions, totalTtWEmissions, ghgIntensity, complianceBalance, complianceBalanceTons, isCompliant: complianceBalance >= 0, nonCompliantVLSFOTons, penaltyBase, rfnboRewardApplied, reportYear };
};

// Dış API (imza değişmedi): tüm sefer listesi verilir, yıl filtresi içeride yapılır,
// ardışık yıl ceza çarpanı önceki yılların verisinden hesaplanır.
const calculateFuelEUCompliance = (voyages, ship, reportYear, gwpVersion) => {
  if (!voyages || voyages.length === 0) return null;
  const yearOf = (v) => (v.date || '').substring(0, 4);
  const res = computeFuelEUYear(voyages.filter(v => yearOf(v) === String(reportYear)), ship, reportYear, gwpVersion);
  if (!res) return null;
  // Ardışık açık yılı sayısı (Md. 23(2)): mevcut yıl dahil geriye doğru
  let consecutiveDeficitYears = res.isCompliant ? 0 : 1;
  if (!res.isCompliant) {
    for (let y = parseInt(reportYear) - 1; y >= 2025; y--) {
      const prev = computeFuelEUYear(voyages.filter(v => yearOf(v) === String(y)), ship, String(y), gwpVersion);
      if (prev && !prev.isCompliant) consecutiveDeficitYears++;
      else break;
    }
  }
  const penaltyMultiplier = consecutiveDeficitYears > 1 ? 1 + (consecutiveDeficitYears - 1) / 10 : 1;
  const penalty = res.penaltyBase * penaltyMultiplier;
  return { ...res, penalty, penaltyMultiplier, consecutiveDeficitYears };
};

const REF_LCV = FUELEU_FACTORS['HFO'].lcv;

const calculateFuelAmount = (distance, dwt, shipType, fuelType, customDailyFuel, speedOverride) => {
  const d = parseFloat(distance) || 0;
  const w = parseFloat(dwt) || 0;
  const profile = SHIP_PROFILES[shipType];
  if (!d || !profile) return 0;
  const daily = parseFloat(customDailyFuel) || profile.dailyFuel;
  const speed = parseFloat(speedOverride) || profile.defaultSpeed;
  const effectiveFuelPerNm = daily / (speed * 24);
  const dwtFactor = (w > 0 && profile.refDWT > 0) ? Math.pow(w / profile.refDWT, 2 / 3) : 1;
  const fuelLCV = (FUELEU_FACTORS[fuelType] || FUELEU_FACTORS['HFO']).lcv;
  return effectiveFuelPerNm * dwtFactor * (REF_LCV / fuelLCV) * d;
};

const calculateVoyageEmissions = (voyage, ship, carbonPrice) => {
  const distance = parseFloat(voyage.distance) || 0;
  const voyageYear = parseInt(voyage.date?.substring(0, 4)) || 2024;
  const engineType = ship?.engineType || LNG_ENGINE_DEFAULT;
  const fuel1 = parseFloat(voyage.fuelAmount) || 0;
  const type1 = voyage.fuelType || 'HFO';
  const r1 = calcEtsCO2eqForFuel(fuel1, type1, voyageYear, engineType, !!voyage.redCertified);
  const fuel2 = parseFloat(voyage.secondaryFuelAmount) || 0;
  const type2 = voyage.secondaryFuelType;
  const r2 = (type2 && fuel2 > 0)
    ? calcEtsCO2eqForFuel(fuel2, type2, voyageYear, engineType, !!voyage.secondaryRedCertified)
    : { co2: 0, ch4: 0, n2o: 0, co2eq: 0, fuel: 0 };
  // DÜZELTME: Liman yakıtı ETS ve toplamlarda hiç sayılmıyordu (eksik beyan riski).
  // EU ETS'te AB limanındaki rıhtım emisyonları %100 kapsamdadır (Dir. 2003/87/EC Md. 3ga);
  // AB temaslı rotalarda (AB içi / Yarı AB) liman yakıtına tam oran uygulanır.
  const portFuel = parseFloat(voyage.portFuelAmount) || 0;
  const rPort = portFuel > 0
    ? calcEtsCO2eqForFuel(portFuel, type1, voyageYear, engineType, !!voyage.redCertified)
    : { co2: 0, ch4: 0, n2o: 0, co2eq: 0, fuel: 0 };
  const totalFuel = r1.fuel + r2.fuel + rPort.fuel;
  const totalCO2 = r1.co2 + r2.co2 + rPort.co2;
  const totalCO2eq = r1.co2eq + r2.co2eq + rPort.co2eq;
  const routeRate = ROUTE_ETS_RATES[voyage.routeType] || 0;
  const portEtsRate = voyage.routeType === 'AB dışı' ? 0 : 1.0;
  const phaseIn = getEtsPhaseIn(voyage.date);
  const scope = getComplianceScope(ship);
  const liableEmission = scope.euEts
    ? (((r1.co2eq + r2.co2eq) * routeRate + rPort.co2eq * portEtsRate) * phaseIn)
    : 0;
  /* DÜZELTME (v4.1): "carbonPrice || 84" deseni fiyat 0 girildiğinde sessizce
     84'e dönüyordu (0 falsy) — maliyeti sıfır fiyatla görmek imkânsızdı. */
  const effCarbonPrice = Number.isFinite(parseFloat(carbonPrice)) ? parseFloat(carbonPrice) : 84;
  const carbonCost = liableEmission * effCarbonPrice;
  const capDWT = getCIICapacity(ship?.type, ship?.capacityDWT || parseFloat(voyage.dwt) || 0);
  const factors1 = FUEL_GHG_FACTORS[type1] || FUEL_GHG_FACTORS['HFO'];
  const factors2 = type2 ? (FUEL_GHG_FACTORS[type2] || FUEL_GHG_FACTORS['HFO']) : null;
  const correctedCO2g = calculateCorrectedCII_CO2(voyage);
  const fi = (voyage.stsSts && ship?.type === 'Tanker') ? 0.97 : 1.0;
  const contributingAER = (capDWT && distance && fi) ? correctedCO2g / (fi * capDWT * distance) : 0;
  let riskStatus = '⚪ Veri bekleniyor...';
  if (totalFuel > 0) {
    if (carbonCost > 500000) riskStatus = '🔴 KRİTİK';
    else if (carbonCost > 200000) riskStatus = '🟠 UYARI';
    else if (carbonCost > 0) riskStatus = '🟢 OPTİMUM';
    else if (phaseIn === 0) riskStatus = '⚪ ETS öncesi';
    else riskStatus = '⚪ AB dışı';
  }
  const totalCH4 = r1.ch4 + r2.ch4 + rPort.ch4;
  const totalN2O = r1.n2o + r2.n2o + rPort.n2o;
  const engCslip = (LNG_ENGINE_TYPES[engineType] || LNG_ENGINE_TYPES[LNG_ENGINE_DEFAULT]).cslip;
  const slippedCH4 = (factors1.isLNG ? fuel1 * engCslip : 0)
                   + (factors2?.isLNG ? fuel2 * engCslip : 0);
  return {
    totalCO2, totalCO2eq, totalCH4, totalN2O, slippedCH4,
    liableEmission, carbonCost, contributingAER, riskStatus,
    fuel: totalFuel, phaseIn, voyageYear, engineType,
    fuelBreakdown: {
      primary: { type: type1, amount: fuel1, co2: r1.co2, ch4: r1.ch4, n2o: r1.n2o, co2eq: r1.co2eq },
      secondary: (type2 && fuel2 > 0) ? { type: type2, amount: fuel2, co2: r2.co2, ch4: r2.ch4, n2o: r2.n2o, co2eq: r2.co2eq } : null,
    },
  };
};

const computeSummary = (fleet, voyages, selectedShip, carbonPrice, gwpVersion) => {
  const ship = fleet.find(s => s.id === selectedShip);
  const sv = voyages.filter(v => v.shipId === selectedShip);
  const empty = { totalCO2: 0, totalCO2eq: 0, totalCost: 0, totalDistance: 0, totalFuel: 0, avgCII: 0, ciiDWT: 0, overallCIIResult: { grade: '-', label: 'Veri yok', required: 0, boundaries: null, disclaimer: false }, voyageCount: 0, euCost: 0, halfEuCost: 0, monthlyData: [], routeBreakdown: [], latestYear: new Date().getFullYear().toString() };
  if (!ship || sv.length === 0) return empty;
  let totalCO2 = 0, totalCO2eq = 0, totalCost = 0, totalDistance = 0, totalFuel = 0;
  let dwtDistSum = 0, euCost = 0, halfEuCost = 0, correctedCO2gSum = 0;
  const monthlyMap = {}, routeMap = { 'AB içi': 0, 'Yarı AB': 0, 'AB dışı': 0 };
  // DÜZELTME (v3): CII takvim yılı bazlı bir göstergedir. Eski kod tüm yılların
  // seferlerini tek havuzda toplayıp son yılın hedefine göre notluyordu.
  // Artık CII yalnızca son raporlama yılının seferlerinden hesaplanır;
  // maliyet/emisyon toplamları ise tüm veriyi kapsamaya devam eder.
  const latestDate = sv.reduce((mx, v) => ((v.date || '') > mx ? v.date : mx), '');
  const latestYear = latestDate.substring(0, 4) || new Date().getFullYear().toString();
  const ciiCapacity = getCIICapacity(ship.type, ship.capacityDWT || 0);
  sv.forEach(v => {
    const r = calculateVoyageEmissions(v, ship, carbonPrice);
    const dist = parseFloat(v.distance) || 0;
    const dwt = parseFloat(v.dwt) || 0;
    totalCO2 += r.totalCO2;
    totalCO2eq += r.totalCO2eq;
    totalCost += r.carbonCost;
    totalDistance += dist;
    totalFuel += r.fuel;
    if (v.routeType === 'AB içi') euCost += r.carbonCost;
    else if (v.routeType === 'Yarı AB') halfEuCost += r.carbonCost;
    const m = (v.date || '').substring(0, 7) || 'Bilinmiyor';
    if (!monthlyMap[m]) monthlyMap[m] = { month: m, co2: 0, cost: 0 };
    monthlyMap[m].co2 += r.totalCO2;
    monthlyMap[m].cost += r.carbonCost;
    if (routeMap[v.routeType] === undefined) routeMap[v.routeType] = 0;
    routeMap[v.routeType] += r.totalCO2;
    // CII: yalnızca son raporlama yılı + sınırlı kapasite + STS fi tutarlılığı
    if ((v.date || '').startsWith(latestYear)) {
      const fi = (v.stsSts && ship.type === 'Tanker') ? 0.97 : 1.0;
      const cap = ciiCapacity || getCIICapacity(ship.type, dwt);
      dwtDistSum += cap * dist;
      correctedCO2gSum += calculateCorrectedCII_CO2(v) / fi;
    }
  });
  const avgCII = dwtDistSum > 0 ? correctedCO2gSum / dwtDistSum : 0;
  const ciiDWT = ship.capacityDWT || (totalDistance > 0 ? dwtDistSum / totalDistance : 0);
  const overallCIIResult = getCIIGrade(avgCII, ciiDWT, ship.type, latestYear);
  return { totalCO2, totalCO2eq, totalCost, totalDistance, totalFuel, avgCII, ciiDWT, overallCIIResult, euCost, halfEuCost, voyageCount: sv.length, monthlyData: Object.values(monthlyMap).sort((a, b) => a.month.localeCompare(b.month)), routeBreakdown: Object.entries(routeMap).filter(([, v]) => v > 0).map(([name, value]) => ({ name, value: Math.round(value) })), latestYear };
};

/* ═══════════════════════════════════════════════════════════════════
   v4 — OPTİMİZASYON MOTORU (hız / yakıt / maliyet)
   Model: günlük tüketim ∝ hız³ (küp yasası), referans = gemi profili.
   Mevcut calculateFuelAmount ile TAM tutarlıdır: referans hızda ikisi
   birebir aynı yakıtı verir (birim testiyle doğrulanır).
   ═══════════════════════════════════════════════════════════════════ */
const computeSpeedSweep = (params) => {
  const {
    shipType, dwt, engineType, fuelType = 'HFO', distance, routeType = 'AB içi',
    year = 2026, fuelPrice = 500, carbonPrice = 84, dayCost = 0,
    dailyFuelOverride, redCertified = false,
  } = params || {};
  const profile = SHIP_PROFILES[shipType];
  const d = parseFloat(distance) || 0;
  if (!profile || d <= 0) return null;
  const vRef = profile.defaultSpeed;
  const ovr = parseFloat(dailyFuelOverride);
  const dailyRef = ovr > 0 ? ovr : profile.dailyFuel;
  const w = parseFloat(dwt) || 0;
  const dwtFactor = (w > 0 && profile.refDWT > 0) ? Math.pow(w / profile.refDWT, 2 / 3) : 1;
  const lcvRatio = REF_LCV / ((FUELEU_FACTORS[fuelType] || FUELEU_FACTORS['HFO']).lcv);
  const routeRate = ROUTE_ETS_RATES[routeType] !== undefined ? ROUTE_ETS_RATES[routeType] : 0;
  const yr = parseInt(year) || 2026;
  const phaseIn = getEtsPhaseIn(String(yr) + '-06-15');
  const capacity = getCIICapacity(shipType, w) || w;
  const fp = Math.max(0, parseFloat(fuelPrice) || 0);
  const cp = Math.max(0, parseFloat(carbonPrice) || 0);
  const dc = Math.max(0, parseFloat(dayCost) || 0);
  const points = [];
  const vMin = Math.max(6, Math.round(vRef * 0.6 * 4) / 4);
  const vMax = Math.round(vRef * 1.1 * 4) / 4;
  for (let v = vMin; v <= vMax + 1e-9; v += 0.25) {
    const speed = Math.round(v * 100) / 100;
    const days = d / (speed * 24);
    const dailyAtV = dailyRef * Math.pow(speed / vRef, 3);
    const fuelTons = dailyAtV * days * dwtFactor * lcvRatio;
    const em = calcEtsCO2eqForFuel(fuelTons, fuelType, yr, engineType, redCertified);
    const etsCost = em.co2eq * routeRate * phaseIn * cp;
    const fuelCost = fuelTons * fp;
    const timeCost = days * dc;
    const total = fuelCost + etsCost + timeCost;
    const aer = (capacity > 0 && d > 0) ? (em.co2 * 1e6) / (capacity * d) : 0;
    points.push({ speed, days, fuelTons, co2: em.co2, co2eq: em.co2eq, fuelCost, etsCost, timeCost, total, aer });
  }
  if (points.length === 0) return null;
  let best = points[0];
  points.forEach(p => { if (p.total < best.total - 1e-9) best = p; });
  const base = points.reduce((acc, p) => (Math.abs(p.speed - vRef) < Math.abs(acc.speed - vRef) ? p : acc), points[0]);
  return { points, best, base, vRef, dailyRef, dwtFactor, phaseIn, routeRate };
};

/* Aynı sefer enerjisi için alternatif yakıt karşılaştırması.
   Enerji eşdeğerliği: ton_alt = E(MJ) / (1e6 × LCV_alt) — enerji korunur.
   FuelEU WtW: fosilde Annex II; sertifikalı bio/RFNBO'da yanma CO₂'si
   biyojenik (0) + tipik sertifika WtT (yer tutucu, PoS değeriyle değiştirin);
   sertifikasızda mevzuat gereği 94 gCO₂eq/MJ fosil karşılaştırıcısı. */
const OPT_FUEL_DEFAULT_PRICES = {
  'HFO': 480, 'VLSFO': 540, 'MGO': 720, 'LNG': 560, 'Methanol': 420,
  'Biodiesel': 1150, 'HVO': 1450, 'Bio-Methanol': 900, 'e-Methanol': 1600,
};
const compareFuelsAtEnergy = (params) => {
  const {
    baseFuelType = 'HFO', baseFuelTons = 0, year = 2026, engineType,
    routeType = 'AB içi', carbonPrice = 84, gwpVersion, priceMap = {},
    redCertifiedAlt = true,
  } = params || {};
  const baseF = FUELEU_FACTORS[baseFuelType] || FUELEU_FACTORS['HFO'];
  const energyMJ = (parseFloat(baseFuelTons) || 0) * 1e6 * baseF.lcv;
  if (energyMJ <= 0) return [];
  const routeRate = ROUTE_ETS_RATES[routeType] !== undefined ? ROUTE_ETS_RATES[routeType] : 0;
  const yr = parseInt(year) || 2026;
  const phaseIn = getEtsPhaseIn(String(yr) + '-06-15');
  const limit = getFuelEUTarget(yr).limit;
  const gwp = FUELEU_GWP_SETS[gwpVersion || FUELEU_GWP_DEFAULT];
  return Object.keys(OPT_FUEL_DEFAULT_PRICES).map(ft => {
    const f = FUELEU_FACTORS[ft];
    const tons = energyMJ / (1e6 * f.lcv);
    const isAlt = f.fuelClass !== 'Fossil';
    const cert = isAlt && !!redCertifiedAlt;
    const em = calcEtsCO2eqForFuel(tons, ft, yr, engineType, cert);
    const etsCost = em.co2eq * routeRate * phaseIn * (parseFloat(carbonPrice) || 0);
    let wtw;
    if (!isAlt) {
      wtw = calcWtWIntensity(ft, gwpVersion, engineType);
    } else if (cert) {
      const cslip = resolveCslip(ft, engineType);
      const comb = (1 - cslip) * (f.cfCH4 * gwp.CH4 + f.cfN2O * gwp.N2O); // yanma CO₂ biyojenik → 0
      wtw = (WTT_CERT_DEFAULTS[ft] !== undefined ? WTT_CERT_DEFAULTS[ft] : 20) + (comb + cslip * gwp.CH4) / f.lcv;
    } else {
      wtw = FOSSIL_COMPARATOR_WTW;
    }
    const price = Number.isFinite(parseFloat(priceMap[ft])) ? parseFloat(priceMap[ft]) : OPT_FUEL_DEFAULT_PRICES[ft];
    const fuelCost = tons * price;
    return {
      fuelType: ft, name: f.name, fuelClass: f.fuelClass, tons, co2eq: em.co2eq,
      etsCost, fuelCost, total: fuelCost + etsCost, wtw,
      fuelEUCompliant: wtw <= limit + 1e-9, fuelEULimit: limit, certified: cert, price,
    };
  }).sort((a, b) => a.total - b.total);
};

/* ═══════════════════════════════════════════════════════════════════
   v4 — KARBON PORTFÖYÜ (ağırlıklı ortalama maliyet yöntemi)
   Kayıtlar tarih + oluşturma sırasına göre işlenir; satışta gerçekleşen
   K/Z = adet × (satış fiyatı − o anki ortalama maliyet).
   ═══════════════════════════════════════════════════════════════════ */
const computePortfolioPositions = (transactions, latestPrices) => {
  const lp = latestPrices || {};
  const txs = [...(transactions || [])].sort((a, b) =>
    ((a.date || '') + '#' + (a.createdAt || '')).localeCompare((b.date || '') + '#' + (b.createdAt || '')));
  const pos = {};
  let realizedTotal = 0;
  const errors = [];
  txs.forEach(t => {
    const q = parseFloat(t.quantity) || 0;
    const p = parseFloat(t.unitPrice) || 0;
    if (q <= 0 || !t.instrument) return;
    if (!pos[t.instrument]) pos[t.instrument] = { instrument: t.instrument, qty: 0, cost: 0, realized: 0, boughtQty: 0, soldQty: 0 };
    const s = pos[t.instrument];
    if (t.side === 'buy') {
      s.qty += q; s.cost += q * p; s.boughtQty += q;
    } else if (t.side === 'sell') {
      const avg = s.qty > 0 ? s.cost / s.qty : 0;
      const sellQ = Math.min(q, s.qty);
      if (q > s.qty + 1e-9) errors.push(`${t.instrument}: eldekinden fazla satış kaydı (${q} > ${s.qty.toFixed(2)})`);
      const gain = sellQ * (p - avg);
      s.realized += gain; realizedTotal += gain;
      s.cost -= sellQ * avg; s.qty -= sellQ; s.soldQty += sellQ;
      if (s.qty < 1e-9) { s.qty = 0; s.cost = 0; }
    }
  });
  const positions = Object.values(pos).map(s => {
    const avgCost = s.qty > 0 ? s.cost / s.qty : 0;
    const last = parseFloat(lp[s.instrument]);
    const hasPrice = Number.isFinite(last);
    return {
      ...s, avgCost,
      lastPrice: hasPrice ? last : null,
      marketValue: hasPrice ? s.qty * last : null,
      unrealized: hasPrice ? s.qty * (last - avgCost) : null,
    };
  }).sort((a, b) => a.instrument.localeCompare(b.instrument));
  return { positions, realizedTotal, errors };
};

/* ═══════════════════════════════════════════════════════════════════
   v4 — ERP / MUHASEBE FİŞ SATIRLARI (evrensel dışa aktarım)
   Tekdüzen hesap planına göre ŞABLON kodlar (770/373) — kendi hesap
   planınıza göre CSV içinde değiştirilebilir. Borç = Alacak dengesi
   birim testiyle doğrulanır.
   ═══════════════════════════════════════════════════════════════════ */
const buildErpJournalRows = ({ ship, reportYear, etsLiableTons, carbonPrice, fuelEUPenalty }) => {
  const rows = [];
  const date = `${reportYear}-12-31`;
  const docBase = String(ship && (ship.imoNumber || ship.name) || 'GEMI').replace(/[^\p{L}\p{N}-]+/gu, '-');
  const doc = `SCP-${reportYear}-${docBase}`;
  const r2 = (x) => Math.round((parseFloat(x) || 0) * 100) / 100;
  const etsAmount = r2((parseFloat(etsLiableTons) || 0) * (parseFloat(carbonPrice) || 0));
  if (etsAmount > 0) {
    rows.push({ date, doc, account: '770.10', accountName: 'EU ETS Emisyon Gideri', desc: `${(ship && ship.name) || ''} ${reportYear} ETS tahakkuku — ${(parseFloat(etsLiableTons) || 0).toFixed(2)} t × €${carbonPrice}`, debit: etsAmount, credit: 0 });
    rows.push({ date, doc, account: '373.10', accountName: 'EU ETS Yükümlülük Karşılığı', desc: `${(ship && ship.name) || ''} ${reportYear} ETS karşılığı`, debit: 0, credit: etsAmount });
  }
  const pen = r2(fuelEUPenalty);
  if (pen > 0) {
    rows.push({ date, doc, account: '770.11', accountName: 'FuelEU Maritime Ceza Gideri', desc: `${(ship && ship.name) || ''} ${reportYear} FuelEU ceza tahakkuku`, debit: pen, credit: 0 });
    rows.push({ date, doc, account: '373.11', accountName: 'FuelEU Ceza Karşılığı', desc: `${(ship && ship.name) || ''} ${reportYear} FuelEU karşılığı`, debit: 0, credit: pen });
  }
  return rows;
};

const csvEscape = (v) => {
  const s = String(v === null || v === undefined ? '' : v);
  return /[;"\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
const rowsToCsv = (headers, rows) =>
  '\uFEFF' + [headers, ...rows].map(r => r.map(csvEscape).join(';')).join('\r\n');
/*__END_PURE__*/
module.exports = { computeSpeedSweep, compareFuelsAtEnergy, computePortfolioPositions, buildErpJournalRows, rowsToCsv, csvEscape, calculateFuelAmount, calcWtWIntensity, getFuelEUTarget, FUELEU_FACTORS, OPT_FUEL_DEFAULT_PRICES, FOSSIL_COMPARATOR_WTW, calculateFuelEUCompliance, computeSummary, calculateVoyageEmissions };
