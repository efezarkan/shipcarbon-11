/* ═══════════════════════════════════════════════════════════════════
   ShipCarbon Pro — AWS Lambda Backend (v2 — güvenlik güçlendirilmiş)
   API Gateway (HTTP API v2) + DynamoDB single-table + JWT (HS256)
   ═══════════════════════════════════════════════════════════════════ */
import crypto from 'node:crypto';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import {
  DynamoDBDocumentClient, GetCommand, PutCommand, UpdateCommand,
  DeleteCommand, QueryCommand,
} from '@aws-sdk/lib-dynamodb';

const TABLE = process.env.TABLE_NAME;
const JWT_SECRET = process.env.JWT_SECRET;
const TOKEN_TTL_SEC = 60 * 60 * 12;      // 12 saat
const MAX_LOGIN_FAILS = 5;               // brute-force kilidi
const LOCK_MINUTES = 15;

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}), {
  marshallOptions: { removeUndefinedValues: true },
});

/* ── Yardımcılar ─────────────────────────────────────────────────── */
const uid = () => 'id_' + crypto.randomBytes(9).toString('hex');
const nowIso = () => new Date().toISOString();
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const hashPin = (pin, salt) => sha256(`${salt}:${pin}`);
const chainHash = (prevHash, payload, seq) =>
  sha256(prevHash + JSON.stringify(payload) + seq).slice(0, 16);
const pad = (n) => String(n).padStart(10, '0');

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

/* GÜVENLİK: istemci gövdesinden rezerve/tehlikeli anahtarları temizle
   (PK/SK enjeksiyonu ile kiracılar-arası yazma girişimini engeller)
   + aşırı uzun dizeleri kırp (depolama kötüye kullanımı) */
const RESERVED = new Set(['PK', 'SK', 'GSI1PK', 'GSI1SK', 'companyId', 'id',
  'chainSeq', 'chainHash', 'prevHash', 'pinHash', 'salt', 'createdAt']);
const sanitize = (body, { keepId = false } = {}) => {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) return {};
  const out = {};
  for (const [k, v] of Object.entries(body)) {
    if (RESERVED.has(k) && !(keepId && k === 'id')) continue;
    if (typeof v === 'string') out[k] = v.slice(0, 500);
    else if (typeof v === 'number' || typeof v === 'boolean' || v === null) out[k] = v;
    else if (typeof v === 'object') out[k] = sanitize(v);
  }
  return out;
};

/* ── JWT (HS256) ─────────────────────────────────────────────────── */
const b64u = (buf) => Buffer.from(buf).toString('base64url');
const signToken = (payload) => {
  const header = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64u(JSON.stringify({ ...payload, iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SEC }));
  const sig = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
};
const verifyToken = (token) => {
  const parts = (token || '').split('.');
  if (parts.length !== 3) throw new ApiError(401, 'Geçersiz oturum.');
  const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${parts[0]}.${parts[1]}`).digest('base64url');
  const a = Buffer.from(parts[2]); const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new ApiError(401, 'Geçersiz oturum.');
  const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
  if (payload.exp < Math.floor(Date.now() / 1000)) throw new ApiError(401, 'Oturum süresi doldu.');
  return payload;
};

/* ── DynamoDB erişim ─────────────────────────────────────────────── */
/* NOT: put'larda anahtarlar HER ZAMAN en sonda yayılır — gövde asla
   PK/SK'yı ezemez (savunma katmanı #2, sanitize'a ek). */
const put = (item, keys) => ddb.send(new PutCommand({ TableName: TABLE, Item: { ...item, ...keys } }));
const get = async (PK, SK) => (await ddb.send(new GetCommand({ TableName: TABLE, Key: { PK, SK } }))).Item || null;
const del = (PK, SK) => ddb.send(new DeleteCommand({ TableName: TABLE, Key: { PK, SK } }));
const queryPrefix = async (PK, skPrefix) => {
  const items = [];
  let ExclusiveStartKey;
  do {
    const r = await ddb.send(new QueryCommand({
      TableName: TABLE,
      KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
      ExpressionAttributeValues: { ':pk': PK, ':sk': skPrefix },
      ExclusiveStartKey,
    }));
    items.push(...(r.Items || []));
    ExclusiveStartKey = r.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items;
};
const strip = ({ PK, SK, GSI1PK, GSI1SK, pinHash, salt, failCount, lockUntil, ...rest }) => rest;

/* Zincir sayacı: atomik seq + hash (çakışmada retry) */
async function nextChain(cid, kind, payload) {
  const key = { PK: `COMPANY#${cid}`, SK: `CHAIN#${kind}` };
  for (let attempt = 0; attempt < 4; attempt++) {
    const cur = (await ddb.send(new GetCommand({ TableName: TABLE, Key: key }))).Item || { seq: 0, hash: '0' };
    const seq = (cur.seq || 0) + 1;
    const prevHash = cur.hash || '0';
    const hash = chainHash(prevHash, payload, seq);
    try {
      await ddb.send(new UpdateCommand({
        TableName: TABLE, Key: key,
        UpdateExpression: 'SET #s = :new, #h = :hash',
        ConditionExpression: 'attribute_not_exists(#s) OR #s = :old',
        ExpressionAttributeNames: { '#s': 'seq', '#h': 'hash' },
        ExpressionAttributeValues: { ':new': seq, ':old': cur.seq || 0, ':hash': hash },
      }));
      return { seq, hash, prevHash };
    } catch (e) {
      if (e.name !== 'ConditionalCheckFailedException') throw e;
      await new Promise(r => setTimeout(r, 40 * (attempt + 1)));
    }
  }
  throw new ApiError(409, 'Eşzamanlı yazma çakışması, tekrar deneyin.');
}

/* ── Auth ────────────────────────────────────────────────────────── */
async function listCompanies() {
  const r = await ddb.send(new QueryCommand({
    TableName: TABLE, IndexName: 'GSI1',
    KeyConditionExpression: 'GSI1PK = :p',
    ExpressionAttributeValues: { ':p': 'COMPANY' },
  }));
  return { companies: (r.Items || []).map(c => ({ id: c.id, name: c.name, imoCompanyNo: c.imoCompanyNo })) };
}

const LOGIN_ERR = 'Kullanıcı adı, rol veya PIN hatalı.'; // kullanıcı-enumerasyonunu önlemek için tek mesaj

async function login(rawBody) {
  const { companyId, userName, role, pin } = sanitize(rawBody);
  if (!companyId || !userName || !role || !pin) throw new ApiError(400, 'Eksik alanlar.');
  const company = await get(`COMPANY#${companyId}`, 'META');
  if (!company) throw new ApiError(401, LOGIN_ERR);
  const userKey = `USER#${userName}#${role}`;
  const user = await get(`COMPANY#${companyId}`, userKey);
  /* GÜVENLİK DÜZELTMESİ: girişte otomatik kullanıcı oluşturma KALDIRILDI.
     (Eski davranış, şirket kimliğini bilen herkesin kendine yönetici
     hesabı açmasına izin veriyordu.) Yeni kullanıcıları yalnızca
     şirket yöneticisi POST /users ile ekler. */
  if (!user) throw new ApiError(401, LOGIN_ERR);
  /* Brute-force kilidi */
  if (user.lockUntil && user.lockUntil > nowIso())
    throw new ApiError(429, `Çok fazla hatalı deneme. ${LOCK_MINUTES} dk sonra tekrar deneyin.`);
  if (user.pinHash !== hashPin(pin, user.salt)) {
    const fails = (user.failCount || 0) + 1;
    const lockUntil = fails >= MAX_LOGIN_FAILS
      ? new Date(Date.now() + LOCK_MINUTES * 60000).toISOString() : undefined;
    await put({ ...user, failCount: fails >= MAX_LOGIN_FAILS ? 0 : fails, lockUntil },
      { PK: `COMPANY#${companyId}`, SK: userKey });
    throw new ApiError(401, LOGIN_ERR);
  }
  if (user.failCount || user.lockUntil)
    await put({ ...user, failCount: 0, lockUntil: undefined }, { PK: `COMPANY#${companyId}`, SK: userKey });
  const session = { companyId, userName, role, loginAt: nowIso() };
  const token = signToken({ cid: companyId, userName, role });
  return { token, session, company: strip(company) };
}

async function register(rawBody) {
  const { companyName, imoCompanyNo, country, userName, pin } = sanitize(rawBody);
  if (!companyName || !userName || !pin || pin.length < 4) throw new ApiError(400, 'Eksik/geçersiz alanlar.');
  const id = uid();
  const company = { id, name: companyName, imoCompanyNo: imoCompanyNo || '', country: country || '', plan: 'demo', createdAt: nowIso() };
  await put(company, { PK: `COMPANY#${id}`, SK: 'META', GSI1PK: 'COMPANY', GSI1SK: companyName });
  const salt = crypto.randomBytes(8).toString('hex');
  await put({ userName, role: 'company_admin', salt, pinHash: hashPin(pin, salt), createdAt: nowIso() },
    { PK: `COMPANY#${id}`, SK: `USER#${userName}#company_admin` });
  const session = { companyId: id, userName, role: 'company_admin', loginAt: nowIso() };
  const token = signToken({ cid: id, userName, role: 'company_admin' });
  return { token, session, company };
}

async function changePin(auth, rawBody) {
  const { oldPin, newPin } = sanitize(rawBody);
  if (!newPin || newPin.length < 4) throw new ApiError(400, 'Yeni PIN en az 4 hane.');
  const userKey = `USER#${auth.userName}#${auth.role}`;
  const user = await get(`COMPANY#${auth.cid}`, userKey);
  if (!user) throw new ApiError(404, 'Kullanıcı yok.');
  if (user.pinHash !== hashPin(oldPin, user.salt)) throw new ApiError(401, 'Mevcut PIN hatalı.');
  const salt = crypto.randomBytes(8).toString('hex');
  await put({ ...user, salt, pinHash: hashPin(newPin, salt), failCount: 0, lockUntil: undefined },
    { PK: `COMPANY#${auth.cid}`, SK: userKey });
  return { ok: true };
}

const VALID_ROLES = ['officer', 'superintendent', 'auditor', 'company_admin'];
const requireAdmin = (auth) => {
  if (auth.role !== 'company_admin') throw new ApiError(403, 'Bu işlem için şirket yöneticisi yetkisi gerekir.');
};
/* Yazma yetkisi: fiyat girişi ve portföy işlemleri (v4) */
const WRITER_ROLES = ['superintendent', 'company_admin'];
const requireWriter = (auth) => {
  if (!WRITER_ROLES.includes(auth.role)) throw new ApiError(403, 'Bu işlem için süpervizör veya yönetici yetkisi gerekir.');
};
const isValidDateStr = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s));
/* Sefer oluşturma/düzenleme: gemi subayı dahil (UI izinleriyle birebir) */
const VOYAGE_WRITERS = ['officer', 'superintendent', 'company_admin'];
const requireVoyageWriter = (auth) => {
  if (!VOYAGE_WRITERS.includes(auth.role)) throw new ApiError(403, 'Sefer yazma yetkiniz yok.');
};

/* ── Router ──────────────────────────────────────────────────────── */
async function route(method, path, body, authHeader) {
  if (method === 'GET' && path === '/auth/companies') return listCompanies();
  if (method === 'POST' && path === '/auth/login') return login(body);
  if (method === 'POST' && path === '/auth/register') return register(body);
  if (method === 'GET' && path === '/health') return { ok: true, ts: nowIso() };

  const token = (authHeader || '').replace(/^Bearer\s+/i, '');
  const auth = verifyToken(token);
  const cid = auth.cid;
  const PK = `COMPANY#${cid}`;
  const clean = sanitize(body);

  if (method === 'GET' && path === '/auth/session') {
    const company = await get(PK, 'META');
    if (!company) throw new ApiError(404, 'Şirket bulunamadı.');
    return { token, session: { companyId: cid, userName: auth.userName, role: auth.role, loginAt: nowIso() }, company: strip(company) };
  }
  if (method === 'POST' && path === '/auth/logout') return {};
  if (method === 'POST' && path === '/auth/change-pin') return changePin(auth, body);

  /* Kullanıcı yönetimi (yalnızca company_admin) */
  if (method === 'GET' && path === '/users') {
    requireAdmin(auth);
    const users = await queryPrefix(PK, 'USER#');
    return { users: users.map(u => ({ userName: u.userName, role: u.role, createdAt: u.createdAt })) };
  }
  if (method === 'POST' && path === '/users') {
    requireAdmin(auth);
    const { userName, role, pin } = clean;
    if (!userName || !VALID_ROLES.includes(role)) throw new ApiError(400, 'Geçersiz kullanıcı adı veya rol.');
    if (!pin || pin.length < 4) throw new ApiError(400, 'PIN en az 4 hane.');
    const userKey = `USER#${userName}#${role}`;
    if (await get(PK, userKey)) throw new ApiError(409, 'Bu kullanıcı zaten mevcut.');
    const salt = crypto.randomBytes(8).toString('hex');
    await put({ userName, role, salt, pinHash: hashPin(pin, salt), createdBy: auth.userName, createdAt: nowIso() },
      { PK, SK: userKey });
    return { user: { userName, role } };
  }
  let m = path.match(/^\/users\/([^/]+)\/([^/]+)$/);
  if (m && method === 'DELETE') {
    requireAdmin(auth);
    const [, uName, uRole] = m.map(decodeURIComponent);
    if (uName === auth.userName && uRole === auth.role) throw new ApiError(400, 'Kendi hesabınızı silemezsiniz.');
    await del(PK, `USER#${uName}#${uRole}`);
    return { ok: true };
  }

  /* Ships */
  if (method === 'GET' && path === '/ships')
    return { ships: (await queryPrefix(PK, 'SHIP#')).map(strip) };
  if (method === 'POST' && path === '/ships') {
    requireWriter(auth); /* GÜVENLİK (v4.1): UI izni sunucuda da zorlanır */
    if (!clean.name) throw new ApiError(400, 'Gemi adı zorunlu.');
    const ship = { ...clean, id: uid(), companyId: cid, createdAt: nowIso() };
    await put(ship, { PK, SK: `SHIP#${ship.id}` });
    return { ship };
  }
  m = path.match(/^\/ships\/([^/]+)$/);
  if (m && method === 'PUT') {
    requireWriter(auth); /* GÜVENLİK (v4.1) */
    const cur = await get(PK, `SHIP#${m[1]}`);
    if (!cur) throw new ApiError(404, 'Gemi bulunamadı.');
    const ship = { ...strip(cur), ...clean, id: cur.id, companyId: cid };
    await put(ship, { PK, SK: `SHIP#${cur.id}` });
    return { ship };
  }
  if (m && method === 'DELETE') { requireAdmin(auth); /* GÜVENLİK (v4.1) */ await del(PK, `SHIP#${m[1]}`); return null; }

  /* Voyages — hash zincirli (prevHash saklanır → gerçek bağ doğrulaması) */
  if (method === 'GET' && path === '/voyages')
    return { voyages: (await queryPrefix(PK, 'VOY#')).map(strip) };
  if (method === 'POST' && path === '/voyages') {
    requireVoyageWriter(auth); /* GÜVENLİK (v4.1): auditor yazamaz */
    /* DOĞRULAMA (v4.1): shipId ve geçerli tarih olmadan kayıt tüm yıllık
       hesapları (CII/FuelEU yıl filtresi) sessizce bozabiliyordu. */
    if (!clean.shipId || typeof clean.shipId !== 'string') throw new ApiError(400, 'shipId zorunlu.');
    if (!isValidDateStr(String(clean.date || ''))) throw new ApiError(400, 'Geçerli sefer tarihi (YYYY-AA-GG) zorunlu.');
    const { seq, hash, prevHash } = await nextChain(cid, 'VOY', clean);
    const voyage = { ...clean, id: uid(), companyId: cid, chainSeq: seq, chainHash: hash, prevHash, createdAt: nowIso() };
    await put(voyage, { PK, SK: `VOY#${pad(seq)}#${voyage.id}` });
    return { voyage };
  }
  m = path.match(/^\/voyages\/([^/]+)$/);
  if (m && (method === 'PUT' || method === 'DELETE')) {
    if (method === 'DELETE') requireWriter(auth); /* GÜVENLİK (v4.1): silme süpervizör+ */
    else requireVoyageWriter(auth);
    const all = await queryPrefix(PK, 'VOY#');
    const cur = all.find(v => v.id === m[1]);
    if (!cur) throw new ApiError(404, 'Sefer bulunamadı.');
    if (method === 'DELETE') { await del(cur.PK, cur.SK); return null; }
    const voyage = { ...strip(cur), ...clean, id: cur.id, companyId: cid, chainSeq: cur.chainSeq, chainHash: cur.chainHash, prevHash: cur.prevHash };
    await put(voyage, { PK: cur.PK, SK: cur.SK });
    return { voyage };
  }

  /* BDN */
  if (method === 'GET' && path === '/bdn')
    return { bdnList: (await queryPrefix(PK, 'BDN#')).map(strip) };
  if (method === 'POST' && path === '/bdn') {
    requireWriter(auth); /* GÜVENLİK (v4.1): BDN yükleme süpervizör+ */
    if (!clean.fuelType || !clean.deliveryDate) throw new ApiError(400, 'Yakıt tipi ve tarih zorunlu.');
    const bdn = { ...clean, id: uid(), companyId: cid, isVerified: false, createdAt: nowIso() };
    await put(bdn, { PK, SK: `BDN#${bdn.id}` });
    return { bdn };
  }
  if (method === 'POST' && path === '/bdn/link') {
    requireWriter(auth); /* GÜVENLİK (v4.1) */
    const { bdnId, voyageId } = clean;
    if (!bdnId) throw new ApiError(400, 'bdnId zorunlu.');
    const bdn = await get(PK, `BDN#${bdnId}`);
    if (!bdn) throw new ApiError(404, 'BDN bulunamadı.');
    await put({ ...strip(bdn), voyageId, isVerified: bdn.isVerified }, { PK, SK: bdn.SK });
    if (bdn.isVerified && voyageId) await markVoyageVerified(PK, voyageId, bdnId);
    return { ok: true, voyageId, bdnId };
  }
  m = path.match(/^\/bdn\/([^/]+)\/verify$/);
  if (m && method === 'PUT') {
    /* RBAC: doğrulama yalnızca yetkili roller */
    if (!['superintendent', 'company_admin', 'auditor'].includes(auth.role))
      throw new ApiError(403, 'BDN doğrulama yetkiniz yok.');
    const bdn = await get(PK, `BDN#${m[1]}`);
    if (!bdn) throw new ApiError(404, 'BDN bulunamadı.');
    const updated = { ...strip(bdn), isVerified: true, verifiedBy: auth.userName, verifiedAt: nowIso() };
    await put(updated, { PK, SK: bdn.SK });
    if (updated.voyageId) await markVoyageVerified(PK, updated.voyageId, updated.id);
    return updated;
  }

  /* Audit — hash zincirli */
  if (method === 'GET' && path === '/audit') {
    const log = (await queryPrefix(PK, 'AUDIT#')).map(strip);
    return { auditLog: log.sort((a, b) => (b.ts || '').localeCompare(a.ts || '')).slice(0, 500) };
  }
  if (method === 'POST' && path === '/audit') {
    if (!clean.action || typeof clean.action !== 'string') throw new ApiError(400, 'action zorunlu.');
    const { seq, hash, prevHash } = await nextChain(cid, 'AUDIT', clean.action);
    const entry = {
      id: uid(), companyId: cid, seq, ts: nowIso(),
      user: auth.userName, role: auth.role,
      action: clean.action, entityId: clean.entityId || null,
      details: clean.details || '', chainHash: hash, prevHash,
    };
    await put(entry, { PK, SK: `AUDIT#${pad(seq)}` });
    return { entry };
  }

  /* Chain verify — hem seq monotonluğu hem gerçek hash bağını doğrular */
  if (method === 'GET' && path === '/chain/verify') {
    const verify = (arr, seqField) => {
      const sorted = [...arr].sort((a, b) => (a[seqField] || 0) - (b[seqField] || 0));
      if (sorted.length === 0) return { valid: true, total: 0, brokenAt: null };
      let prevSeq = 0, prevHash = null;
      for (const it of sorted) {
        const s = it[seqField];
        if (s !== undefined && s <= prevSeq)
          return { valid: false, total: sorted.length, brokenAt: { seq: s, reason: 'Seq sırası bozuk' } };
        /* prevHash saklanmışsa gerçek bağ kontrolü (silinen kayıtlar zinciri
           kırar; bu bilinçli bir bütünlük özelliğidir) */
        if (it.prevHash !== undefined && prevHash !== null && it.prevHash !== prevHash)
          return { valid: false, total: sorted.length, brokenAt: { seq: s, reason: 'Hash bağı kopuk (kayıt silinmiş/değiştirilmiş olabilir)' } };
        if (s !== undefined) prevSeq = s;
        if (it.chainHash !== undefined) prevHash = it.chainHash;
      }
      return { valid: true, total: sorted.length, brokenAt: null };
    };
    const [voyages, bdnList, auditLog] = await Promise.all([
      queryPrefix(PK, 'VOY#'), queryPrefix(PK, 'BDN#'), queryPrefix(PK, 'AUDIT#'),
    ]);
    return {
      voyages: verify(voyages, 'chainSeq'),
      bdn: { valid: true, total: bdnList.length, brokenAt: null },
      audit: verify(auditLog, 'seq'),
      checkedAt: nowIso(),
    };
  }

  /* Verifier sessions */
  if (method === 'GET' && path === '/verifier/sessions')
    return { sessions: (await queryPrefix(PK, 'VSESS#')).map(strip) };
  if (method === 'POST' && path === '/verifier/sessions') {
    requireAdmin(auth);
    const vtoken = 'vtok_' + uid();
    const session = {
      id: uid(), companyId: cid,
      verifierOrg: clean.verifierOrg, verifierEmail: clean.verifierEmail || '',
      reportYear: clean.reportYear, expiryDays: clean.expiryDays,
      createdAt: nowIso(), createdBy: auth.userName,
      expiresAt: new Date(Date.now() + (clean.expiryDays || 30) * 86400000).toISOString(),
      isRevoked: false, token: vtoken,
    };
    await put(session, { PK, SK: `VSESS#${session.id}` });
    return { session, token: vtoken };
  }
  m = path.match(/^\/verifier\/sessions\/([^/]+)\/revoke$/);
  if (m && method === 'PUT') {
    requireAdmin(auth);
    const s = await get(PK, `VSESS#${m[1]}`);
    if (s) await put({ ...strip(s), isRevoked: true }, { PK, SK: s.SK });
    return { ok: true };
  }

  /* ── v4: Karbon fiyat yönetimi (EUA / gönüllü kredi vb.) ──
     Fiyatlar şirket kapsamındadır; canlı borsa feed'i lisans gerektirdiğinden
     kaynak alanıyla birlikte manuel/entegrasyon girişi olarak saklanır. */
  if (method === 'GET' && path === '/prices') {
    const prices = (await queryPrefix(PK, 'PRICE#')).map(strip);
    return { prices: prices.sort((a, b) => ((b.date || '') + (b.createdAt || '')).localeCompare((a.date || '') + (a.createdAt || ''))) };
  }
  if (method === 'POST' && path === '/prices') {
    requireWriter(auth);
    const instrument = String(clean.instrument || '').trim().slice(0, 24);
    const price = parseFloat(clean.price);
    const date = String(clean.date || '').slice(0, 10);
    if (!instrument) throw new ApiError(400, 'instrument zorunlu (örn. EUA, VCC).');
    if (!Number.isFinite(price) || price < 0) throw new ApiError(400, 'price ≥ 0 sayı olmalı.');
    if (!isValidDateStr(date)) throw new ApiError(400, 'date YYYY-AA-GG biçiminde olmalı.');
    const entry = {
      id: uid(), companyId: cid, instrument, price, date,
      source: String(clean.source || 'manuel').slice(0, 100),
      createdBy: auth.userName, createdAt: nowIso(),
    };
    await put(entry, { PK, SK: `PRICE#${entry.id}` });
    return { price: entry };
  }
  m = path.match(/^\/prices\/([^/]+)$/);
  if (m && method === 'DELETE') { requireAdmin(auth); await del(PK, `PRICE#${m[1]}`); return { ok: true }; }

  /* ── v4: Karbon kredi portföyü (kayıt/portföy yönetimi) ──
     NOT: Bu uçlar işlem KAYDI tutar; gerçek EUA/kredi alım-satımı borsa veya
     aracı kurum üzerinden yapılır ve buraya referansıyla işlenir. */
  if (method === 'GET' && path === '/portfolio')
    return { transactions: (await queryPrefix(PK, 'PTX#')).map(strip) };
  if (method === 'POST' && path === '/portfolio') {
    requireWriter(auth);
    const side = clean.side === 'sell' ? 'sell' : (clean.side === 'buy' ? 'buy' : null);
    const instrument = String(clean.instrument || '').trim().slice(0, 24);
    const quantity = parseFloat(clean.quantity);
    const unitPrice = parseFloat(clean.unitPrice);
    const date = String(clean.date || '').slice(0, 10);
    if (!side) throw new ApiError(400, "side 'buy' veya 'sell' olmalı.");
    if (!instrument) throw new ApiError(400, 'instrument zorunlu.');
    if (!Number.isFinite(quantity) || quantity <= 0) throw new ApiError(400, 'quantity > 0 olmalı.');
    if (!Number.isFinite(unitPrice) || unitPrice < 0) throw new ApiError(400, 'unitPrice ≥ 0 olmalı.');
    if (!isValidDateStr(date)) throw new ApiError(400, 'date YYYY-AA-GG biçiminde olmalı.');
    if (side === 'sell') {
      const txs = await queryPrefix(PK, 'PTX#');
      const held = txs
        .filter(t => t.instrument === instrument)
        .reduce((s, t) => s + (t.side === 'buy' ? (parseFloat(t.quantity) || 0) : -(parseFloat(t.quantity) || 0)), 0);
      if (quantity > held + 1e-9)
        throw new ApiError(400, `Yetersiz pozisyon: elde ${held.toFixed(2)} ${instrument} var.`);
    }
    const tx = {
      id: uid(), companyId: cid, side, instrument, quantity, unitPrice, date,
      registryRef: String(clean.registryRef || '').slice(0, 120),
      note: String(clean.note || '').slice(0, 300),
      createdBy: auth.userName, createdAt: nowIso(),
    };
    await put(tx, { PK, SK: `PTX#${tx.id}` });
    return { transaction: tx };
  }
  m = path.match(/^\/portfolio\/([^/]+)$/);
  if (m && method === 'DELETE') { requireAdmin(auth); await del(PK, `PTX#${m[1]}`); return { ok: true }; }

  throw new ApiError(404, `Rota bulunamadı — ${method} ${path}`);
}

async function markVoyageVerified(PK, voyageId, bdnId) {
  const all = await queryPrefix(PK, 'VOY#');
  const v = all.find(x => x.id === voyageId);
  if (v) await put({ ...strip(v), bdnVerified: true, bdnId, chainSeq: v.chainSeq, chainHash: v.chainHash, prevHash: v.prevHash }, { PK: v.PK, SK: v.SK });
}

/* ── Lambda giriş noktası ────────────────────────────────────────── */
export const handler = async (event) => {
  const method = event.requestContext?.http?.method || 'GET';
  const path = event.rawPath || '/';
  const authHeader = event.headers?.authorization || event.headers?.Authorization;
  let body = null;
  if (event.body) {
    try { body = JSON.parse(event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString() : event.body); }
    catch { body = null; }
  }
  try {
    const result = await route(method, path, body, authHeader);
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(result ?? {}) };
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    return {
      statusCode: status,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: status === 500 ? 'Sunucu hatası' : e.message }),
    };
  }
};
